# fieldz/protoSpec.py

#__all__ = [ 
#]

class Protocol(object):
    """ 
    A Protocol is a set of message types, enumerations, and acceptable
    message sequences.  It is essential for our purposes that any
    Protocol can be constructed dynamically from its wire serialization.

    """

    def __init__(self):
        pass

class MsgSequence(object):
    """

    """
    pass

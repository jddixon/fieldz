#!/usr/bin/python

# testRingDataProto.py

import binascii, time, unittest
from io             import StringIO

from rnglib         import SimpleRNG
from ringDataProto  import RING_DATA_PROTO_SPEC

from fieldz.parser import StringProtoSpecParser
import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T
from pzog.xlattice.node     import Node
from fieldz.chan            import Channel
from fieldz.msgImpl         import makeMsgClass, makeFieldClass

rng             = SimpleRNG(int(time.time()))
BUFSIZE         = 16 * 1024
hostByName      = {}
hostByAddr      = {}
hostByNodeID    = {}
hostByPubKey    = {}
hostByPrivateKey= {}


class HostInfo(object):
    __slots__ = ['_name', '_ipAddr', '_nodeID', '_pubKey',
                 '_privateKey',]
    def __init__(self, name=None, ipAddr=None, nodeID=None,
                       pubKey=None, privateKey=None):
        self._name      = name
        self._ipAddr    = ipAddr
        self._nodeID    = nodeID
        self._pubKey    = pubKey
        self._privateKey= privateKey

    @classmethod
    def createRandomHost(cls):
            name, dottedQ, nodeID, pubKey, privateKey = hostInfoValues()
            return cls(name, dottedQ, nodeID, pubKey, privateKey)  

class RingData(object):
    __slots__ = ['_hosts',]
    def __init__(self, hosts):
        # DEBUG
        # END
        self._hosts = []
        for h in hosts:
            self._hosts.append(h)

    @classmethod
    def createRandomRing(cls):
        ring = ringDataValues()
        return cls(ring)

def ringDataValues():
    count = 2 + rng.nextInt16(4)    # so 2 to 5 hosts
    ring  = []
    for n in range(count):
        host = HostInfo.createRandomHost()
        ring.append(host)
    # DEBUG
    print "RING_DATA_VALUES returning a list of %u hosts" % len (ring)
    # END
    return ring

def hostInfoValues():
    maxCount = 8
    n = 0
    while n < maxCount:
        n           = n + 1
        node        = Node()  # by default uses SHA3 and generates RSA keys
        privateKey  = node.key
        pubKey      = node.pubKey
        nodeID      = node.nodeID
    
        name    = rng.nextFileName(8)
        
        addr    = rng.nextInt32()
        dottedQ = '%d.%d.%d.%d' % (
                    (addr >> 24 & 0xff),
                    (addr >> 16 & 0xff),
                    (addr >>  8 & 0xff),
                    (addr       & 0xff))
        # DEBUG
        print "name is      '%s'" % name
        print "addr is      '%s'" % addr
        print "dottedQ is   '%s'" % dottedQ
        print "nodeID is    '%s'" % binascii.b2a_hex(nodeID)
        # END
        if name     in hostByName:  
            continue
        if dottedQ  in hostByAddr:   
            continue
        if nodeID   in hostByNodeID: 
            continue
        # DEBUG
        # print "PUB_KEY: %s" % pubKey.n
        # END
        if pubKey.n  in hostByPubKey:    
            print "pubKey is not unique"
            continue
        if privateKey.n  in hostByPrivateKey:
            print "privateKey is not unique"
            continue
        return (name, dottedQ, nodeID, pubKey, privateKey)  # GEEP

class TestRingDataProto (unittest.TestCase):

    def setUp(self):
        pass
    def tearDown(self):
        pass

    # utility functions #############################################

    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    def makeSOM(self):
        # MODEL: testProtoSpec XXX
        data = StringIO(RING_DATA_PROTO_SPEC)
        p    = StringProtoSpecParser(data)
        sOM  = p.parse()             # object model from string serialization
        return sOM

    # actual unit tests #############################################
    def testRingDataProto(self):
        sOM  = self.makeSOM()
        self.assertIsNotNone(sOM)
        self.assertTrue(isinstance(sOM, M.ProtoSpec))
        self.assertEquals( 'org.xlattice.pzog.ringData', sOM.name )
        self.assertEquals(0, len(sOM.enums) )
        self.assertEquals(1, len(sOM.msgs) )
        self.assertEquals(0, len(sOM.seqs) )

        # OUTER MESSAGE SPEC ----------------------------------------
        msgSpec = sOM.msgs[0]
        field = msgSpec[0]
        self.assertEquals(field.name,           'hosts')
        self.assertEquals(field.fTypeName,      'hostInfo')
        self.assertEquals(field.quantifier,     M.Q_PLUS)

        # INNER MESSAGE SPEC ----------------------------------------
        msgSpec = sOM.msgs[0].msgs[0]
        self.assertEquals(msgSpec.fName(0),     'hostName')
        self.assertEquals(msgSpec.fTypeName(0), 'lString')
        self.assertEquals(msgSpec.fName(1),     'ipAddr')
        self.assertEquals(msgSpec.fTypeName(1), 'lString')
        self.assertEquals(msgSpec.fName(2),     'nodeID')
        self.assertEquals(msgSpec.fTypeName(2), 'fBytes32')
        self.assertEquals(msgSpec.fName(3),     'pubKey')
        self.assertEquals(msgSpec.fTypeName(3), 'lString')
        self.assertEquals(msgSpec.fName(4),     'privateKey')
        self.assertEquals(msgSpec.fTypeName(4), 'lString')
        try:
            msgSpec.fName(5)
            self.fail('did not catch reference to non-existent field')
        except IndexError as ie:
            pass                                                    # GEEP

    # ---------------------------------------------------------------
    def testCaching(self):
        """ verify that classes with the same definition are cached """
        sOM          = self.makeSOM()
        protoName    = sOM.name
        self.assertTrue(isinstance(sOM, M.ProtoSpec))

        outerMsgSpec = sOM.msgs[0]
        innerMsgSpec = sOM.msgs[0].msgs[0]
        OuterMsg     = makeMsgClass(protoName, outerMsgSpec)
        InnerMsg     = makeMsgClass(protoName, innerMsgSpec)
        
        # TEST INNER MESSAGE ########################################
        Clz0    = makeMsgClass(protoName, innerMsgSpec)
        Clz1    = makeMsgClass(protoName, innerMsgSpec)
        # we cache classes, so the two should be the same
        self.assertEquals(id(Clz0), id(Clz1))

        # test that msg instances created from the same value lists differ
        values      = hostInfoValues()
        innerMsg0   = Clz0(values) 
        innerMsg1   = Clz0(values) 
        # we don't cache instances, so these will differ
        self.assertNotEquals(id(innerMsg0), id(innerMsg1))

        # verify that field classes are cached 
        fieldSpec = innerMsgSpec[0]
        F0    = makeFieldClass(protoName, innerMsgSpec.name, fieldSpec)
        F1    = makeFieldClass(protoName, innerMsgSpec.name, fieldSpec)
        self.assertEquals(id(F0), id(F1))           # GEEP

        # TEST OUTER MESSAGE ########################################
        Clz2    = makeMsgClass(protoName, outerMsgSpec)
        Clz3    = makeMsgClass(protoName, outerMsgSpec)
        # we cache classe, so the two should be the same
        self.assertEquals(id(Clz2), id(Clz3))

        # test that msg instances created from the same value lists differ
        ring        = ringDataValues()  # a list of random hosts

        # 'values' is a list of field values.  In this case, the single 
        # value is itself a list, a list of HostInfo value lists.
        values      = [ring]            # a list whose only member is a list 

        outerMsg0   = Clz2(values)
        outerMsg1   = Clz2(values) 
        # we don't cache instances, so these will differ
        self.assertNotEquals(id(outerMsg0), id(outerMsg1))

        fieldSpec = outerMsgSpec[0]
        F0    = makeFieldClass(protoName, outerMsgSpec.name, fieldSpec)
        F1    = makeFieldClass(protoName, outerMsgSpec.name, fieldSpec)
        self.assertEquals(id(F0), id(F1))           # GEEP

    # ---------------------------------------------------------------
    def testMsgImpl(self):
        sOM          = self.makeSOM()
        protoName    = sOM.name
        outerMsgSpec = sOM.msgs[0]
        innerMsgSpec = sOM.msgs[0].msgs[0]
        OuterMsg     = makeMsgClass(protoName, outerMsgSpec)
        InnerMsg     = makeMsgClass(protoName, innerMsgSpec)

        #############################################################
        # XXX WORKING HERE, testMsgImpl.testMsgImpl is model ########
        #############################################################
        
        # Create a channel ------------------------------------------
        # its buffer will be used for both serializing # the instance 
        # data and, by deserializing it, for creating a second instance.
        chan = Channel(BUFSIZE)
        buf  = chan.buffer
        self.assertEquals( BUFSIZE, len(buf) )

        # create a message instance ---------------------------------
        ring        = ringDataValues()  # a list of random hosts

        # 'values' is a list of field values.  In this case, the single 
        # value is itself a list, a list of HostInfo value lists.
        values      = [ring]            # a list whose only member is a list 
        
        outerMsg   = OuterMsg( values )

        # serialize the object to the channel -----------------------
        # XXX FAILS: 'list index out of range, line 149, msgImply.py 
        outerMsg.putter(chan)

        # XXX this has no useful effect:
        chan.limit    = chan.position  
        chan.position = 0

        # deserialize the channel, making a clone of the message ----
        readBack = OuterMsg.getter(chan) 
        self.assertIsNotNone(readBack)

        # verify that the messages are identical --------------------
        self.assertTrue(outerMsg.__eq__(readBack))

        # produce another message from the same values --------------
        outerMsg2  = OuterMsg( values )
        chan2      = Channel(BUFSIZE)
        outerMsg2.putter(chan2)
        copy2      = OuterMsg.getter(chan2)
        self.assertTrue(outerMsg.__eq__(copy2))
        self.assertTrue(outerMsg2.__eq__(copy2))                   # GEEP
    
    
    
    # ---------------------------------------------------------------
    def roundTripRingDataInstanceToWireFormat(self, spec, r): # r = ringHost

        # invoke WireMsgSpecWriter
        # XXX STUB

        # invoke WireMsgSpecParser
        # XXX STUB

        pass

    def testRoundTripRingDataInstancesToWireFormat(self):
        strSpec     = StringIO(RING_DATA_PROTO_SPEC)
        p           = StringProtoSpecParser(strSpec)
        ringDataSpec= p.parse()

        count = 3 + rng.nextInt16(6)   # so 3..8 inclusive

        # make that many semi-random nodes, taking care to avoid duplicates,
        # and round-trip each
        for k in range(count):
            r = HostInfo.createRandomHost()
            self.roundTripRingDataInstanceToWireFormat(ringDataSpec, r) # GEEP


if __name__ == '__main__':
    unittest.main()

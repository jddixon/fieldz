# ~/dev/py/fieldz/msgImpl.py

import fieldz.fieldTypes as F
from fieldz.raw         import readFieldHdr, writeRawVarint, readRawVarint
from fieldz.typed       import *
from fieldz.msgSpec     import *

import fieldz.reg       as R

__all__ = ['makeMsgClass', 'makeFieldClass', ]

# -------------------------------------------------------------------
# METHODS USED AS COMPONENTS IN BUILDING CLASSES
# -------------------------------------------------------------------
def myName(self):               return self._name

def myPutter(self):
    return notImpl
def myGetter(self):
    return notImpl
def myLenFunc(self):
    print "DEBUG: myLenFunc invoked"
    return notImpl
def myPLenFunc(self):
    return notImpl

# specific to messages ----------------------------------------------
def myEnums(self):              return self._enums
def myMsgs(self):               return self._msgs
def myFieldClasses(self):       return self._fieldClasses

# specific to fields ------------------------------------------------
# FOR A GIVEN FIELD, THESE ARE CONSTANTS ASSIGNED BY makeFieldClass
def myFType(cls):               return cls._fType
def myQuantifier(cls):          return cls._quantifier
def myFieldNbr(cls):            return cls._fieldNbr
def myDefault(cls):             return cls._default

# these get and set the value attribute of the field instance; they
# have nothing to do with de/serialization to and from the channel
def myValueGetter(self):        return self._value
# XXX TYPE-SPECIFIC VALIDATION, COERCION:
def myValueSetter(self, value): self._value = value

# -------------------------------------------------------------------
# FIELD CLASS
# -------------------------------------------------------------------
class FieldImpl(object):
    """
    An abstract class intended to serve as parent to automatically
    generated classes whose purpose will be to ease user handling
    of data being sent or received across the wire.
    """

    __slots__ = [ '_value',]

    # should default precede value?  if a value is assigned, isn't that
    # a default?  In fact shouldn't the parameter list end with
    #   value=default?
    def __init__(self, value=None):
        # XXX NEED SOME VALIDATION
        self._value     = value

    def __eq__(self, other):
        if other is None:                           return False
        if self is other:                           return True
        if self._name != other._name:               return False
        if self._fType != other._fType:             return False
        if self._quantifier != other._quantifier:   return False
        if self._fieldNbr != other._fieldNbr:       return False
        # ignore defaults for now
        return True

    
class MetaField(type):

    def __new__(meta, name, bases, dct):
#       print "MetaField METACLASS NEW gets called once"
        return super(MetaField, meta).__new__(meta, name, bases, dct)

    def __init__(cls, name, bases, dct):
        super(MetaField, cls).__init__(name, bases, dct)
#       print "MetaField METACLASS INIT gets called once"

    def __call__(cls, *args, **kwargs):
#       print "MetaField CALL with args = %s" % str(args)
        return type.__call__(cls, *args, **kwargs)

# -------------------------------------------------------------------
# MESSAGE CLASS
# -------------------------------------------------------------------
class MsgImpl(object):
    """
    An abstract class intended to serve as parent to automatically
    generated classes whose purpose will be to ease user handling
    of data being sent or received across the wire.
    """

    __slots__ = [ '_fields' ,       # list of field instances
                  '_enums',         # nested enums
                  '_msgs',          # nested messages
                ]

    def __eq__(self, other):
        if other is None:                           return False
        if self is other:                           return True
        if self._name != other._name:               return False

#       print "MESSAGE NAMES THE SAME"              # DEBUG

        # -- compare fields -------------------------------
        if self._fields is None or other._fields is None:
            return False
#       print "SAME NUMBER OF FIELDS"               # DEBUG
        if len(self._fields) != len(other._fields): return False
        for i in range(len(self._fields)):
            if self._fields[i] != other._fields[i]: 
                # DEBUG
                print "MESSAGE FIELDS %d DIFFER" % i
                # END
                return False

#       print "FIELDS ARE THE SAME"                 # DEBUG

        # -- compare nested enums -------------------------
        if self._enums is None or other._enums is None:
            return False
        if len(self._enums) != len(other._enums): return False
        for i in range(len(self._enums)):
            if self._enums[i] != other._enums[i]: return False

        # -- compare nested msgs --------------------------
        if self._msgs is None or other._msgs is None:
            return False
        if len(self._msgs) != len(other._msgs): return False
        for i in range(len(self._msgs)):
            if self._msgs[i] != other._msgs[i]: return False
        
        return True

    def __len__(self):              return len(self._fields)
    def __getitem__(self, n):       return self._fields[n]

    def putter(self, chan):
        """
        Serialize the message into the channel and signal to the
        channel that it is to be sent.
        """

        # would prevent recursive handling of nested messages 
#       chan.position = 0

        # serialized message is preceded by a varint containing the 
        # message length (excluding the varint itself)
        msgLen = 0
        n = 0 # DEBUG
        for field in self._fields:
            # DEBUG
            print "ADDING FIELD %u (%s) OF TYPE %u CONTRIBUTION TO LEN " % (
                                                n, field.name, field.fType)
            n += 1
            # END

            # ---------------------------------------------------------
            # ERROR HERE if field is a list (Q_PLUS) of nested classses
            # ---------------------------------------------------------
            msgLen += tLenFuncs[ field.fType ] (field.value, field.fieldNbr)
        chan.position = writeRawVarint(chan.buffer, chan.position, msgLen)
        
        # XXX DEBUG
        print "MSG LEN IS %u; AFTER WRITING OFFSET IS %u" % (
                                                    msgLen, chan.position)

        # XXX This only makes sense for simple messages all of whose
        # fields are required and so have only a single instance
        for field in self._fields:      # these are instances with a value attr
        
            # CLASS-LEVEL SLOTS are '_name', '_fType', '_quantifier', 
            #                       '_fieldNbr', '_default',]
            # INSTANCE-LEVEL SLOT is '_value'

            fType   = field.fType
            value   = field.value
            fieldNbr= field.fieldNbr

            chan.position = tPutFuncs[fType](chan.buffer, chan.position,
                                             value, fieldNbr)
#           # DEBUG
#           print "WROTE FIELD %-10s: %s" % (field.name, value) 
#       print "AFTER WRITING ENTIRE MESSAGE OFFSET IS %d" % chan.position
#       # END

    @classmethod
    def getter(cls, chan):
        """
        Deserialize the message in the channel, creating an 
        instance of a subclass of the MsgImpl class.
        """
        # XXX PROBLEMS IF NESTED MESSAGE
        chan.position = 0
        (msgLen, chan.position) = readRawVarint(chan.buffer, chan.position)

        # DEBUG
        print "GET_FROM_CHAN: msgLen IS %u, OFFSET NOW %u" % (
                                                msgLen, chan.position)
        # END

        end = chan.position + msgLen
        fields = []
        values = []
        for fieldClass in cls._fieldClasses:

            fType   = fieldClass._fType
            fieldNbr= fieldClass._fieldNbr

            # read the field header
            (pType, nbr, chan.position) \
                            = readFieldHdr(chan.buffer, chan.position)
            # DEBUG      
            print "    GET_FROM_CHAN, FIELD %u, TYPE %u" % (fieldNbr, fType)
            # END
            if fieldNbr != nbr:
                raise RuntimeError("EXPECTED FIELD NBR %d, GOT %d" % (
                                                    fieldNbr, nbr))

            (value, chan.position) = tGetFuncs[fType](
                                        chan.buffer, chan.position)
            if chan.position > end:
                # A HACK: SHOULD RAISE EXCEPTION
                # raise RuntimeError("read beyond end of buffer")
                print "GET TAKES POSITION TO %d, BEYOND END OF BUFFER %d" % (
                        chan.position, end)
            fields.append( fieldClass(value) )      # XXXX WRONG TRACK
            values.append(value)
        # DEBUG
        print "AFTER COLLECTING %u FIELDS, OFFSET IS %u" % (
                                            len(fields), chan.position)
        # END

        # XXX SHOULD INSTANTIATE AND RETURN MSG CLASS
        return cls(values)

class MetaMessage(type):

    def __new__(meta, name, bases, dct):
        # DEBUG
#       print "METACLASS NEW gets called once"
        # END
        return super(MetaMessage, meta).__new__(meta, name, bases, dct)

    def __init__(cls, name, bases, dct):
        # definitely works:
        # setattr(cls, 'baz', '__init__ added to dictionary before super call')

        super(MetaMessage, cls).__init__(name, bases, dct)
#       print "METACLASS INIT gets called once"

    def __call__(cls, *args, **kwargs):
        """ 
        XXX At this time the only argument expected is a list of field 
        values.
        """
        cls._fields=[]
        # -----------------------------------------------------------
        # XXX THIS CANNOT HANDLE ANY QUANTIFICATION OTHER THAN REQUIRED
        # -----------------------------------------------------------
        values = args[0]
        for idx,val in enumerate(values):
            # DEBUG
            print "META_MESSAGE.__call__: idx = %u" % idx
            # END
            cls._fields.append( cls._fieldClasses[idx](val) )
#       print "  THERE ARE %u FIELDS SET" % len(cls._fields)    # DEBUG
        return type.__call__(cls, *args, **kwargs)

    # don't permit any new attributes to be added
    # XXX why do we need to do this given __slots__ list?
    def __setattr__(cls, attr, value):
        """ make the class more or less immutable """
        if attr not in dir(cls):
            raise AttributeError('cannot create attribute by assignment')
        return type.__setattr__(cls, attr, value)

# -------------------------------------------------------------------
# MAKERS
# -------------------------------------------------------------------

# EXPERIMENT: IMPLEMENTATION OF MESSAGE CLASS __init__
def msgInitter(cls, *args, **attrs):
    # We want to create instances of the respective fields and 
    # assign 'arg' to field 'idx'.  This means that field instances 
    # need to have been created before we get here
    
    # DEBUG
    print 'INITTER:'
    if args:
        for idx,arg in enumerate(args):
            print "  arg %u is '%s'" % (idx, str(arg))
    if attrs:
        for key,val in attrs.iteritems:
            print "  kwarg attr is '%s', value is '%s'" % (key, str(val))

    # END

    # XXX if msgInitter is dropped from the dictionary, I get an error at
    # line 249 in __call__, 
    #    return type.__call__(cls, *args, **kwargs)
    #  TypeError: object.__new__() takes no parameters
    # 
    pass

msgClsByQName   = {}    # PROTO_NAME . MSG_NAME => class
fieldClsByQName = {}    # PROTO_NAME . MSG_NAME . FIELD_NAME => class

# XXX could be renamed MsgClassFactory 
def makeMsgClass(protoName, msgSpec):
    if protoName is None:
        raise ValueError('protocol dotted name must be specified')
    if msgSpec is None:
        raise ValueError('msgSpec be specified')
    qualName = '%s.%s' % (protoName, msgSpec.name)

    # DEBUG
    print 'MAKE_MSG_CLASS for %s' % qualName
    # END
    if qualName in msgClsByQName:
        return msgClsByQName[qualName]

    # build list of field classes -----------------------------------
    fieldClasses        = []
    fieldClassesByName  = {}
    # XXX implicit assumption is that fields are ordered by ascending
    # XXX field number
    for fieldSpec in msgSpec:
        clz = makeFieldClass(protoName, msgSpec.name, fieldSpec) 
        fieldClasses.append(clz)
        fieldClassesByName[ '%s.%s.%s' % (
                    protoName, msgSpec.name, fieldSpec.name)] = clz

    # class is not in cache, so construct ---------------------------
    d = {}
    d['__init__']   = msgInitter
    d['__slots__']  = [ '_name', '_enums', 
                        '_msgs', '_fieldClasses', '_fieldsClassesByName',
                      ]

    # DEBUG
    if '__dict__' in dir(MsgSpec):
        print "MsgSpec CLASS DICTIONARY excluding __doc__"
        for key in MsgSpec.__dict__.keys():
            if key != '__doc__':
                print "    %-20s %s" % ( key, MsgSpec.__dict__[key])
    if '__dict__' in dir(msgSpec):
        print "msgSpec INSTANCE DICTIONARY excluding __doc__"
        for key in msgSpec.__dict__.keys():
            if key != '__doc__':
                print "    %-20s %s" % ( key, msgSpec.__dict__[key])
    # END

    # we want a property for each item in the slots list
    d['_name']      = msgSpec.name
    d['name']       = property(myName)
    d['_enums']     = []      # enums visible at all levels; shd be immutable
    d['enums']      = property(myEnums)
    d['_msgs']      = []      # nested msgs, visible at all levels
    d['msgs']       = property(myMsgs)
    d['_fieldClasses'] = fieldClasses
    d['fieldClasses']  = property(myFieldClasses)

    C = MetaMessage( msgSpec.name,  # name  MUST NOT BE UNICODE
                     (MsgImpl,),    # bases
                     d)             # dictionry

    #----------------------------
    # possibly some more fiddling ...
    #----------------------------

    msgClsByQName[qualName] = C
    return C

# -------------------------------------------------------------------
def makeFieldClass(protoName, msgName, fieldSpec):
    if protoName is None:       raise ValueError('null protocol name')
    if msgName is None:         raise ValueError('null message name')
    if fieldSpec is None:       raise ValueError('null field spec')
    qualName = '%s.%s.%s' % (protoName, msgName, fieldSpec.name)
    print 'MAKE_FIELD_CLASS for %s' % qualName      # DEBUG
    if qualName in fieldClsByQName:   return fieldClsByQName[qualName]

    # DEBUG
    # won't work if FieldSpec has __slots__
    if '__dict__' in dir(FieldSpec):
        print "FieldSpec CLASS DICTIONARY excluding __doc__"
        for key in FieldSpec.__dict__.keys():
            if key != '__doc__':
                print "    %-20s %s" % ( key, FieldSpec.__dict__[key])
        print "fieldSpec INSTANCE DICTIONARY excluding __doc__"

    if '__dict__' in dir(fieldSpec):
        for key in fieldSpec.__dict__.keys():
            if key != '__doc__':
                print "    %-20s %s" % ( key, fieldSpec.__dict__[key])
    # END

    d = {}

    # XXX DISABLE __slots__ FOR DEBUGGING
    d['__slots__'] = ['_name', '_fType', '_quantifier',
                      '_fieldNbr', '_default',]

    # we want an attribute and a property for each fieldSpec attr
    d['_name']      = fieldSpec.name
    d['name']       = property(myName)
    d['_fType']     = fieldSpec.fTypeNdx
    d['fType']      = property(myFType)
    d['_quantifier']= fieldSpec.quantifier
    d['quantifier'] = property(myQuantifier)
    d['_fieldNbr']  = fieldSpec.fieldNbr
    d['fieldNbr']   = property(myFieldNbr)
    d['_default']   = fieldSpec.default
    d['default']    = property(myDefault)
    d['_default']   = fieldSpec.default
    d['default']    = property(myDefault)

    # this needs to be elaborated as appropriate to deal with the
    # 18 or so field types
    d['value']      = property(myValueGetter, myValueSetter)

    M = MetaField( str(fieldSpec.name),  # name
                     (FieldImpl,),  # bases
                     d)             # dictionry

    #----------------------------
    # possibly some more fiddling ...
    #----------------------------
    
    fieldClsByQName[qualName] = M
    return M


#!/usr/bin/python

# testPzogProto.py
import StringIO, time, unittest

from rnglib         import SimpleRNG
from ringDataProto  import RING_DATA_PROTO_SPEC

from fieldz.parser import StringProtoSpecParser
import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T

class TestPzogProto (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################

    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################
    def testPzogProto(self):
        # MODEL: testProtoSpec XXX
        data = StringIO.StringIO(RING_DATA_PROTO_SPEC)
        p    = StringProtoSpecParser(data)   
        sOM  = p.parse()             # object model from string serialization
        self.assertIsNotNone(sOM)
        self.assertTrue(isinstance(sOM, M.ProtoSpec))
        self.assertEquals( 'org.xlattice.pzog.ringData', sOM.name )
        self.assertEquals(0, len(sOM.enums) )
        # XXX FAILS: 
        # self.assertEquals(2, len(sOM.msgs) )
        self.assertEquals(1, len(sOM.msgs) )        # THIS IS WRONG
        self.assertEquals(0, len(sOM.seqs) )

        # FIRST MESSAGE SPEC ----------------------------------------
        msgSpec = sOM.msgs[0]
        self.assertEquals(msgSpec.fName(0),     'hostName')   
        self.assertEquals(msgSpec.fTypeName(0), 'lString')
        self.assertEquals(msgSpec.fName(1),     'ipAddr')   
        self.assertEquals(msgSpec.fTypeName(1), 'lString')
        self.assertEquals(msgSpec.fName(2),     'nodeID')   
        self.assertEquals(msgSpec.fTypeName(2), 'fBytes32')
        self.assertEquals(msgSpec.fName(3),     'pubKey')   
        self.assertEquals(msgSpec.fTypeName(3), 'lString')
        self.assertEquals(msgSpec.fName(4),     'privateKey')   
        self.assertEquals(msgSpec.fTypeName(4), 'lString')
        try:
            msgSpec.fName(5)
            self.fail('did not catch reference to non-existent field')
        except IndexError as ie:
            pass


        # SECOND MESSAGE SPEC ---------------------------------------
        # PARSE OF SECOND MESSAGE SPEC FAILS WITH
        #   DEBUG: NOT A FIELD DECL: 'message ringData:'

        # XXX STUB XXX

if __name__ == '__main__':
    unittest.main()

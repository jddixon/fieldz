# fieldz/msgSpec.py

import re, sys

from fieldz.raw     import *
from fieldz.typed   import *

import fieldz.fieldTypes    as F
import fieldz.coreTypes     as C

__all__ = [  \
            # constants, so to speak: quantifiers
            'Q_REQUIRED',   # no quantifier, so one and only one such field
            'Q_OPTIONAL',   # ?: either zero or one instance of the field
            'Q_STAR',       # *: zero or more instances of the field allowed
            'Q_PLUS',       # +: one or more instances of the field

            # methods
            'qName',        'validateSimpleName',   'validateDottedName',

            # class-level
            'cPutFuncs', 'cGetFuncs', 'cLenFuncs',

            'enumPairSpecPutter',   'enumSpecPutter',   'fieldSpecPutter',
            'msgSpecPutter',        'seqSpecPutter',    'protoSpecPutter',

            'enumPairSpecGetter',   'enumSpecGetter',   'fieldSpecGetter',
            'msgSpecGetter',        'seqSpecGetter',    'protoSpecGetter',

            'enumPairSpecLen',      'enumSpecLen',      'fieldSpecLen',
            'msgSpecLen',           'seqSpecLen',       'protoSpecLen',

            # classes
            'EnumPairSpec',
            'EnumSpec',             'FieldSpec',            'MsgSpec',
            'ProtoSpec',            'SeqSpec',
            #'StringMsgSpecParser',
            #'WireMsgSpecParser',    'WireMsgSpecWriter',
          ]

Q_REQUIRED  = 0
Q_OPTIONAL  = 1
Q_STAR      = 2
Q_PLUS      = 3

Q_NAMES     = ['', '?', '*', '+',]
def qName(n):
    if n < 0 or n >= len(Q_NAMES):
        raise ValueError('does not map to a valid quantifier: %s' % str(n))
    return Q_NAMES[n]

# base names, forming part of a larger pattern
_VALID_NAME_PAT = "[a-zA-Z_][a-zA-Z_0-9]*"
_VALID_NAME_RE  = re.compile(_VALID_NAME_PAT)

# just base names; match will fail if any further characters follow
_VALID_SIMPLE_NAME_PAT = _VALID_NAME_PAT + '$'
_VALID_SIMPLE_NAME_RE  = re.compile(_VALID_SIMPLE_NAME_PAT)

def validateSimpleName(s):
    m = _VALID_SIMPLE_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid simple name '%s'" % s)

# both protocol names and field names can be qualified
_VALID_DOTTED_NAME_PAT = _VALID_NAME_PAT + '(\.' + _VALID_NAME_PAT + ')*$'
_VALID_DOTTED_NAME_RE  = re.compile(_VALID_DOTTED_NAME_PAT)

def validateDottedName(s):
    m = _VALID_DOTTED_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid (optionally dotted) name '%s'" % s)


# -- CLASSES --------------------------------------------------------
class EnumPairSpec(object):
    __slots__ = ['_symbol', '_value',]
    def __init__(self, symbol, value):
        validateSimpleName(symbol)
        self._symbol    = symbol
        self._value     = int(value)

    @property
    def symbol(self):           return self._symbol
    @property
    def value(self):            return self._value

    def __eq__(self, other):
        if other is None or not isinstance(other, EnumPairSpec):
            print 'XXX None or not EnumPairSpec'
            return False
        if (self._symbol != other._symbol) or (self._value  != other._value):
            print 'XXX symbol or value differs'
            return False
#       print 'XXX pairs match'
#       print "  my    self:  %s" % self
#       print "  other other: %s" % other
        return True

    def indentedStr(self, indent='', step=''):
        return "%s%s = %d\n" % (indent, self._symbol, self._value)

    def __str__(self):
        """ return a usable representation of the EnumPairSpec """
        return self.indentedStr('    ')

    def __repr__(self):
        """ return the EnumPairSpec in today's notion of the canonical form """
        return self.indentedStr(' ')

class EnumSpec(object):
    """
    For our purposes an enum is a named list of simple names (names
    containing no delimiters)` and a map from such names to their
    non-negative integer values.
    """
    __slots__ = ['_name', '_pairs', '_sym2pair', ]
    def __init__(self, name, pairs):
        """pairs are EnumPairSpecs """
        validateDottedName(name)
        self._name = name
        if pairs is None:
            raise ValueError('null list of enum pairs')
        if len(pairs) == 0:
            raise ValueError('empty list of enum pairs')
        self._pairs     = []
        self._sym2pair  = {}
        for pair in pairs:
            sym = pair.symbol
            val = pair.value
            if sym in self._sym2pair:
                raise ValueError("already in EnumSpec: '%s'" % sym)
            self._pairs.append(pair)
            self._sym2pair[sym] = pair

    @classmethod
    def create (cls, name, pairs):
        """pairs are 2-tuples, (symbol, value), where value is uInt16 """
        validateDottedName(name)
        if pairs is None:
            raise ValueError('null list of enum pairs')
        if len(pairs) == 0:
            raise ValueError('empty list of enum pairs')

        _pairs = []
        for pair in pairs:
            sym = pair[0]
            val = pair[1]
            p   = EnumPairSpec(sym, val)
            _pairs.append(p)
        return EnumSpec(name, _pairs)

    def value(self, s):
        """ map a name to the corresponding value """
        return self._sym2pair[s].value

    @property
    def name(self):     return self._name

    # def pair(self, k):
    def __getitem__(self, k):
        return self._pairs[k]

    def __len__(self):     return len(self._pairs)

    def __eq__(self, other):
        # print "ENUM_SPEC COMPARISON"
        if other is None or not isinstance(other, EnumSpec):
            return False
        if other is self:
            return True
        if other._name != self._name:
            return False
        if len(self._pairs) != len(other._pairs):
            return False

        # print "  ENUM LENGTHS match"
        for i in range(self.__len__()):
            #if self[i] != other[i]:
            if self[i].symbol != other[i].symbol or \
                    self[i].value != other[i].value:
                print "ENUM_PAIR_SPECS DIFFER:"
                print "  my    pair %u: %s" % (i, self[i])
                print "  other pair %u: %s" % (i, other[i])
                return False
        return True

    def indentedStr(self, indent='', step=''):
        s = []
        s.append('%senum %s\n' %  (indent, self.name))
        for pair in self._pairs:
            s.append( pair.indentedStr(indent + step, step))
        return ''.join(s)

    def __str__(self):
        """ return a usable representation of the EnumSpec """
        return self.indentedStr('', '    ')

    def __repr__(self):
        """ return the EnumSpec in today's notion of the canonical form """
        return self.indentedStr('', ' ')


class FieldSpec(object):
    __slots__ = [ '_name', '_type', '_quantifier', '_fieldNbr', '_default', ]

    def __eq__(self, other):
        if other is None or not isinstance(other, FieldSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
        if other._name != self._name:
            return False
        if other._type != self._type:
            return False
        if other._quantifier != self._quantifier:
            return False
        if self._fieldNbr:
            if other._fieldNbr is None:
                return False
            if self._fieldNbr != other._fieldNbr:
                return False

        # XXX IGNORE DEFAULTS FOR NOW

        return True


    def __init__(self, name, fType, quantifier=Q_REQUIRED,
                                        fieldNbr=-1, default=None):
        # -- name ---------------------------------------------------
        if name is None:
            raise ValueError('no field name specified')
        validateDottedName(name)
        self._name = name

        # -- fType --------------------------------------------------
        # XXX TEMPORARILY DISABLED - 
#       if fType < 0 or fType > F.maxNdx:
#           raise ValueError("invalid fType '%s'" % str(fType))
        self._type = fType

        # -- quantifier ---------------------------------------------
        # XXX BAD RANGE CHECK
        if quantifier < 0 or quantifier > Q_PLUS:
            raise ValueError("invalid quantifier '%s'" % str(quantifier))
        self._quantifier = quantifier

        # -- fieldNbr -----------------------------------------------
        self._fieldNbr = int(fieldNbr)

        # -- default ------------------------------------------------
        # if default is None, could provide a default appropriate for the type
        # XXXif we are going to support a default value, it needs to be
        #   validated
        # XXX STUB
        if default is not None:
            raise NotImplementedError('default for FieldSpec')
        self._default = default

    @property
    def name(self):         return self._name

    # XXX return a string value
    @property
    def fTypeName(self):    
        return F.asStr(self._type)

    # XXX return a number
    @property
    def fTypeNdx(self):     return self._type

    @property
    def quantifier(self):   return self._quantifier
    #def quantifier(self):   return Q_NAMES[self._quantifier]

    @property
    def fieldNbr(self):
        return self._fieldNbr
    @fieldNbr.setter
    def fieldNbr(self, value):
        v = int(value)
        if v < 0:
            raise ValueError('field number may not be negative')
        self._fieldNbr = v

    @property
    def default(self):      return self._default

    def indentedStr(self, indent, step):
        s = []
        s.append('%s%s ' % (indent, self._name))

        tName = self.fTypeName
        if self._quantifier != Q_REQUIRED:
            tName += qName(self._quantifier)
        s.append('%s ' % tName)               # at least one space

        if self._fieldNbr is not None:
            s.append('@%d ' % self._fieldNbr)  # again, at least one space

        #========================
        # XXX default not handled
        #========================
        s.append('\n')

        return '' . join(s)

    def __str__(self):
        """ return a prettier representation of the FieldSpec """
        return self.indentedStr('', '    ')

    def __repr__(self):
        """
        Return the FieldSpec in today's notion of the canonical form.
        This doesn't have to be pretty, just absolutely clear and
        unambiguous.
        """
        return self.indentedStr('', ' ')

class MsgSpec(object):
    """
    A message is specified as an acceptable sequence of typed fields.
    Each field has a zero-based index (field number), a name, and a type.
    Later it will have a default value.

    Serialized, a message spec begins with the name of the message,
    which is a lenPlus string; this must be either a simple name
    containing no delimiters or it may be a sequence of simple names
    separated by dots ('.').  This is followed by individual field
    specs, each of which is a lenPlus names followed by colon (':')
    followed by a fieldType.

    """
    __slots__ = ['_name', '_fields', '_enums', '_msgs',
                 '_lastFieldNbr',           # must increase monotonically
                 'fieldNameToNdx', 
                 '_parent', '_reg', 
                 '_fieldNdx',                    # zero-based field index
                 ]

    def __init__(self, name, parent, reg):
        
        # XXX NEEDS CLEANUP

#       # -- protocol -----------------------------------------------
#       if protocol is None:
#           raise ValueError('missing protocol declaration')
#       validateDottedName(protocol)
#       self._protocol = protocol

        if name is None:
            raise ValueError('missing MsgSpec name')
        validateSimpleName(name)
        self._name = name

        if parent is None:
            raise ValueError('parent must be specified')
        self._parent = parent
        parent.addMsg(self)

        if reg is None:
            raise ValueError('MsgReg must be specified')
        self._reg = reg

        self._enums = []
        self._msgs  = []

        self._fields        = []
        self._lastFieldNbr  = -1
        self.fieldNameToNdx = {}    # XXX value?
        self._fieldNdx      = 0     # zero-based index of field in MsgSpec

    @property
    def reg(self):          return self._reg            # this protocol's reg
    
    def addField(self, f):
        fName = f.name
        if not isinstance(f, FieldSpec):
            raise ValueError("'%s' is not a FieldSpec!" % fName)
        if fName in self.fieldNameToNdx:
            raise KeyError("field named %s already exists" % fName)
        if f.fieldNbr < 0:
            self._lastFieldNbr += 1
            f.fieldNbr = self._lastFieldNbr
        elif f.fieldNbr <= self._lastFieldNbr:
            raise ValueError(
                "field number is %d not greater than last %d" % (
                                    f.fieldNbr, self._lastFieldNbr))
        else:
            self._lastFieldNbr      = f.fieldNbr
        self._fields.append(f)
        self.fieldNameToNdx[fName]  = self._fieldNdx
        self._fieldNdx             += 1         # so this is a count of fields

    def getRegIDForName(self, name):
        """ 
        If the name is in use, raise an exception.  Otherwise, return 
        the next free regID.
        """
        
        # THIS LOGIC DOESN'T PERMIT FULLY RECURSIVE STRUCTURE

        # XXX THIS IS NONSENSE: there is no MsgSpec._byName

        if name in self._byName or name in self.parent._byName:
            raise RuntimeError("name '%s' is already in use" % name)

        # XXX STUB XXX GET THE NEXT FREE regID

    def addEnum(self, e):
        # should validate AND check for uniqueness
        
        # DEBUG
        name = e.name
        print "ADDING ENUM %s TO PROTOSPEC" % name
        # END

        # WORKING HERE
        self._enums.append(e)

    def addMsg(self, m):
        # should validate AND check for uniqueness
        self._msgs.append(m)

    @property
    def name(self):         return self._name
    @property
    def parent(self):       return self._parent

    def __len__(self):      return len(self._fields)

    def __getitem__(self, k):
        return self._fields[k]

    def fName(self, i):
        if i < 0 or i > self.__len__():
            raise ValueError('field number out of range')
        return self._fields[i].name

    def fTypeName(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self.__len__():
            raise ValueError('field number out of range')
        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeName

    def fTypeNdx(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self.__len__():
            raise ValueError('field number out of range')

        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeNdx

    def fDefault(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self.__len__():
            raise ValueError('field number out of range')
        return self._fields[i].default

    @property
    def enums(self):                return self._enums

    # -- serialization ----------------------------------------------
    def __eq__(self, other):
        if other is None or not isinstance(other, MsgSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
#       if other._protocol != self._protocol:
#           return False
        if other._name != self._name:
            return False
        if self.__len__() == 0 or other.__len__() == 0:
            return False
        if self.__len__() != other.__len__():
            return False
        for n in range(self.__len__()):
            if not self._fields[n].__eq__(other._fields[n]):
                return False
        return True

    def indentedStr(self, indent, step):
        s = []
        # s.append( "%sprotocol %s\n\n" % (indent, self._protocol))
        s.append( "%smessage %s\n"    % (indent, self._name))
        if self._enums is not None:
            for e in self._enums:
                s.append( e.indentedStr(indent + step, step) )
        if self._msgs is not None:
            for m in self._msgs:
                s.append( m.indentedStr(indent + step, step) )
        for f in self._fields:
            s.append( f.indentedStr(indent + step, step) )
        return ''.join(s)

    def __str__(self):
        """ return string representation in perhaps prettier format """
        return self.indentedStr('', '    ')

    def __repr__(self):
        """ return string representation in canonical format """
        return self.indentedStr('', ' ')

class SeqSpec(object):
    """

    """
    def __init__(self):
        pass
        # XXX STUB

    def indentedStr(self, indent, step):
        raise NotImplementedError('indentedStr for SeqSpec')

    def __str__(self):
        return self.indentedStr('', '    ')

    def __repr__(self):
        return self.indentedStr('', ' ')

class ProtoSpec(object):
    """
    A protocol is a set of message types, enumerations, and acceptable
    message sequences.  It is essential for our purposes that any
    protocol can be constructed dynamically from its wire serialization.
    """

    __slots__   = [ '_name', '_enums', '_msgs', '_seqs', '_nodeReg', '_reg',]

    def __init__(self, name, reg):
        if name is None:
            raise ValueError('missing protocol name')
        validateDottedName(name)
        self._name      = name

        if reg is None:
            raise ValueError('proto reg must be specified')
        self._reg       = reg
        self._nodeReg   = reg.nodeReg       # parent XXX REDUNDANT

        self._enums     = []
        self._msgs      = []
        self._seqs      = []                # XXX NOT YET SUPPORTED


    def addEnum(self, e):
        # should validate AND check for uniqueness
        self._enums.append(e)

    def addMsg(self, m):
        # should validate AND check for uniqueness
        self._msgs.append(m)

    def addSeq(self, s):
        # should validate AND check for uniqueness
        self._seqs.append(s)

    # XXX we should make iterators available instead
    @property
    def enums(self):        return self._enums
    @property
    def msgs(self):         return self._msgs
    @property
    def seqs(self):         return self._seqs

    @property
    def nodeReg(self):      return self._nodeReg        # parent registry
    @property
    def reg(self):          return self._reg            # this protocol's reg

    @property
    def name(self):         return self._name

    def __eq__(self, other):
        if other is None:                               return False
        if other is self:                               return True
        if self._name != other._name:                   return False

        #------------------------------------------------------------
        # XXX THESE THREE SETS OF TESTS NEED REVISITING, because
        # if any of {self,other}._{enums,msgs,seqs} is None, it
        # should be treated as though it were [].
        # I have changed the constructor to automatically replace
        # None with [].  Does this solve the problem?
        #------------------------------------------------------------
        if self._enums is None:
            if other._enums is not None:                return False
        else:
            if other._enums is None:                    return False
            n = len(self._enums)
            if n != len(other._enums):                  return False
            for i in range(n):
                # XXX DOES NOT WORK AS EXPECTED
                #if self._enums[i] != other._enums[i]:   return False
                if not self._enums[i].__eq__(other._enums[i]):   return False

        if self._msgs is None:
            if other._msgs is not None:                 return False
        else:
            if other._msgs is None:                     return False
            n = len(self._msgs)
            if n != len(other._msgs):                   return False
            for i in range(n):
                if not self._msgs[i].__eq__(other._msgs[i]):
                    return False

        if self._seqs is None:
            if other._seqs is not None:
                return False
        else:
            if other._seqs is None:                     return False
            n = len(self._seqs)
            if n != len(other._seqs):                   return False
            for i in range(n):
                if self._seqs[i] != other._seqs[i]:     return False

        return True

    def indentedStr(self, indent='', step=' '):
        s = []
        s.append( "%sprotocol %s\n" % (indent, self._name) )
        if self._enums is not None:
            for e in self._enums:
                s.append( e.indentedStr(indent, step) )
        if self._msgs is not None:
            for m in self._msgs:
                s.append( m.indentedStr(indent, step) )
        if self._seqs is not None:
            for q in self._seqs:
                s.append( q.indentedStr(indent, step) )

        return ''.join(s)

    def __str__(self):
        return self.indentedStr('', '    ')

    def __repr__(self):
        return self.indentedStr('', ' ')

# DISPATCH TABLES ===================================================

# XXX dunno why notImpl is not picked up by
#                                          from fieldz.typed import *
def notImpl(*arg):     raise NotImplementedError

cPutFuncs  = [notImpl]*(C.maxNdx + 1)
cGetFuncs  = [notImpl]*(C.maxNdx + 1)
cLenFuncs  = [notImpl]*(C.maxNdx + 1)
cPLenFuncs = [notImpl]*(C.maxNdx + 1)

# PUTTERS, GETTERS, LEN FUNCS ---------------------------------------

lStringLen = tLenFuncs[F._L_STRING]
lStringPut = tPutFuncs[F._L_STRING]
vuInt32Len = tLenFuncs[F._V_UINT32]
vuInt32Put = tPutFuncs[F._V_UINT32]
vEnumGet   = tGetFuncs[F._V_ENUM]
vEnumLen   = tLenFuncs[F._V_ENUM]
vEnumPut   = tPutFuncs[F._V_ENUM]

# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# LEN PARAMETERS MUST BE (val, n), where n is the field number
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

def enumPairSpecLen(val, n):
    """
    val is guaranteed to be a well-formed EnumPair object; this is
    the length of the spec on the wire, what is written before the spec.
    Returns a 2-tuple containing first the byte count and then that plus
    the header lengths.
    """
    return lStringLen(val.symbol, n) + vuInt32Len(val.value, n)

def enumPairSpecPrefixedLen(val, n):
    """
    val is guaranteed to be a well-formed EnumPair object; this is
    the length of the spec on the wire, what is written before the spec.
    Returns a 2-tuple containing first the byte count and then that plus
    the header lengths.
    """
    h = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    byteCount = enumPairSpecLen(val, n)
    return h + lengthAsVarint(byteCount) + byteCount

# val = instance of the type, n = field number
def enumPairSpecPutter(buf, pos, val, n):
    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = enumPairSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
#   print "AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write field 0, the symbol
    pos = lStringPut( buf, pos, val.symbol, 0 )
#   print "AFTER WRITING SYMBOL %s pos = %u" % ( val.symbol, pos)

    # write field 1, the value
    pos = vuInt32Put( buf, pos, val.value,  1 )
#   print "AFTER WRITING VALUE %u pos = %u" % (val.value, pos)
    return pos

def enumPairSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount           # XXX should use for validation

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    sym = str(s)                        # convert bytearray to str

    # read field 1
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (val,pos) = readRawVarint(buf, pos)

    # construct the EnumPairSpec object from field values
    obj = EnumPairSpec(sym, val)
    return (obj, pos)

cLenFuncs[C._ENUM_PAIR_SPEC]    = enumPairSpecLen
cPLenFuncs[C._ENUM_PAIR_SPEC]   = enumPairSpecPrefixedLen
cPutFuncs[C._ENUM_PAIR_SPEC]    = enumPairSpecPutter
cGetFuncs[C._ENUM_PAIR_SPEC]    = enumPairSpecGetter

# ---------------------------------------------------------
def enumSpecLen(val, n):
    # val is guaranteed to be a well-formed EnumSpec object

    count   = lStringLen(val.name, 0)               # field 0 contribution
    for pair in val:
        count += enumPairSpecPrefixedLen(pair, 1)   # field 1 contribution(s)
    return count

def enumSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed EnumSpec object

    # we are going to write the header, then a byte count, then the enum
    # name, then one or more EnumPairSpecs
    h       = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    count   = enumSpecLen(val, n)
    return h + lengthAsVarint(count) + count

def enumSpecPutter(buf, pos, val, n):
    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = enumSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
#   print "AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write the enum's name
    pos = lStringPut(buf, pos, val.name, 0)             # field 0

    # write the pairs
    for pair in val:
        pos = enumPairSpecPutter(buf, pos, pair, 1)   # field 1 instances

    return pos

def enumSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount           # XXX should use for validation

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    name = str(s)                        # convert bytearray to str

    # read instances of field 1: should enforce the + quantifier here
    pairs = []
    while pos < end:
        (hdr, pos0) = readRawVarint(buf, pos)
        if hdrFieldNbr(hdr) != 1:
            # XXX SHOULD COMPLAIN IF WRONG HEADER
            # XXX This is a a peek: pos only gets advanced if OK
            print "EXPECTED FIELD 1, FOUND %s" % hdrFieldNbr(hdr)
            break
        (e,pos) = enumPairSpecGetter(buf, pos0)
        pairs.append(e)

    # create EnumSpec instance, which gets returned
    val = EnumSpec(name, pairs)
    return (val, pos)

cLenFuncs[C._ENUM_SPEC]     = enumSpecLen
cPLenFuncs[C._ENUM_SPEC]    = enumSpecPrefixedLen
cPutFuncs[C._ENUM_SPEC]     = enumSpecPutter
cGetFuncs[C._ENUM_SPEC]     = enumSpecGetter

# ---------------------------------------------------------
def fieldSpecLen(val, n):
    # val is guaranteed to be a well-formed fieldSpec object
    # fields are '_name', '_type', '_quantifier', '_fieldNbr', '_default'

    count   = lStringLen(val.name,      0)      # field 0 contribution
    count  += vEnumLen(val.fTypeNdx,    1)
    count  += vEnumLen(val.quantifier,  2)
    count  += vuInt32Len(val.fieldNbr,  3)
    if val.default is not None:
        # TYPE OF DEFAULT VALUE MUST MATCH val.fType
        pass
    return count

def fieldSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed fieldSpec object
    h       = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    count   = fieldSpecLen(val, n)
    return h + lengthAsVarint(count) + count

def fieldSpecPutter(buf, pos, val, n):
    # fields are '_name', '_type', '_quantifier', '_fieldNbr', '_default'

    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "FIELD SPEC: AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = fieldSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
#   print "FIELD SPEC: AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write the field's name
    pos = lStringPut(buf, pos, val.name, 0)             # field 0

    # write the type
    pos = vEnumPut(buf, pos, val.fTypeNdx, 1)

    # write the quantifier
    pos = vEnumPut(buf, pos, val.quantifier, 2)

    # write the field number
    pos = vuInt32Put(buf, pos, val.fieldNbr, 3)

    # write the default, should there be one
    if val.default is not None:
        # XXX STUB XXX
        pass

    return pos

def fieldSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    name = str(s)                        # convert bytearray to str

    # read field 1
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (fType, pos) = vEnumGet(buf, pos)

    # read field 2
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (quant, pos) = vEnumGet(buf, pos)

    # read field 3
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (fNbr, pos) = vEnumGet(buf, pos)

    # XXX IGNORING DEFAULT
    default = None
    val = FieldSpec(name, fType, quant, fNbr, default)

    return (val, pos)

cLenFuncs[C._FIELD_SPEC]    = fieldSpecLen
cPLenFuncs[C._FIELD_SPEC]   = fieldSpecPrefixedLen
cPutFuncs[C._FIELD_SPEC]    = fieldSpecPutter
cGetFuncs[C._FIELD_SPEC]    = fieldSpecGetter

# ---------------------------------------------------------
def msgSpecLen(val, n):
    # val is guaranteed to be a well-formed msgSpec object
    # fields are  protocol, name, fields, enum=None

    count  = lStringLen(val.name, 0)                # field 0, name
    for field in val:
        count += fieldSpecPrefixedLen(field, 1)     # field 1, fields
    if val.enums is not None and val.enums != []:
        for enum in val.enums:
            count += enumSpecPrefixedLen(enum, 2)   # field 2, optional enums
    return count

def msgSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed msgSpec object
    h       = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    count   = msgSpecLen(val, n)
    return h + lengthAsVarint(count) + count

def msgSpecPutter(buf, pos, val, n):
    # fields are  protocol, name, fields, enum=None

    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
    print "MSG SPEC: AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = msgSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
    print "MSG SPEC: AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write the spec's name
    pos = lStringPut(buf, pos, val.name, 0)                 # field 0

    # write the fields
    for field in val:
        pos = fieldSpecPutter(buf, pos, field, 1)          # field 1 instances

    # write the enum, should there be one
    if val.enums is not None and val.enums != []:
        for enum in val.enums:
            pos = enumSpecPutter(buf, pos, enum, 2)         # yup, field 2

    return pos

def msgSpecGetter(buf, pos):
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount

#   # read field 0
#   (hdr, pos) = readRawVarint(buf, pos)
#   # SHOULD COMPLAIN IF WRONG HEADER
#   (s, pos) = readRawLenPlus(buf, pos)
#   protocol = str(s)                       # convert bytearray to str

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    name = str(s)                           # convert bytearray to str

    # read instances of field 1: should enforce the + quantifier here
    fields = []
    while pos < end:
        (hdr, pos0) = readRawVarint(buf, pos)
        if hdrFieldNbr(hdr) != 1:
            # XXX SHOULD COMPLAIN IF WRONG HEADER
            # XXX This is a a peek: pos only gets advanced if OK
            print "EXPECTED FIELD 1, FOUND %s" % hdrFieldNbr(hdr)
            break
        (f,pos) = fieldSpecGetter(buf, pos0)
        fields.append(f)

    # we may have multiple enums
    enums = []
    while pos < end:
        (hdr, pos0) = readRawVarint(buf, pos)
        if hdrFieldNbr(hdr) != 2:
            print "EXPECTED FIELD 2, FOUND %s" % hdrFieldNbr(hdr)
            break
        (enum, pos) = enumSpecGetter(buf, pos0)
        enums.append(enum)

    val = MsgSpec(name, fields, enums)

    return (val, pos)

cLenFuncs[C._MSG_SPEC] = msgSpecLen
cPLenFuncs[C._MSG_SPEC] = msgSpecPrefixedLen
cPutFuncs[C._MSG_SPEC] = msgSpecPutter
cGetFuncs[C._MSG_SPEC] = msgSpecGetter

# ---------------------------------------------------------
def seqSpecLen(val, n):
    # val is guaranteed to be a well-formed seqSpec object
    pass

def seqSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed seqSpec object
    pass

def seqSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def seqSpecGetter(buf, pos):
     # STUB
     return (val, pos)

cLenFuncs[C._SEQ_SPEC] = seqSpecLen
cPLenFuncs[C._SEQ_SPEC] = seqSpecPrefixedLen
cPutFuncs[C._SEQ_SPEC] = seqSpecPutter
cGetFuncs[C._SEQ_SPEC] = seqSpecGetter

# ---------------------------------------------------------
def protoSpecLen(val, n):
    # val is guaranteed to be a well-formed protoSpec object
    pass

def protoSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed protoSpec object
    pass

def protoSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def protoSpecGetter(buf, pos):
     # STUB
     return (val, pos)              # END DISPATCH TABLES

cLenFuncs[C._PROTO_SPEC] = protoSpecLen
cPLenFuncs[C._PROTO_SPEC] = protoSpecPrefixedLen
cPutFuncs[C._PROTO_SPEC] = protoSpecPutter
cGetFuncs[C._PROTO_SPEC] = protoSpecGetter


#!/usr/bin/python

# testLogEntry.py
import time, unittest

from rnglib         import SimpleRNG
import fieldz.typed         as T
import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.reg           as R
from fieldz.tfbuffer    import *

# -- logEntry msgSpec ---------------------------
protocol= 'org.xlattice.upax'
name    = 'logEntry'
enum    = M.EnumSpec.create('foo', [('not',0), ('being',1), ('used',2),])
fields  = [ \
        M.FieldSpec('timestamp', F._F_UINT32,   M.Q_REQUIRED, 0),
        M.FieldSpec('nodeID',    F._F_BYTES20,  M.Q_REQUIRED, 1),
        M.FieldSpec('key',       F._F_BYTES20,  M.Q_REQUIRED, 2),
        M.FieldSpec('by',        F._L_STRING,   M.Q_REQUIRED, 3),
        M.FieldSpec('path',      F._L_STRING,   M.Q_REQUIRED, 4),
]
nodeReg         = R.NodeReg()
protoReg        = R.ProtoReg(protocol, nodeReg)
msgReg          = R.MsgReg(protoReg)
leMsgSpec       = M.MsgSpec(name, protoReg, msgReg)
for f in fields:
    leMsgSpec.addField(f)
upaxProtoSpec   = M.ProtoSpec(protocol, protoReg)
upaxProtoSpec.addEnum(enum)
upaxProtoSpec.addMsg(leMsgSpec)

# -- end logEntry msgSpec -----------------------

class TestLogEntry (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpWireBuffer (self, wb):
        for i in range(16):
            print "0x%02x " % wb.buf[i],
        print

    # actual unit tests #############################################
    def testProtoSpec(self):
        self.assertIsNotNone(nodeReg)
        self.assertIsNotNone(protoReg)

    def testConstructors(self):
        pSpec = upaxProtoSpec
        self.assertEquals(protocol,     pSpec.name)
        self.assertEquals(enum,         pSpec.enums[0])
        self.assertEquals(leMsgSpec,    pSpec.msgs[0])
        self.assertEquals(0,            len(pSpec.seqs))

    def testWritingAndReading(self):
        BUFSIZE = 16*1024
        writer  = TFWriter.create(leMsgSpec, BUFSIZE)
        buf     = writer.buffer
        reader  = TFReader(leMsgSpec, BUFSIZE, buf) # reader and writer share same buffer

        t       = int(time.time())
        nodeID  = bytearray(20)         # 160 bit
        self.rng.nextBytes(nodeID)           #        .... random value
        key     = bytearray(20)         # 160 bit
        self.rng.nextBytes(key)              #        .... random value
        by      = self.rng.nextFileName(16)
        path    = 'path/to/' + self.rng.nextFileName(16)

        n = 0                           # 0-based field number
        # write a log entry into the buffer
        writer.putNext(n, t);           n = n + 1
        writer.putNext(n, nodeID);      n = n + 1
        writer.putNext(n, key);         n = n + 1
        writer.putNext(n, by);          n = n + 1
        writer.putNext(n, path)

        # now read the buffer to see what actually was written
        self.assertEquals(0,            reader.position)

        reader.getNext()
        self.assertEquals(0,            reader.fieldNbr)
        self.assertEquals('fuInt32',    F.asStr(reader.fType))
        self.assertEquals(t,            reader.value) 
        self.assertEquals(5,            reader.position)

        reader.getNext()
        self.assertEquals(1,            reader.fieldNbr)
        self.assertEquals('fBytes20',   F.asStr(reader.fType))
        self.assertEquals(nodeID,       reader.value)
        self.assertEquals(26,           reader.position)

        reader.getNext()
        self.assertEquals(2,            reader.fieldNbr)
        self.assertEquals('fBytes20',   F.asStr(reader.fType))
        self.assertEquals(key,          reader.value)
        self.assertEquals(47,           reader.position)

        reader.getNext()
        self.assertEquals(3,            reader.fieldNbr)
        self.assertEquals('lString',    F.asStr(reader.fType))
        self.assertEquals(by,           reader.value)

        reader.getNext()
        self.assertEquals(4,            reader.fieldNbr)
        self.assertEquals('lString',    F.asStr(reader.fType))
        self.assertEquals(path,         reader.value)

if __name__ == '__main__':
    unittest.main()

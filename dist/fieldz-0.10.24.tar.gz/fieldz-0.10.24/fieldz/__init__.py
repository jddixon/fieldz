# fieldz/__init__.py

__version__ = '0.10.24'
__version_date__ = '2016-10-29'


__all__ = ['__version__', '__version_date__', ]

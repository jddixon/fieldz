#!/usr/bin/python

# testReg.py
import time, unittest

from rnglib         import SimpleRNG
from fieldz/reg     import *

class TestReg (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################


    # actual unit tests #############################################
    def testReg(self):

        pass

if __name__ == '__main__':
    unittest.main()

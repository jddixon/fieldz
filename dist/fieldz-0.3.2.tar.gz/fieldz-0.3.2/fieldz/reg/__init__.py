# ~/dev/py/fieldz/reg/__init__.py

import fieldz.fieldTypes as F

__all__ = [ 'Registry', ]

class Registry(object):

    def __init__(self):
        self._qualNames  = []   # unique qualified (dotted) name list
        # content key is hash of canonical string version of object
        self._qName2hash = {}   # qualified name to content key
        self._hash2regID = {}   # content key to unique ID

        # currying could help here
        self._putter     = []   # methods, write instance field type to buffer
        self._getter     = []   # methods, get instance field type from buffer

        self._nextRegID  = 0

        pass

    def register(seld):
        pass

    def bootstrap(self):
        # -- add fieldTypes -----------------------------------------
        for i in range(F.maxNdx):
            self._qualNames.append(F.asStr(i))
            self._qName2hash.append(None)
            self._hash2regID.append(None)
            # XXX STUB: putter
            # XXX STUB: getter

        self._nextRegID = F.maxNdx

        # -- load core types from specs/org/xlattice/fieldz/core/* 

        # -- add core types to tables -------------------------------
        pass



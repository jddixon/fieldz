#!/usr/bin/python

# testBigTestMsg.py
import time, unittest

from rnglib         import SimpleRNG
from fieldz.msgSpec import *

import fieldz.enumSpec          as Q
from StringIO import StringIO   as S

BIG_MSG_FILE = 'bigTest.xlgo'

class TestBigTestMsg (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################


    # actual unit tests #############################################
    def roundTripMsgSpecViaString(self, m):
        """ 
        Convert a MsgSpec object model to canonical string form,
        parse that to make a clone, and verify that the two are
        equal.
        """
        canonicalSpec = m.__repr__()
        # DEBUG
        print canonicalSpec
        # END
        p = StringMsgSpecParser( S(canonicalSpec) )
        clonedSpec   = p.parse()
        # crude tests of __eq__ AKA ==
        self.assertFalse( m == None        )
        self.assertTrue ( m == m           )

        # one way of saying it ------------------
        self.assertTrue ( m.__eq__(clonedSpec)  )
        self.assertTrue ( clonedSpec.__eq__(m)  )
        # this is the same test -----------------
        self.assertTrue ( m == clonedSpec  )
        self.assertTrue ( clonedSpec == m  )

    def testCompiler(self):
        with open('bigTest.xlgo', 'r') as f:
            p = StringMsgSpecParser(f)
            bigMsgSpec = p.parse()

        self.roundTripMsgSpecViaString(bigMsgSpec)

    # ---------------------------------------------------------------
    def roundTripMsgSpecToWireFormat(self, m):

        # invoke WireMsgSpecWriter
        # XXX STUB 

        # invoke WireMsgSpecParser
        # XXX STUB 
        
        pass

    def testRoundTripBigTestTypesToWireFormat(self):
        with open('bigTest.xlgo', 'r') as f:
            p = StringMsgSpecParser(f)
            bigMsgSpec = p.parse()

        self.roundTripMsgSpecToWireFormat(bigMsgSpec)

    # ---------------------------------------------------------------
    def testRoundTripBigTestInstancesToWireFormat(self):
        # XXX STUB
        pass

if __name__ == '__main__':
    unittest.main()

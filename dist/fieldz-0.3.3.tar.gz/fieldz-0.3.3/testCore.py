#!/usr/bin/python

# testCore.py
import time, unittest

from rnglib import SimpleRNG
import fieldz.core

class TestCore (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################

    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print


    # actual unit tests #############################################
    def testCoreTypes(self):

        pass

if __name__ == '__main__':
    unittest.main()

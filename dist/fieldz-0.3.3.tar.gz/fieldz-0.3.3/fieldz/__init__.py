# fieldz/__init__.py

__version__         = '0.3.3'
__version_date__    = '2012-09-06'

__all__ = [ '__version__',      '__version_date__',
]

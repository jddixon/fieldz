# fieldz/raw.py

import ctypes
import fieldTypes as F

__all__ = [ 'B32_TYPE', 'B64_TYPE', 'LEN_PLUS_TYPE', 'VARINT_TYPE',
            'B128_TYPE',
            'B160_TYPE',
            'B256_TYPE',
            'fieldHdr',         'readFieldHdr',
            'lengthAsVarint',   'readRawVarint', 'writeVarintField',
            'readRawB32',       'writeB32Field',
            'readRawB64',       'writeB64Field',
            'readRawLenPlus',   'writeLenPlusField',
            'readRawB128',      'writeB128Field',
            'readRawB160',      'writeB160Field',
            'readRawB256',      'writeB256Field',
            # -- methods --------------------------------------------
            'nextPowerOfTwo',
            # -- classes --------------------------------------------
            'WireBuffer',
]

# these are PRIMITIVE types, which determine the number of bytes
# occupied in the buffer; they are NOT data types
VARINT_TYPE     = 0 # variable length integer
B32_TYPE        = 1 # fixed length, 32 bits
B64_TYPE        = 2 # fixed length, 64 bits
LEN_PLUS_TYPE   = 3 # sequence of bytes preceded by a varint length
B128_TYPE       = 4 # fixed length, 128 bits (AES IV length)
B160_TYPE       = 4 # fixed length, 160 bits (SHA1 content key)
B256_TYPE       = 4 # fixed length, 128 bits (SHA3 content key)

# FIELD HEADERS #####################################################
def fieldHdr(n, t):
    # it would be prudent but slower to validate the parameters
    return (n << 3) | t

def hdrFieldNbr(h):
    return h >> 3

def hdrType(h):
    return h & 7

def readFieldHdr(buf, offset):
    (hdr, offset) = readRawVarint(buf, offset)
    pType       = hdrType(hdr)      # this is the primitive field type
    fieldNbr    = hdrFieldNbr(hdr)
    # DEBUG
    print "\nreadFieldHdr: hdr       0x%x" % hdr
    print "              pType     %u" % pType
    print "              fieldNbr  %u" % fieldNbr
    print "              offset    " + str(offset)
    # END
    return (pType, fieldNbr, offset)        # GEEP

# VARINTS ###########################################################
def lengthAsVarint(v):
    """ 
    Return the number of bytes occupied by an unsigned int. 
    caller is responsible for assuring that v is in fact properly
    cast as unsigned occupying no more space than an int64 (and
    so no more than 10 bytes).
    """
    if   v < (1<<7):    return 1
    elif v < (1<<14):   return 2
    elif v < (1<<21):   return 3
    elif v < (1<<28):   return 4
    elif v < (1<<35):   return 5
    elif v < (1<<42):   return 6
    elif v < (1<<49):   return 7
    elif v < (1<<56):   return 8
    elif v < (1<<63):   return 9
    else:               return 10

def readRawVarint(buf, offset):
    v = 0
    x = 0
    while True:
        if offset >= len(buf):
            raise ValueError("attempt to read beyond end of buffer")
        nextByte = buf[offset]
#       # DEBUG
#       print "readRaw: offset %u, nextByte = 0x%x" % (offset, nextByte)
#       # END
        offset  += 1

        sign     = nextByte & 0x80
        nextByte = nextByte & 0x7f
        nextByte <<= (x * 7)
        v |= nextByte
        x += 1

#       # DEBUG
#       print "  after shifting nextByte is 0x%x" % nextByte
#       print "    and v is 0x%x" % v
#       # END
        if sign == 0:
            break
    return (v, offset)

def writeRawVarint(buf, offset, s):
    # all varints are construed as 64 bit unsigned numbers
    v = ctypes.c_uint64(s).value
#   # DEBUG
#   print "entering writeRaw: will write 0x%x at offset %u" % ( v, offset)
#   # END
    l = lengthAsVarint(v)
    if offset + l > len(buf):
        raise ValueError("can't fit varint of length %u into buffer" % l)
    while True:
        buf[offset] = (v & 0x7f)
        offset += 1
        v >>= 7
        if v == 0:
            # return offset of next unused byte
            return offset   # next unused byte
        else:
            buf[offset-1] |= 0x80

def writeVarintField(buf, offset, v, n):
    # the header is the field number << 3 ORed with 0, VARINT_TYPE
    hdr = fieldHdr(n, VARINT_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
#   # DEBUG
#   print "header was 0x%x; writing value 0x%x at offset %u" % (
#                                                   hdr, v, offset)
#   # END
    return writeRawVarint(buf, offset, v)

# 32- AND 64-BIT FIXED LENGTH FIELDS ################################

def readRawB32 (buf, offset):
    """ buf construed as array of unsigned bytes """
    # XXX verify buffer long enough
    v = buf[offset];        offset += 1         # little-endian
    v |= buf[offset] <<  8; offset += 1
    v |= buf[offset] << 16; offset += 1
    v |= buf[offset] << 24; offset += 1
    return (v, offset)

def writeRawB32(buf, offset, v):
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;                 offset += 1
    return offset

def writeB32Field(buf, offset, v, f):
    hdr    = fieldHdr(f, B32_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
    return writeRawB32(buf, offset, v)                  # GEEP

def readRawB64 (buf, offset):
    """ buf construed as array of unsigned bytes """
    # XXX verify buffer long enough
    v = buf[offset];        offset += 1         # little-endian
    v |= buf[offset] <<  8; offset += 1
    v |= buf[offset] << 16; offset += 1
    v |= buf[offset] << 24; offset += 1
    v |= buf[offset] << 32; offset += 1
    v |= buf[offset] << 40; offset += 1
    v |= buf[offset] << 48; offset += 1
    v |= buf[offset] << 56; offset += 1
    return (v, offset)

def writeRawB64(buf, offset, v):
    # XXX verify buffer long enough
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;                 offset += 1
    return offset

def writeB64Field(buf, offset, v, f):
    hdr    = fieldHdr(f, B64_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
    return writeRawB64(buf, offset, v)

# VARIABLE LENGTH FIELDS ############################################

def readRawLenPlus(buf, offset):

    # read the varint len
    (n, offset) = readRawVarint(buf, offset)

    # then read n actual bytes
    s = []
    count = 0
    while count < n:
        s.append(buf[offset])
        count += 1
        offset += 1
    return (bytearray(s), offset)

def writeRawBytes(buf, offset, bytes):
    """ bytes a byte array """
    # XXX CHECK LEN OFFSET
    for b in bytes:
        buf[offset] = b;
        offset += 1
    return offset

def writeLenPlusField(buf, offset, s, f):
    """s is a bytearray or string"""
    # write the field header --------------------
    hdr    = fieldHdr(f, LEN_PLUS_TYPE)
    offset = writeRawVarint(buf, offset, hdr)

    # write the length of the byte array --------
    offset = writeRawVarint(buf, offset, len(s))

    # now write the byte array itself -----------
    return writeRawBytes(buf, offset, s)

# LONGER FIXED-LENGTH BYTE FIELDS ===================================
def readRawB128 (buf, offset):
    """ buf construed as array of unsigned bytes """
    # XXX verify buffer long enough
    s = []
    for i in range(16):
        s.append( buf[offset + i] )
    offset += 16
    return (bytearray(s), offset)

def writeRawB128(buf, offset, v):
    """ v is a bytearray or string """
    for i in range(16):
        # this is a possibly unnecessary cast
        buf[offset] = 0xff & v[i]
        offset += 1
    return offset

def writeB128Field(buf, offset, v, f):
    hdr    = fieldHdr(f, B128_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
    return writeRawB128(buf, offset, v)                  # GEEP

def readRawB160 (buf, offset):
    """ buf construed as array of unsigned bytes """
    # XXX verify buffer long enough
    s = []
    for i in range(20):
        s.append( buf[offset + i] )
    offset += 20
    return (bytearray(s), offset)

def writeRawB160(buf, offset, v):
    """ v is a bytearray or string """
    for i in range(20):
        # this is a possibly unnecessary cast
        buf[offset] = 0xff & v[i]
        offset += 1
    return offset

def writeB160Field(buf, offset, v, f):
    hdr    = fieldHdr(f, B160_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
    return writeRawB160(buf, offset, v)                  # GEEP

def readRawB256 (buf, offset):
    """ buf construed as array of unsigned bytes """
    # XXX verify buffer long enough
    s = []
    for i in range(32):
        s.append( buf[offset + i] )
    offset += 32
    return (bytearray(s), offset)

def writeRawB256(buf, offset, v):
    """ v is a bytearray or string """
    for i in range(32):
        # this is a possibly unnecessary cast
        buf[offset] = 0xff & v[i]
        offset += 1
    return offset

def writeB256Field(buf, offset, v, f):
    hdr    = fieldHdr(f, B256_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
    return writeRawB256(buf, offset, v)                  # GEEP

# PRIMITIVE FIELD NAMES =============================================
class PrimFields(object):
    """ lower-level primitive field types """
    
    _P_VARINT   = 0
    _P_B32      = 1     # 32 bit fields
    _P_B64      = 2     # 64 bit fields
    _P_LEN_PLUS = 3     # varint len followed by that many bytes
    # the following can be implemented in terms of _P_LEN_PLUS
    _P_B128    =  4    # fixed length string of 16 bytes
    _P_B160    =  5    # fixed length string of 20 bytes
    _P_B256    =  6    # fixed length string of 32 bytes

    _MAX_TYPE  = _P_B256

    @property
    def pVarint(clz):       return clz._P_VARINT
    @property
    def pB32(clz):          return clz._P_B32
    @property
    def pB64(clz):          return clz._P_B64
    @property
    def pLenPlus(clz):      return clz._P_LenPlus
    @property
    def pB128(clz):         return clz._P_B128
    @property
    def pB160(clz):         return clz._P_B160
    @property
    def pB256(clz):         return clz._P_B256

    _names = {}
    _names[_P_VARINT]   = 'pVarint'
    _names[_P_B32]      = 'pB32'
    _names[_P_B64]      = 'pB64'
    _names[_P_LEN_PLUS] = 'pLenPlus'
    _names[_P_B128]     = 'pB128'
    _names[_P_B160]     = 'pB160'
    _names[_P_B256]     = 'pB256'

    @classmethod
    def name(clz, v):      
        if v is None or v < 0 or FieldTypes._MAX_TYPE < v:
            raise ValueError('no such field type: %s' + str(v))
        return clz._names[v]

# -- WireBuffer -----------------------------------------------------
def nextPowerOfTwo(n):
    """ 
    If n is a power of two, return n.  Otherwise return the next 
    higher power of 2.
    See eg http://acius2.blogspot.com/2007/11/calculating-next-power-of-2.html
    """
    if n < 1:
        raise ValueError("nextPowerOfTwo: %s < 1" % str(n))
    n = n - 1
    n = (n >>  1) | n
    n = (n >>  2) | n
    n = (n >>  4) | n
    n = (n >>  8) | n
    n = (n >> 16) | n
    return n + 1

class WireBuffer(object):
   
    __slots__ = ['_buffer', '_position', '_capacity',]

    def __init__(self, n=1024, buffer=None):
        """ 
        Initialize the object.  If a buffer is specified, use it.
        Otherwise create one.  The resulting buffer will have a 
        capacity which is a power of 2.
        """
        if buffer:
            self._buffer = buffer
            bufSize      = len(buffer)
            if n < bufSize:
                n = bufSize
            n = nextPowerOfTwo(n)
            # DANGER: buffer capacities of cloned buffers can get out of sync
            if n > bufSize:
                more = bytearray(n - bufSize)
                self.buffer.extend(more)
        else:
            n = nextPowerOfTwo(n)
            # allocate and initialize the buffer; init probably a waste of time
            self._buffer    = bytearray(n)

        self._position  = 0
        self._capacity  = n             # NO LONGER USED

    def copy(self):
        """ 
        Returns a copy of this WireBuffer using the same underlying
        bytearray.  
        """
        return WireBuffer(len(self._buffer), self._buffer)

    @property
    def buffer(self):   return self._buffer

    @property
    def position(self): return self._position
    @position.setter
    def position(self, offset):
        if offset < 0:
            raise ValueError('position cannot be negative')
        if (offset >= len(self._buffer)):
            raise ValueError('position cannot be beyond capacity')
        self._position = offset

#   @property
#   def limit(self):    return self._limit
#   @limit.setter
#   def limit(self, offset):
#       if offset < 0:
#           raise ValueError('limit cannot be set to a negative')
#       if (offset < self._position):
#           raise ValueError("limit can't be set to less than current position")
#       if (offset > self._capacity):
#           raise ValueError('limit cannot be beyond capacity')
#       self._limit = offset

    @property
    def capacity(self): 
        return len(self._buffer)

    def reserve(self, k):
        """ 
        We need to add k more bytes; if the buffer isn't big enough,
        resize it.
        """
        if k < 0:
            raise ValueError(
              "attempt to increase WireBuffer size by negative number of bytes")
        if self._position + k >= self._capacity:
            # wildly inefficient, I'm sure
            more = bytearray(self._capacity)
            self._buffer.extend(more)
            self._capacity *= 2



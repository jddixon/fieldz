# fieldz/msgSpec.py

import re, sys
#from fieldz import  *
import fieldz.fieldTypes as F

__all__ = [  \
            # constants, so to speak: quantifiers
            'Q_REQUIRED',   # no quantifier, so one and only one such field
            'Q_OPTIONAL',   # ?: either zero or one instance of the field
            'Q_STAR',       # *: zero or more instances of the field allowed
            'Q_PLUS',       # +: one or more instances of the field

            # methods
            'qName',        'validateSimpleName',   'validateDottedName',

            # classes
            'EnumSpec',             'FieldSpec',            'MsgSpec',
            'ProtoSpec',            'MsgSequence',
            'StringMsgSpecParser',   
            'WireMsgSpecParser',    'WireMsgSpecWriter',
          ]

Q_REQUIRED  = 0
Q_OPTIONAL  = 1
Q_STAR      = 2
Q_PLUS      = 3

Q_NAMES     = ['', '?', '*', '+',]
def qName(n):
    if n < 0 or n >= len(Q_NAMES):
        raise ValueError('does not map to a valid quantifier: %s' % str(n))
    return Q_NAMES[n]

# base names, forming part of a larger pattern
_VALID_NAME_PAT = "[a-zA-Z_][a-zA-Z_0-9]*"
_VALID_NAME_RE  = re.compile(_VALID_NAME_PAT)

# just base names; match will fail if any further characters follow
_VALID_SIMPLE_NAME_PAT = _VALID_NAME_PAT + '$'
_VALID_SIMPLE_NAME_RE  = re.compile(_VALID_SIMPLE_NAME_PAT)

def validateSimpleName(s):
    m = _VALID_SIMPLE_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid simple name '%s'" % s)

# both protocol names and field names can be qualified
_VALID_DOTTED_NAME_PAT = _VALID_NAME_PAT + '(\.' + _VALID_NAME_PAT + ')*$'
_VALID_DOTTED_NAME_RE  = re.compile(_VALID_DOTTED_NAME_PAT)

def validateDottedName(s):
    m = _VALID_DOTTED_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid (optionally dotted) name '%s'" % s)

class EnumSpec(object):
    """
    For our purposes an enum is a list of simple names (names containing
    no delimiters and a map from such names to their 0-based indexes.
    """
    def __init__(self, names):
        if names is None:
            raise ValueError('null list of enum names')
        if len(names) == 0:
            raise ValueError('empty list of enum names')

        # sorting seems inappropriate, but we must not allow matches
        self._names     = []
        self._name2ndx  = {}
        i = 0
        for name in names:
            validateSimpleName(name)
            if not name in self._name2ndx:
                # silently discard duplicates
                self._names.append(name)
                self._name2ndx[name]    = i
                i += 1
        self._size      = len(self._names)  # which should be the same as i

    def value(self, s):
        """ map a name to the corresponding value """
        if s in self._name2ndx:
            return self._name2ndx[s]
        else:
            return None

    def name(self, n):
        if n < 0 or n > self._size - 1:
            return None
        else:
            return self._names[n]

    def __eq__(self, other):
        if other is None or not isinstance(other, EnumSpec):
            return False
        if other == self:
            return True
        if other._name != self._name:
            return False
        if len(self._names) != len(other._names):
            return False
        for name in self._names:
            if not name in other._names:
                return False
            if self._name2ndx(name) != other._name2ndx(name):
                return False
        return True
    
    def __str__(self):
        """ return a usable representation of the EnumSpec """
        return ', ' . join(self._names)
    def __repr__(self):
        """ return the EnumSpec in today's notion of the canonical form """
        return ',' . join(self._names)


class FieldSpec(object):
    __slots__ = [ '_name', '_type', '_quantifier', '_fieldNbr', '_default', ]

    def __eq__(self, other):
        if other is None or not isinstance(other, FieldSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
        if other._name != self._name:
            return False
        if other._type != self._type:
            return False
        if other._quantifier != self._quantifier:
            return False
        if self._fieldNbr:
            if other._fieldNbr is None:
                return False
            if self._fieldNbr != other._fieldNbr:
                return False

        # XXX IGNORE DEFAULTS FOR NOW

        return True


    def __init__(self, name, fType, quantifier=Q_REQUIRED, 
                                        fieldNbr=None, default=None):
        # -- name ---------------------------------------------------
        if name is None:
            raise ValueError('no field name specified')
        validateDottedName(name)
        self._name = name

        # -- fType --------------------------------------------------
        if fType is None:
            raise ValueError('no field type specified')
        tNdx = F.ndx(fType)
        if tNdx is None:
            # print "DEBUG: '%s' maps to %s" % (fType, str(tNdx))
            raise ValueError("'%s' is not a field type" % fType)
        self._type = tNdx

        # -- quantifier ---------------------------------------------
        # XXX BAD RANGE CHECK
        if quantifier < 0 or quantifier > Q_PLUS:
            raise ValueError("invalid quantifier '%s'" % str(quantifier))
        self._quantifier = quantifier

        # -- fieldNbr -----------------------------------------------
        self._fieldNbr = int(fieldNbr)

        # -- default ------------------------------------------------
        # if default is None, could provide a default appropriate for the type
        # XXXif we are going to support a default value, it needs to be
        #   validated
        # XXX STUB
        if default is not None:
            raise NotImplementedError('default for FieldSpec')
        self._default = default

    @property
    def name(self):         return self._name

    # XXX return a string value
    @property
    def fTypeName(self):    return F.asStr(self._type)

    # XXX return a number
    @property
    def fTypeNdx(self):     return self._type

    @property
    def quantifier(self):   return self._quantifier
    #def quantifier(self):   return Q_NAMES[self._quantifier]

    @property
    def fieldNbr(self):     return self._fieldNbr

    @property
    def default(self):      return self._default

    def __str__(self):
        """ return a prettier representation of the FieldSpec """

        # KEEP THIS IN SYNC WITH __repr__

        s = []
        # assume the caller does any indenting
        s.append('%-20s ' % self._name)

        tName = self.fTypeName
        if self._quantifier != Q_REQUIRED:
            tName += qName(self._quantifier)
        s.append('%-12s' % tName)               # at least one space

        if self._fieldNbr is not None:
            s.append(' @%d ' % self._fieldNbr)  # again, at least one space

        #========================
        # XXX default not handled
        #========================

        return '' . join(s)                 # GEEP

    def __repr__(self):
        """ 
        Return the FieldSpec in today's notion of the canonical form.
        This doesn't have to be pretty, just absolutely clear and
        unambiguous.
        """

        # KEEP THIS IN SYNC WITH __str__

        s = []
        # assume the caller does any indenting
        s.append(self._name)
        s.append(' ')

        tName = self.fTypeName
        if self._quantifier != Q_REQUIRED:
            tName += qName(self._quantifier)
        s.append(tName)
        s.append(' ')

        if self._fieldNbr is not None:
            s.append('@%d ' % self._fieldNbr)  # at least one space

        #========================
        # XXX default not handled
        #========================

        return '' . join(s)                 # GEEP

class MsgSpec(object):
    """
    A message is specified as an acceptable sequence of typed fields.
    Each field has a 1-based index, a name, and a type.  Later it will
    have a default value.

    Serialized, a message spec begins with the name of the message,
    which is a lenPlus string; this must be either a simple name
    containing no delimiters or it may be a sequence of simple names
    separated by dots ('.').  This is followed by individual field
    specs, each of which is a lenPlus names followed by colon (':')
    followed by a fieldType.

    """
    def __init__(self, protocol, name, fields, enum=None):
        # -- protocol -----------------------------------------------
        if protocol is None:
            raise ValueError('missing protocol declaration')
        validateDottedName(protocol)
        self._protocol = protocol

        # -- msgSpec name -------------------------------------------
        if name is None:
            raise ValueError('missing protocol declaration')
        validateSimpleName(name)
        self._name = name
        self._fields = []

        # -- fields -------------------------------------------------
        ndx             = 0
        self._nameToNdx = {}

        for f in fields:
            fName = f.name
            if fName in self._nameToNdx:
                # we will just ignore any fields with duplicate names
                continue
            if not isinstance(f, FieldSpec):
                raise ValueError("'%s' is not a FieldSpec!" % fName)
            self._fields.append(f)
            self._nameToNdx[fName] = ndx
            ndx += 1
        self._size = ndx 

        # -- enum ---------------------------------------------------
        if enum is not None and not isinstance(enum, EnumSpec):
            raise ValueError('not an EnumSpec')
        # we allow this to be None
        self._enum = enum

    # redundant but seems sensible; could return _fields[0].name
    @property
    def protocol(self):     return self._protocol

    @property
    def name(self):         return self._name

    @property
    def size(self):         return self._size

    def fName(self, i):
        if i < 0 or i > self._size:
            raise ValueError('field number out of range')
        return self._fields[i].name

    def fTypeName(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')
        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeName

    def fTypeNdx(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')

        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeNdx

    def fDefault(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')
        return self._fields[i].default

    # -- serialization ----------------------------------------------
    def __eq__(self, other):
        if other is None or not isinstance(other, MsgSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
        if other._protocol != self._protocol:
            return False
        if other._name != self._name:
            return False
        if self._size == 0 or other._size == 0:
            return False
        if self._size != other._size:
            return False
        for n in range(self._size):
            if not self._fields[n].__eq__(other._fields[n]):
                return False
        return True

    def __str__(self):
        """ return string representation in perhaps prettier format """
        s = []
        s.append( "protocol %s\n\n" % self._protocol)
        s.append( "message %s\n"    % self._name)
        for f in self._fields:
            s.append( "    %s\n" % f.__str__())

        return ''.join(s)

    def __repr__(self):
        """ return string representation in canonical format """
        s = []
        s.append( "protocol %s\n"   % self._protocol)
        s.append( "message %s\n"    % self._name)
        for f in self._fields:
            s.append( "  %s\n" % f.__repr__())

        return ''.join(s)

class ProtoSpec(object):
    """ 
    A protocol is a set of message types, enumerations, and acceptable
    message sequences.  It is essential for our purposes that any
    protocol can be constructed dynamically from its wire serialization.

    """

    def __init__(self, name):
        if name is None:
            raise ValueError('missing protocol name')
        validateDottedName(name)
        self._name = name

        # XXX STUB
            
    
    def __str__(self):
        raise NotImplementedError('__str__ for ProtoSpec')

    def __repr__(self):
        raise NotImplementedError('__repr__ for ProtoSpec')

class MsgSequence(object):
    """

    """
    def __init__(self):
        pass
        # XXX STUB
            
    
    def __str__(self):
        raise NotImplementedError('__str__ for MsgSequence')

    def __repr__(self):
        raise NotImplementedError('__repr__ for MsgSequence')


# == PARSERS AND WRITERS ============================================

# -------------------------------------------------------------------
class StringMsgSpecParser(object):
    """
    Reads a human-readable MsgSpec (a *.msgSpec file) to produce a
    MsgSpec object model, which is a MsgSpec with FieldSpecs and EnumSpecs
    dangling off of it.
    """
    def __init__(self, fd):
        # XXX should die if fd not open 
        self._fd            = fd
        self._protocol      = None
        self._name          = None
        self._enum          = None
        self._fields        = []

        self._nextFieldNbr  = 0

    def getLine(self):
        while True:
            line = self._fd.readline()
            
            # The first condition never fails if fd is a file-like object 
            # (from StringIO)
            if line is None or line == '':
                return None

            # strip off any comments 
            s   = line.partition('#')[0]

            # get rid of any trailing blanks
            line = s.rstrip()
            if line != '':
                return line

    def expectTokenCount(self, tokens, kind, n):
        if len(tokens) != n:
            raise RuntimeError("too many tokens in %s line '%s'" % (
                                                            kind,tokens))

    def expectProtocol(self):
        line  = self.getLine()
        words = line.split()
        self.expectTokenCount(words, 'protocol', 2)
        if words[0] == 'protocol':
            validateDottedName(words[1])
            self._protocol = words[1]
            # print "DEBUG: protocol is '%s'" % str(self._protocol)
        else:
            raise RuntimeError("expected protocol line, found '%s'" % line)

    def expectMsgSpecName(self):
        line  = self.getLine()
        words = line.split()
        self.expectTokenCount(words, 'protocol', 2)
        if words[0] == 'message':
            self._name = words[1]
            if self._name[-1] == ':':
                self._name = self._name[:-1]
            validateSimpleName(self._name)
            # print "DEBUG: msgSpec name is '%s'" % str(self._name)
        else:
            raise RuntimeError("expected message line, found '%s'" % line)

    def acceptEnum(self):
        # XXX STUB XXX
        # I think we need to return a line, but just do nothing for now
        self._enum = None

    def expectField(self, line):
        # for now, ignore any indentation
        line  = line.lstrip()
        
        # accept NAME FTYPE(Q)? (@N)? (=DEFAULT)?

        words = line.split()
        wordCount = len(words)

        if wordCount < 2:
            raise RuntimeError("too few tokens in field def '%s'" % line)
        if wordCount > 4:
            raise RuntimeError("too many tokens in field def '%s'" % line)

        # -- field name -------------------------
        fName   = words[0]
        validateSimpleName(fName)

        # -- quantifier -------------------------
        q = words[1][-1]
        if q == '?' or q == '*' or q == '+':
            words[1]    = words[1][:-1]
            if   q == '?':  quantifier = Q_OPTIONAL
            elif q == '*':  quantifier = Q_STAR
            else         :  quantifier = Q_PLUS
        else:           
            quantifier  = Q_REQUIRED

        # -- field type --------------------------
        fType   = words[1]
        if F.ndx(fType) is None:
            # may be the name of a message type, possibly from another protocol
            validateDottedName(fType)

        # XXX NAME OF MESSAGE TYPE NOT HANDLED ???

        # -- field number -----------------------
        fieldNbr = self._nextFieldNbr
        if wordCount >2:
            if words[2].startswith('@'):
                fieldNbr = int(words[2][1:])    # could use some validation
                if fieldNbr < self._nextFieldNbr:
                    raise ValueError('field number <= last field number')
        self._nextFieldNbr = fieldNbr + 1

        # -- default ----------------------------
        # XXX STUB - NOT IMPLEMENTED YET

        return FieldSpec(fName, fType, quantifier, fieldNbr)

    def expectFields(self):
        # they get appended to self._fields; there must be at least one
        line  = self.getLine()
        if line is None or line == '':
            raise RuntimeError('no fields found')
        self._fields.append( self.expectField(line) )

        line = self.getLine()
        while line is not None and line != '':
            self._fields.append( self.expectField(line) )
            line = self.getLine()

    def parse(self):
        self.expectProtocol()
        self.expectMsgSpecName()
        self.acceptEnum()
        self.expectFields()
        return MsgSpec(self._protocol, self._name, self._fields, self._enum)

# POSSIBLY SUPERCLASS IS TFReader
class WireMsgSpecParser(object):
    """
    Reads a MsgSpec fully serialized to wire form (and so a sequence of
    fieldz) produce a MsgSpec object model, which is a MsgSpec with
    FieldSpecs and EnumSpecs dangling off of it.
    """
    def __init__(self, w):
        pass

# POSSIBLY SUPERCLASS IS TFBuffer OR TFWriter
class WireMsgSpecWriter(object):
    """
    Given a MsgSpec (including attached FieldSpecs and optional EnumSpecs)
    produces a serialization using FieldTypes.
    """

    def __init__(self, mSpec, wb):
        if mSpec is None:
            raise ValueError('no MsgSpec identified')
        self._m = mSpec
        
        if wb is None:
            raise ValueError('no WireBuffer specified')
        self._wb = wb

    def write(self):
        
        # THIS SHOULD JUST USE TFWriter, OR ITS BITS AND PIECES. 
        # To use TFWriter in its current form, we need a wired-in class 
        # definition, say MsgSpecClz.  
        # Alternatively, put the putNext methods into a dispatch table
        # and invoke them through that table.

        # protocol
        # name
        # enum
        # fields
        
        pass

#!/usr/bin/python

# testMsgSpec.py
import time, unittest

from rnglib         import SimpleRNG
from fieldz.msgSpec import *
from fieldz.typed   import *

class TestMsgSpec (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # actual unit tests #############################################

    def testEnum(self):
        """ 
        A not very useful enum, limited to mapping a fixed list of
        names into a zero-based sequence of integers.
        """

        # XXX should test null or empty lists, ill-formed names
        names = ['abc', 'def', 'ghi']
        enum  = EnumSpec(names)
        self.assertEquals( ','.join(names), enum._repr())
        self.assertEquals( 'abc', enum.name(0))
        self.assertEquals( 'def', enum.name(1))
        self.assertEquals( 'ghi', enum.name(2))

    def testMsgSpec(self):
        """ this is in fact the current spec for a log entry """
        name    = 'logEntry'
        enum    = ['oh', 'hello', 'there',]
        fields  = [ \
                ('timestamp', FieldTypes._F_INT32),
                ('nodeID',    FieldTypes._F_BYTES20),
                ('key',       FieldTypes._F_BYTES20),
                ('by',        FieldTypes._L_STRING),
                ('path',      FieldTypes._L_STRING),
        ]
        msgSpec = MsgSpec(name, fields, enum)

        self.assertEquals(name, msgSpec.name)

        # not likely to be useful just yet but ...
        self.assertEquals(name, msgSpec.fName(0))
        self.assertEquals(FieldTypes._L_MSG, msgSpec.fType(0))

        # field numbers are 1-based
        for i in range(1,5):
            self.assertEquals(fields[i][0], msgSpec.fName(i))
            self.assertEquals(fields[i][1], msgSpec.fType(i))

if __name__ == '__main__':
    unittest.main()

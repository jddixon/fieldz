#!/usr/bin/python

# testTFWriter.py
import time, unittest

from rnglib       import SimpleRNG
from fieldz.typed import *

# scratch variables
b128 = bytearray(16)
b160 = bytearray(20)
b256 = bytearray(32)

class TestTFWriter (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################

    def testCtor(self):
        BUFSIZE = 1024
        buffer  = bytearray(BUFSIZE)
        tfWriter   = TFWriter(buffer)
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def testCreator(self):
        BUFSIZE = 1024
        tfWriter   = TFWriter.create(BUFSIZE)
        self.assertTrue( isinstance( tfWriter, TFWriter ) )
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def doRoundTripField(self, writer, reader, n, fType, value):
        writer.putNext(n, fType, value)
#       # DEBUG
#       tfBuf   = writer.buffer
#       print "after put buffer is " ,
#       self.dumpBuffer(tfBuf)
#       # END
        reader.getNext()
        self.assertEquals( n,     reader.fieldNbr ) 
        self.assertEquals( fType, reader.fType    )
        self.assertEquals( value, reader.value    )
        return n + 1

    def testWritingAndReading(self):
        BUFSIZE = 16*1024
        tfWriter= TFWriter.create(BUFSIZE)
        tfBuf   = tfWriter.buffer
        tfReader= TFReader(tfBuf)       # evil :-)
        
        F = FieldTypes()                # yes, this is stupid
        n = 1                           # 1-based field number

        # field types encoded as varints (8) ========================
        # These are tested in greater detail in testVarint.py; the
        # tests here are to exercise their use in a heterogeneous 
        # buffer

        # _V_INT32
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 0x1f)
        self.assertEquals(2, n)         # DEBUG

        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 
                                                      0x172f3e4d)
        # _V_INT64
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt64, 
                                                      0x12345678abcdef3e)

        # DEBUG: This line has already tested OK - and makes no difference here
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 0x1f)
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 0x1f)

#       PROBLEM WITH vsInt32/64 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#       # hmmm... This line gets the same sort of error: 96 in doRoundTrip()
#       n = self.doRoundTripField(tfWriter, tfReader, n, F.vsInt32, 192)
#       # copying this block to the beginning did NOT help - got same error
#       # END -------------------------------------------------------

#       # _V_SINT32 (zig-zag encoded, optimal for small values near zero)
#       # XXX FAILS: -192 becomes -96 in doRoundTrip()
#       n = self.doRoundTripField(tfWriter, tfReader, n, F.vsInt32, -192)
#       
#       # _V_SINT64
#       n = self.doRoundTripField(tfWriter, tfReader, n, F.vsInt64, -193) # GEEP
#       END PROBLEM AREA XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

        # _V_UINT32
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vuInt32, 
                                                      0x172f3e4d)
        # _V_UINT64
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vuInt64, 
                                                      0xffffffff172f3e4d)

        # _V_BOOL
        # XXX NOT IMPLEMENTED, NOT TESTED

        # _V_ENUM
        # XXX NOT IMPLEMENTED, NOT TESTED

        # encoded as fixed length 32 bit fields =====================
        # _F_INT32
        # _F_FLOAT
        
        # encoded as fixed length 64 bit fields =====================
        # _F_INT64
        # _F_DOUBLE
        
        # encoded as varint len followed by byte[len] ===============
        # _L_STRING
        # _L_BYTES
        # _L_MSG 

        # fixed length byte sequences, byte[N} ======================
        # _F_BYTES16
        # _F_BYTES20
        # may want to introduce eg fNodeID20 and fSha1Key types
        # _F_BYTES32    
        # may want to introduce eg fSha3Key type, allowing semantic checks

if __name__ == '__main__':
    unittest.main()

# fieldz/msgSpec.py

import re
from fieldz.typed import *

__all__ = [ 'EnumSpec', 'FieldSpec', 'MsgSpec', ]

# we are simple folk
_VALID_NAME_PAT = "[a-zA-Z_][a-zA-Z_0-9]*$"
_VALID_NAME_RE  = re.compile(_VALID_NAME_PAT)

class EnumSpec(object):
    """
    For our purposes an enum is a list of simple names (names containing
    no delimiters and a map from such names to their 0-based indexes.
    """
    def __init__(self, names):
        if names is None:
            raise ValueError('null list of enum names')
        if len(names) == 0:
            raise ValueError('empty list of enum names')

        # sorting seems inappropriate, but we must not allow matches
        self._names     = []
        self._name2ndx  = {}
        i = 0
        for name in names:
            m = _VALID_NAME_RE.match(name)
            if m is None:
                raise ValueError("'%s' is not a valid enum name" % name)
            if not name in self._name2ndx:
                # silently discard duplicates
                self._names.append(name)
                self._name2ndx[name]    = i
                i += 1
        self._size      = len(self._names)  # which should be the same as i

    def value(self, s):
        """ map a name to the corresponding value """
        if s in self._name2ndx:
            return self._name2ndx[s]
        else:
            return None

    def name(self, n):
        if n < 0 or n > self._size - 1:
            return None
        else:
            return self._names[n]

    def _repr(self):
        return ',' . join(self._names)


class FieldSpec(object):
    pass

class MsgSpec(object):
    """
    A message is specified as an acceptable sequence of typed fields.
    Each field has a 1-based index, a name, and a type.  Later it will
    have a default value.

    Serialized, a message spec begins with the name of the message,
    which is a lenPlus string; this must be either a simple name
    containing no delimiters or it may be a sequence of simple names
    separated by dots ('.').  This is followed by individual field
    specs, each of which is a lenPlus names followed by colon (':')
    followed by a fieldType.
    """
    def __init__(self, name, fields, enum=None):
        self._names      = []
        self._types      = []
        self._defaults   = []
        self._enum       = enum

        # field zero describes the MsgSpec itself
        self._names.append(name)
        self._types.append(FieldTypes._L_MSG)
        for i in range(1, len(fields)):
            field = fields[i]
            # it must be a tuple  XXX NEED TO ADD VALIDATION
            self._names.append(field[0])
            self._types.append(field[1])
            if len(field) >= 3:
                self._defaults.append(field[2])
            else:
                self._defaults.append(None)
        self._size = len(self._names)        # could just use i

    # redundant but seems sensible
    @property
    def name(self):         return self._names[0]

    def fName(self, i):
        if i < 0 or i >= self._size:    
            raise ValueError('field number out of range')
        return self._names[i]
    def fType(self, i):
        if i < 0 or i >= self._size:    
            raise ValueError('field number out of range')
        return self._types[i]
    def default(self, i):
        if i < 0 or i >= self._size:    
            raise ValueError('field number out of range')
        return self._defaults[i]


# fieldz/__init__.py

__version__         = '0.1.6'
__version_date__    = '2012-08-22'

__all__ = [ '__version__', '__version_date__',
]

# fieldz/protoSpec.py

#__all__ = [ 
#]

class ProtocolSpec(object):
    """ a protocol is specified as an acceptable sequence of messages """
    pass

## MACHINE ###########################################################
#
##class ReadMachine(object):
##    def __init__ (self, buffer, offset=0):
##        if buffer is None:
##            raise ValueError('no input buffer')
##        if offset < 0 or len(buffer) HERE ***

# fieldz/msgSpec.py

#__all__ = [ 
#]

class FieldSpec(object):

class MessageSpec(object):
    """ 
    A message is specified as an acceptable sequence of typed fields.
    Serialized, a message spec begins with the name of the message, 
    which is a lenPlus string; this must be either a simple name 
    containing no delimiters or it may be a sequence of simple names 
    separated by dots ('.').  This is followed by individual field 
    specs, each of which is a lenPlus names followed by colon (':') 
    followed by a fieldType.
    """
    def __init__(self, name, fields):
        pass


## MACHINE ###########################################################
#
##class ReadMachine(object):
##    def __init__ (self, buffer, offset=0):
##        if buffer is None:
##            raise ValueError('no input buffer')
##        if offset < 0 or len(buffer) HERE ***

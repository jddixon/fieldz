#!/usr/bin/python

# testTFReader.py
import time, unittest

from rnglib       import SimpleRNG
from fieldz.typed import *

class TestTFReader (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################

    def testCtor(self):
        BUFSIZE = 1024
        buffer  = [0]*BUFSIZE
        tfReader   = TFReader(buffer)
        self.assertEquals(0,       tfReader.position)
        self.assertEquals(BUFSIZE, tfReader.capacity)
        self.assertEquals(BUFSIZE, len(tfReader.buffer))

    def testCreator(self):
        BUFSIZE = 1024
        tfReader   = TFReader.create(BUFSIZE)
        self.assertTrue( isinstance( tfReader, TFReader ) )
        self.assertEquals(0,        tfReader.position)
        self.assertEquals(BUFSIZE,  tfReader.capacity)

if __name__ == '__main__':
    unittest.main()

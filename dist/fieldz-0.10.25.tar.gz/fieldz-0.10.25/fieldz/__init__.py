# fieldz/__init__.py

__version__ = '0.10.25'
__version_date__ = '2016-10-30'


__all__ = ['__version__', '__version_date__', ]

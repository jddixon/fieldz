#!/usr/bin/python

# testRingDataProto.py
import StringIO, time, unittest

from rnglib         import SimpleRNG
from ringDataProto  import RING_DATA_PROTO_SPEC

from fieldz.parser import StringProtoSpecParser
import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T
from pzog.xlattice.node     import Node

hostByName      = {}
hostByAddr      = {}
hostByNodeID    = {}
hostByPubKey    = {}
hostByPrivateKey= {}

rng             = SimpleRNG(int(time.time()))

class RingHost(object):
#   __slots__ = ['_hostName', '_ipAddr', '_nodeID', '_pubKey',
#                '_privateKey',]
    def __init__(self, name=None, ipAddr=None, nodeID=None,
                       pubKey=None, privateKey=None):
        self._name      = name
        self._ipAddr    = ipAddr
        self._nodeID    = nodeID
        self._pubKey    = pubKey
        self._privateKey= privateKey

    @classmethod
    def createRandomHost(cls):
        maxCount = 8
        n = 0
        while n < maxCount:
            n           = n + 1
            node        = Node()  # by default uses SHA3 and generates RSA keys
            privateKey  = node.key
            pubKey      = node.pubKey
            nodeID      = node.nodeID

            name    = rng.nextFileName(8)
            
            addr    = rng.nextInt32()
            dottedQ = '%d.%d.%d.%d' % (
                        (addr >> 24 & 0xff),
                        (addr >> 16 & 0xff),
                        (addr >>  8 & 0xff),
                        (addr       & 0xff))
            # DEBUG
            print "name is      '%s'" % name
            print "addr is      '%s'" % addr
            print "dottedQ is   '%s'" % dottedQ
            print "nodeID is    '%s'" % nodeID
            # END
            if name     in hostByName:  
                continue
            if dottedQ  in hostByAddr:   
                continue
            if nodeID   in hostByNodeID: 
                continue
            # DEBUG
            print "PUB_KEY: %s" % pubKey.n
            # END
            if pubKey.n  in hostByPubKey:    
                print "pubKey is not unique"
                continue
            if privateKey.n  in hostByPrivateKey:
                print "privateKey is not unique"
                continue

            r = cls(name, dottedQ, nodeID, pubKey, privateKey)
            hostByName[name]            = r
            hostByAddr[dottedQ]         = r  # addr as dotted quad
            hostByNodeID[nodeID]        = r
            hostByPubKey[pubKey.n]      = r
            hostByPrivateKey[privateKey.n]= r
            return r

class TestPzogProto (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################

    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################
    def testPzogProto(self):
        # MODEL: testProtoSpec XXX
        data = StringIO.StringIO(RING_DATA_PROTO_SPEC)
        p    = StringProtoSpecParser(data)
        sOM  = p.parse()             # object model from string serialization
        self.assertIsNotNone(sOM)
        self.assertTrue(isinstance(sOM, M.ProtoSpec))
        self.assertEquals( 'org.xlattice.pzog.ringData', sOM.name )
        self.assertEquals(0, len(sOM.enums) )
        self.assertEquals(1, len(sOM.msgs) )
        self.assertEquals(0, len(sOM.seqs) )

        # OUTER MESSAGE SPEC ----------------------------------------
        msgSpec = sOM.msgs[0]
        field = msgSpec[0]
#       self.assertEquals(msgSpec.fName(0),     'hosts')
#       self.assertEquals(msgSpec.fTypeName(0), 'hostInfo')
        self.assertEquals(field.name,           'hosts')
        self.assertEquals(field.fTypeName,      'hostInfo')
        self.assertEquals(field.quantifier,     M.Q_PLUS)
        # quantifier should be PLUS

        # INNER MESSAGE SPEC ----------------------------------------
        msgSpec = sOM.msgs[0].msgs[0]
        self.assertEquals(msgSpec.fName(0),     'hostName')
        self.assertEquals(msgSpec.fTypeName(0), 'lString')
        self.assertEquals(msgSpec.fName(1),     'ipAddr')
        self.assertEquals(msgSpec.fTypeName(1), 'lString')
        self.assertEquals(msgSpec.fName(2),     'nodeID')
        self.assertEquals(msgSpec.fTypeName(2), 'fBytes32')
        self.assertEquals(msgSpec.fName(3),     'pubKey')
        self.assertEquals(msgSpec.fTypeName(3), 'lString')
        self.assertEquals(msgSpec.fName(4),     'privateKey')
        self.assertEquals(msgSpec.fTypeName(4), 'lString')
        try:
            msgSpec.fName(5)
            self.fail('did not catch reference to non-existent field')
        except IndexError as ie:
            pass

    # ---------------------------------------------------------------
    def roundTripRingDataInstanceToWireFormat(self, spec, r): # r = ringHost

        # invoke WireMsgSpecWriter
        # XXX STUB

        # invoke WireMsgSpecParser
        # XXX STUB

        pass

    def testRoundTripRingDataInstancesToWireFormat(self):
        strSpec     = StringIO.StringIO(RING_DATA_PROTO_SPEC)
        p           = StringProtoSpecParser(strSpec)
        ringDataSpec= p.parse()

        count = 2 + self.rng.nextInt16(8)   # so 2..9 inclusive

        # make that many semi-random nodes, taking care to avoid duplicates,
        # and round-trip each
        for k in range(count):
            r = RingHost.createRandomHost()
            self.roundTripRingDataInstanceToWireFormat(ringDataSpec, r)


if __name__ == '__main__':
    unittest.main()

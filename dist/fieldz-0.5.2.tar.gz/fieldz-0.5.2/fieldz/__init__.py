# fieldz/__init__.py

__version__         = '0.5.2'
__version_date__    = '2012-11-16'

__all__ = [ '__version__',      '__version_date__',
]

#!/usr/bin/python

# testCoreTypes.py
import time, unittest
import StringIO

from rnglib import SimpleRNG
from fieldz.raw    import * 
from fieldz.typed  import * 
import fieldz.msgSpec       as M
import fieldz.coreTypes     as C
import fieldz.fieldTypes    as F
import fieldz.reg           as R
from fieldz.parser import StringMsgSpecParser

LOG_ENTRY_MSG_SPEC = """
# protocol org.xlattice.zoggery
message logEntry:
 timestamp   fuInt32
 nodeID      fBytes20
 key         fBytes20
 by          lString
 path        lString
"""
class TestCoreTypes (unittest.TestCase):

    def setUp(self):
#       self.rng = SimpleRNG( time.time() )
        pass
    def tearDown(self):
        pass

    # utility functions #############################################
    def makeRegistries(self, protocol):
        nodeReg = R.NodeReg()
        protoReg= R.ProtoReg(protocol, nodeReg)
        msgReg  = R.MsgReg(protoReg)
        return (nodeReg, protoReg, msgReg)
    
    # actual unit tests #############################################
    def testTheEnum(self):
        self.assertEquals(5, C.maxNdx)
        self.assertEquals(0, C._ENUM_PAIR_SPEC)
        self.assertEquals(5, C._PROTO_SPEC)

    def roundTripToWireFormat(self, wb, n, cType, val):
        nodeReg, protoReg, msgReg = self.makeRegistries(
                                        'org.xlattice.fieldz.test.roundTrip')

        buf         = wb.buffer
        putter      = M.cPutFuncs[cType] 
        getter      = M.cGetFuncs[cType] 
        lenFunc     = M.cLenFuncs[cType] 
        pLenFunc    = M.cPLenFuncs[cType] 
        h           = fieldHdrLen(n, cType)     # BUT cType must be >18!

        wPos        = 0 # write
        rPos        = 0 # read
        expectedPos = pLenFunc(val, n)

        wPos = putter(buf, wPos, val, 0) # writing field 0

        self.assertEquals(expectedPos, wPos)

        (pType, n, rPos) = readFieldHdr(buf, rPos)
        actualHdrLen     = rPos
        self.assertEquals( LEN_PLUS_TYPE,   pType )
        self.assertEquals( 0,               n     )    # field number
        self.assertEquals( h,               actualHdrLen)

        # XXX FAILS: WRONG NUMBER OF ARGUMENTS.  Takes 3:
        #   msgSpec.fieldSpecGetter(msgReg, buf, pos)
        # XXX THIS HAS BEEN CRUDELY FIXED by prefixing msgReg, but doing
        # nothing with it in msgSepc.fieldSpecGetter 
        # BUT THIS FIX FAILS IMMEDIATELY, when round-tripping an EnumPairSpec
        (retVal, rPos)  = getter(msgReg, buf, rPos)
#       # DEBUG
#       print "ROUND TRIP: val    = %s" % val
#       print "            retVal = %s" % retVal
#       # END
        self.assertEquals( val, retVal)

    def testRoundTrippingCoreTypes(self):
        BUFSIZE = 16*1024
        wb      = WireBuffer(BUFSIZE)

        # -----------------------------------------------------------
        # XXX FAILS if msgReg arg added: WRONG NUMBER OF ARGS
        # XXX n=0 is wired into roundTripToWireFormat XXX
#       n = 0                           # 0-based field number
#       s = M.EnumPairSpec('funnyFarm', 497)
#       self.roundTripToWireFormat( wb, n, C._ENUM_PAIR_SPEC, s)

        # -----------------------------------------------------------
        protocol= 'org.xlattice.upax'
        nodeReg, protoReg, msgReg = self.makeRegistries(protocol)
        n = 0                          # 0-based field number
        pairs = [ ('funnyFarm', 497),
                  ('myOpia',     53),
                  ('frogHeaven',919), 
                ]
        s = M.EnumSpec.create('thisEnum', pairs)
        self.assertEquals(3, len(s))
        # XXX FAILS if msgReg arg added: WRONG NUMBER OF ARGS
#       self.roundTripToWireFormat( wb, n, C._ENUM_SPEC, s)

        # -----------------------------------------------------------
        protocol= 'org.xlattice.upax'
        nodeReg, protoReg, msgReg = self.makeRegistries(protocol)
        n = 0                          # 0-based field number
        s = M.FieldSpec(msgReg, 'jollyGood', F._V_SINT32, M.Q_OPTIONAL, 37)
        self.roundTripToWireFormat(wb, n, C._FIELD_SPEC, s)

        # -----------------------------------------------------------
        
        # MsgSpec without enum
        protocol= 'org.xlattice.upax'
        nodeReg, protoReg, msgReg = self.makeRegistries(protocol)
        data = StringIO.StringIO(LOG_ENTRY_MSG_SPEC)
        p    = StringMsgSpecParser(data)   
        sOM  = p.parse()             # object model from string serialization
        self.assertIsNotNone(sOM)
        self.assertTrue(isinstance(sOM, M.MsgSpec))

        n = 0
        # XXX FAILS if msgReg arg added: WRONG NUMBER OF ARGS
#       self.roundTripToWireFormat( wb, n, C._MSG_SPEC, sOM )


if __name__ == '__main__':
    unittest.main()

# fieldz/__init__.py

__version__ = '0.10.29'
__version_date__ = '2016-12-04'


__all__ = ['__version__', '__version_date__', ]

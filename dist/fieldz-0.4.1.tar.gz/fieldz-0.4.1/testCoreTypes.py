#!/usr/bin/python

# testCoreTypes.py
import time, unittest
import StringIO

from rnglib import SimpleRNG
from fieldz.raw    import * 
from fieldz.typed  import * 
import fieldz.msgSpec       as M
import fieldz.coreTypes     as C
import fieldz.fieldTypes    as F
from fieldz.parser import StringMsgSpecParser

LOG_ENTRY_MSG_SPEC = """
# protocol org.xlattice.zoggery
message logEntry:
 timestamp   fuInt32
 nodeID      fBytes20
 key         fBytes20
 by          lString
 path        lString
"""
class TestCoreTypes (unittest.TestCase):

    def setUp(self):
#       self.rng = SimpleRNG( time.time() )
        pass
    def tearDown(self):
        pass

    # utility functions #############################################


    # actual unit tests #############################################
    def testTheEnum(self):
        self.assertEquals(5, C.maxNdx)
        self.assertEquals(0, C._ENUM_PAIR_SPEC)
        self.assertEquals(5, C._PROTO_SPEC)

    def doRoundTripCoreType(self, wb, n, cType, val):
        buf         = wb.buffer
        putter      = M.cPutFuncs[cType] 
        getter      = M.cGetFuncs[cType] 
        lenFunc     = M.cLenFuncs[cType] 
        pLenFunc    = M.cPLenFuncs[cType] 
        h           = fieldHdrLen(n, cType)     # BUT cType must be >18!

        wPos        = 0 # write
        rPos        = 0 # read
        expectedPos = pLenFunc(val, n)

        wPos = putter(buf, wPos, val, 0) # writing field 0

        self.assertEquals(expectedPos, wPos)

        (pType, n, rPos) = readFieldHdr(buf, rPos)
        actualHdrLen     = rPos
        self.assertEquals( LEN_PLUS_TYPE,   pType )
        self.assertEquals( 0,               n     )    # field number
        self.assertEquals( h,               actualHdrLen)

        (retVal, rPos)  = getter(buf, rPos)
#       # DEBUG
#       print "ROUND TRIP: val    = %s" % val
#       print "            retVal = %s" % retVal
#       # END
        self.assertEquals( val, retVal)

    def testRoundTrippingCoreTypes(self):
        BUFSIZE = 16*1024
        wb      = WireBuffer(BUFSIZE)

        # -----------------------------------------------------------
        # XXX n=0 is wired into doRoundTripCoreType XXX
        n = 0                           # 0-based field number
        s = M.EnumPairSpec('funnyFarm', 497)
        self.doRoundTripCoreType( wb, n, C._ENUM_PAIR_SPEC, s)

        # -----------------------------------------------------------
        n = 0                          # 0-based field number
        pairs = [ ('funnyFarm', 497),
                  ('myOpia',     53),
                  ('frogHeaven',919), 
                ]
        s = M.EnumSpec.create('thisEnum', pairs)
        self.assertEquals(3, len(s))
        self.doRoundTripCoreType( wb, n, C._ENUM_SPEC, s)

        # -----------------------------------------------------------
        n = 0                          # 0-based field number
        s = M.FieldSpec('jollyGood', F._V_SINT32, M.Q_OPTIONAL, 37)
        self.doRoundTripCoreType( wb, n, C._FIELD_SPEC, s)

        # -----------------------------------------------------------
        
        # MsgSpec without enum
        data = StringIO.StringIO(LOG_ENTRY_MSG_SPEC)
        p    = StringMsgSpecParser(data)   
        sOM  = p.parse()             # object model from string serialization
        self.assertIsNotNone(sOM)
        self.assertTrue(isinstance(sOM, M.MsgSpec))

        n = 0
        self.doRoundTripCoreType( wb, n, C._MSG_SPEC, sOM )


if __name__ == '__main__':
    unittest.main()

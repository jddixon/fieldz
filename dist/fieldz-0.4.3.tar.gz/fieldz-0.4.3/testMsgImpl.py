#!/usr/bin/python

# testMsgImpl.py
import StringIO, time, unittest

from rnglib import SimpleRNG

from fieldz.parser import StringProtoSpecParser
import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T
from fieldz.chan    import Channel
from fieldz.msgImpl import makeMsgClass, makeFieldClass

#################################################################
# THIS WAS HACKED FROM testProtoSpec.py; CAN HACK MORE FROM THERE
#################################################################

# PROTOCOLS ---------------------------------------------------------
from zoggeryProtoSpec import ZOGGERY_PROTO_SPEC

BUFSIZE = 16*1024

# TESTS -------------------------------------------------------------
class TestMsgImpl (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
        data = StringIO.StringIO(ZOGGERY_PROTO_SPEC)
        p    = StringProtoSpecParser(data)   # data should be file-like
        self.sOM        = p.parse()     # object model from string serialization
        self.protoName  = self.sOM.name # the dotted name of the protocol

    def tearDown(self):
        pass

    # utility functions #############################################
    def leMsgValues(self):
        """ returns a list """
        timestamp   = int(time.time())
        key         = [0]*20
        nodeID      = [0]*20
        by          = 'who is responsible'
        path        = '/home/jdd/tarballs/something.tar.gz'
        # let's have some random bytes
        self.rng.nextBytes(key)
        self.rng.nextBytes(nodeID)
        return [timestamp, key, nodeID, by, path]

    # actual unit tests #############################################
    def checkFieldImplAgainstSpec(self, protoName, msgName, fieldSpec, value):
        self.assertIsNotNone(fieldSpec)
        Clz         = makeFieldClass(protoName, msgName, fieldSpec)
        if '__dict__' in dir(Clz):
            print '\nGENERATED FieldImpl CLASS DICTIONARY'
            for e in Clz.__dict__.keys():
                print "%-20s %s" % (e, Clz.__dict__[e])

        self.assertIsNotNone(Clz)
        f           = Clz(value)
        self.assertIsNotNone(f)

        # class attributes --------------------------------
        self.assertEquals( fieldSpec.name,      f.name        )
        self.assertEquals( fieldSpec.fTypeNdx,  f.fType       )
        self.assertEquals( fieldSpec.quantifier,f.quantifier  )
        self.assertEquals( fieldSpec.fieldNbr,  f.fieldNbr    )
        self.assertIsNone( f.default )          # not an elegant test

        # instance attribute ------------------------------
        self.assertEquals( value, f.value)

        # with slots enabled, this is never seen ----------
        # because __dict__ is not in the list of valid 
        # attributes for f
        if '__dict__' in dir(f):
            print '\nGENERATED FieldImpl INSTANCE DICTIONARY'
            for item in f.__dict__.keys():
                print "%-20s %s" % (item, f.__dict__[item])     # GEEP

    def testFieldImpl(self):
        msgSpec     = self.sOM.msgs[0]

        # the fields in this imaginary logEntry
        values = self.leMsgValues()

        for i in range(len(msgSpec)): 
            print "\nDEBUG: field %u ------------------------------------------------------" % i
            fieldSpec = msgSpec[i]
            self.checkFieldImplAgainstSpec(
                        self.protoName, msgSpec.name, fieldSpec, values[i])

    def testCaching(self):
        self.assertTrue(isinstance(self.sOM, M.ProtoSpec))
        msgSpec = self.sOM.msgs[0]
        Clz0    = makeMsgClass(self.protoName, msgSpec)
        Clz1    = makeMsgClass(self.protoName, msgSpec)
        # we cache classe, so the two should be the same
        self.assertEquals(id(Clz0), id(Clz1))

        # chan    = Channel(BUFSIZE)
        values  = self.leMsgValues()
        leMsg0  = Clz0(values) 
        leMsg1  = Clz0(values) 
        # we don't cache instances, so these will differ
        self.assertNotEquals(id(leMsg0), id(leMsg1))

        fieldSpec = msgSpec[0]
        F0    = makeFieldClass(self.protoName, msgSpec.name, fieldSpec)
        F1    = makeFieldClass(self.protoName, msgSpec.name, fieldSpec)
        self.assertEquals(id(F0), id(F1))

    def testMsgImpl(self):
        self.assertIsNotNone(self.sOM)
        self.assertTrue(isinstance(self.sOM, M.ProtoSpec))
        self.assertEquals( 'org.xlattice.zoggery', self.sOM.name )

        self.assertEquals(0, len(self.sOM.enums) )
        self.assertEquals(1, len(self.sOM.msgs) )
        self.assertEquals(0, len(self.sOM.seqs) )

        msgSpec = self.sOM.msgs[0]
        
        # Create a channel ------------------------------------------
        # its buffer will be used for both serializing # the instance 
        # data and, by deserializing it, for creating a second instance.
        chan = Channel(BUFSIZE)
        buf  = chan.buffer
        self.assertEquals( BUFSIZE, len(buf) )

        # create the LogEntryMsg class ------------------------------

        Clz     = makeMsgClass(self.protoName, msgSpec)

        # __setattr__ in MetaMessage raises exception on any attempt
        # to add new attributes
        try:
            Clz.foo = 42
            self.fail(
                "ERROR: attempt to assign new class attribute succeeded")
        except AttributeError as ae:
            
            # DEBUG
            print "success: attr error attempting to set Clz.foo: " + str(ae)
            # END
            pass

        print '\nClz CLASS DICTIONARY'
        for e in Clz.__dict__.keys():
            print "%-20s %s" % (e, Clz.__dict__[e])

        # create a message instance ---------------------------------
        # some random values 
        values  = self.leMsgValues()
        leMsg   = Clz( values )
        
        # __setattr__ in MetaMessage raises exception on any attempt
        # to add new attributes.  This works at the class level but
        # NOT at the instance level
        if False:
            try:
                leMsg.foo = 42
                self.fail(
                    "ERROR: attempt to assign new instance attribute succeeded")
            except AttributeError as ae:
                # DEBUG
                print "ATTR ERROR ATTEMPTING TO SET leMsg.foo: " + str(ae)
                # END
                pass

        if '__dict__' in dir(leMsg):
            print '\nleMsg INSTANCE DICTIONARY'
            for e in leMsg.__dict__.keys():
                print "%-20s %s" % (e, leMsg.__dict__[e])

        # leMsg.name is a property
        try:
            leMsg.name = 'boo'
            self.fail("ERROR: attempt to change message name succeeded")
        except AttributeError:
            pass

        self.assertEquals(msgSpec.name, leMsg.name)
        # we don't have any nested enums or messages
        self.assertEquals(0, len(leMsg.enums))
        self.assertEquals(0, len(leMsg.msgs))

        self.assertEquals(5, len(leMsg.fieldClasses))
        self.assertEquals(5, len(leMsg))        # number of fields in instance
        for i in range(len(leMsg)):
            self.assertEquals(values[i], leMsg[i].value)

        # serialize the object to the channel -----------------------
        leMsg.putToChan(chan)

        # DEBUG
        leMsg.getFromChan(chan) # outputs debug messages
        # END

        # create a second LogEntryMsg instance, ---------------------
        # associating it with the data channel (and setting the limit 
        # on that channel to the end of the buffer)
        # XXX STUB XXX

        # verify that the two LogEntryMsgs are equal ----------------
        # XXX STUB XXX                                          # GEEP
        
if __name__ == '__main__':
    unittest.main()

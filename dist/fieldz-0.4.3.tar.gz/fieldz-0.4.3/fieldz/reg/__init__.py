# ~/dev/py/fieldz/reg/__init__.py

from fieldz.msgSpec import validateSimpleName, validateDottedName
import fieldz.typed         as T
import fieldz.fieldTypes    as F
import fieldz.coreTypes     as C
import fieldz.msgSpec       as M

__all__ = [ \
#           'Registry', 
            'NodeRegEntry', 
            'FieldTypeEntry', 
            'CoreTypeEntry', 
#           'MsgSpecEntry',
#           'ProtoSpecEntry',

            # new stuff; there will be some merging with existing types
            'NodeReg',  'ProtoEntry', 
            'ProtoReg'  'MsgEntry',
            'MsgReg',   'EnumEntry',
#            'EnumSpecEntry',                # now vestigial ?
        ]

# BEGIN NEW CLASSES =================================================

class UniqueNameRegistry(object):
    """ 
    An abstract calls which can be used with both the NodeReg and the 
    ProtoReg, because both control regID generation, but not in this
    form with the MsgReg, which needs to obtain regIDs from the parent
    registry.
    """
    def __init__(self):
        self._entries       = []    # regID -> name, where regID is index
        self._name2RegID    = {}    # name  -> regID, must be unique
        self._nextRegID     = 0

    @property
    def nextRegID(self):
        return self._nextRegID

    def __len__(self):
        return len(self._entries)

    def __getitem__(self, i):
        """ returns the actual entry, which is not immutable """
        return self._entries[i]

    def name2RegID(self, name):
        return self._name2RegID[name]

    def register(self, whatever):
        """ subclasses must override """
        raise NotImplementedError() # this is an abstract class

class NodeReg(UniqueNameRegistry):
    """ maintains the list of protocols known to the node """
    def __init__(self):
        super(NodeReg, self).__init__()

        # if newer versions of protocols have the same name, newer 
        # replace older (but older may still be present and reachable
        # by hash)

        self._protosByHash  = {}    # hash  -> regID: must be unique
        self._regID2Hash    = {}    # regID -> content key

        # these are associated with fieldTypes and core classes, and may
        # be utterly pointless now
        self._putter     = []   # methods, write instance field type to buffer
        self._getter     = []   # methods, get instance field type from buffer
        self._lenFunc    = []
        self._pLenFunc   = []

        # initialize the lists above 
        self.bootstrap()

    def register(self, protoSpec):
        """ 
        We convert the protoSpec to canonical form, then hash that
        to get the content key that uniquely identifies the protocol.
        """
        if protoSpec is None:
            raise ValueError('protoSpec cannot be None')

        # reduce the spec to canonical form
        canonical = None                # XXX STUB

        # ....

        # create a ProtoEntry
        protoEntry = None               # XXX STUB

        # register it
        regID = None
        if protoEntry is not None:
            regID = self._register(protoEntry)
        return regID

    def _register(self, entry):
        """ used to register both protoSpecs and basic types """

        # creation of the entry has used the next free regID
        self._nextRegID += 1            # so we step it
        self._entries.append(entry)
        name = entry.qualName

        # we maintain a list of type names
        # self._qualNames.append( name )
#       self._qName2regID[name] = entry.regID
        self._name2RegID[name] = entry.regID

#       # DEBUG
#       print "%-20s => regiID %d" % (name, entry.regID)
#       # END
    
    def _registerBasicType(self, entry):
        # THIS IS A HACK, to make things compile
        self._register(entry)

    def bootstrap(self):
        # register the names of the core elements: field types and the
        # core classes
        
        # -- add fieldTypes -----------------------------------------
        for i in range(F.maxNdx + 1):
            entry = FieldTypeEntry(
                        self,               # reg 
                        F.asStr(i),         # qualName, 
                        T.tPutFuncs[i],     # putter, 
                        T.tGetFuncs[i])     # getter, 
            self._registerBasicType(entry)

        # self._nextRegID = F.maxNdx    # redundant and wrong anyway
        for i in range(C.maxNdx + 1):
            entry = CoreTypeEntry(
                        self,               # reg 
                        C.asStr(i),         # qualName, 
                        M.cPutFuncs[i],     # putter, 
                        M.cGetFuncs[i],     # getter, 
                        M.cLenFuncs[i],     # getter, 
                        M.cPLenFuncs[i])    # getter, 
            self._registerBasicType(entry)


# -- MERGE INTO ABOVE, POSSIBLY ABSTRACTING SOME OF IT --------------
class xxxRegistry(object):

    def __init__(self):
        self._entries    = []

        self._qualNames  = []   # unique qualified (dotted) name list
        self._qName2regID = {}   # qualified name to content key
        # content key is hash of canonical string version of object
        self._qName2hash = {}   # qualified name to content key
        self._hash2regID = {}   # content key to unique ID


    def register(self, qName, rCanonical, putter, getter, lenFunc, pLenFunc):
        """ 
        Add a type to the registry's internal tables.  The canonical
        string serialization of the type is used to calculate a content
        key (160 bit SHA1 or 256 bit SHA3) for the type.  The caller
        must provide a putter, a method for serializing an instance of
        the type into a bytearray, and a getter, a method for deserializing
        an instance from a bytearray.
        """
        
        # XXX STUB - add some validation
       
        # THIS IS NOW JUST WRONG: 
        entry = _DefinedNodeRegEntry( qName, rCanonical, putter, getter, lenFunc, pLenFunc )
        self._register(entry)       # _uses_ the next free regID
        return entry._regID         # GEEP

    def _register(self, entry):
        # creation of the entry has used the next free regID
        self._nextRegID += 1            # so we step it
        self._entries.append(entry)
        name = entry.qualName

        # we maintain a list of type names
        self._qualNames.append( name )
        self._qName2regID[name] = entry.regID

#       # DEBUG
#       print "%-20s => regiID %d" % (name, entry.regID)
#       # END

        # we map names to the rCanonical hash  (which may be null)
        self._qName2hash[name] = entry.rCanonical

        # and we main a reverse map
        if entry.rCanonical is not None:
            self._hash2regID[entry.rCanonical] = entry.regID


# FOO

# -- BASIC TYPES, ALSO IN NODE REGISTRY -----------------------------

# THIS SHOULD BE AN ABSTACT CLASS 
class NodeRegEntry(object):
    __slots__ = [ '_id', '_qualName', '_putter', '_getter', 
                                      '_lenFunc', '_pLenFunc',]

    def __init__(self, reg, qualName, putter, getter, 
                                      lenFunc=None, pLenFunc=None):
        # XXX CURRENTLY NOT USED
        if reg is None:         raise ValueError('reg may not be None')
        # END NOT USED

        if qualName is None:    raise ValueError('qualName may not be None')
        if putter is None:      raise ValueError('putter may not be None')
        if getter is None:      raise ValueError('getter may not be None')
        # lenFunc and pLenFunc may be None

        validateDottedName(qualName)
        # XXX if the name is dotted the protocol must be defined.
        self._qualName      = qualName

        # XXX these must be methods with the right signature :-)
        self._putter        = putter
        self._getter        = getter
        self._lenFunc       = lenFunc
        self._pLenFunc      = pLenFunc

        # XXX THIS IS A BAD IDEA.  If the entry cannot be created, we don't
        # want to have allocated an ID.  So create the entry and then 
        # register it, allocating an ID at registration time
        self._id = reg.nextRegID             # MOVE ME XXX

    @property
    def regID(self):        return self._id
    @property
    def qualName(self):     return self._qualName
    @property
    def putter(self):       return self._putter
    @property
    def getter(self):       return self._getter
    @property
    def lenFunc(self):      return self._lenFunc
    @property
    def pLenFunc(self):     return self._pLenFunc               # GEEP

class FieldTypeEntry(NodeRegEntry):
    def __init__(self, reg, qualName, putter, getter):
        super(FieldTypeEntry, self).__init__(reg, qualName, putter, getter)
    @property
    def rCanonical(self):   return None


class CoreTypeEntry(NodeRegEntry):
    __slots__ = [ '_rCanonical',  ]
    def __init__(self, reg, qualName, putter, getter, lenFunc, pLenFunc):
        super(CoreTypeEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)

        # XXX STUB

    @property
    def rCanonical(self):   return None                         # FOO

# -- PROTOCOLS ------------------------------------------------------
class ProtoEntry(object):
    """ contains information about specific protocol """
    def __init__(self, nodeReg, protoSpec):
        self._nodeReg   = nodeReg       # not actually used 
        self._protoSpec = protoSpec
        self._reg       = ProtoReg(nodeReg) 

class ProtoReg(UniqueNameRegistry):
    """ contains information about specific protocol """
    def __init__(self, nodeReg):
        super(ProtoEntry, self).__init__()
        self._nodeReg   = nodeReg   # where to look to resolve protocol names
        self._enums     = []
        self._msgs      = []
        self._byName    = {}        # names local to this proto spec

# -- MESSAGES -------------------------------------------------------
class MsgEntry(object):
    """ contains information about a MsgSpec (which might be nested) """
    def __init__(self, protoReg, msgSpec):
        self._msgSpec   = msgSpec
        self._reg       = MsgReg(self) 
        pass

class MsgReg(object):
    """ 
    Like a UniqueNameRegistry, but gets regIDs and name uniqueness
    guarantees from its ultimate parent, the protoReg.
    """

    def __init__(self, protoReg):
        self._protoReg  = protoReg  # where to look if we can't resolve a name
        self._enums     = []        # enum specs nested within this msg spec
        self._msgs      = []        # message specs nested within this one
        self._byName    = {}        # names local to this message spec
        # self.append(primum)

    # XXX 'in' uses a linear search based on __getitem__ rather than
    # the byName index.
#   def __getitem__(self, k):
#       if k < 0:
#           raise ValueError('index is out of range: %s' % str(k))
#       if k >= len(self._enums):
#           # Python uses this to detect the end of the range
#           raise IndexError()
#       return self._enums[k]

    # ILL-ADVISED 
    def __len_(self):
        return len(self._enums) 

    # XXX what's added can be either a MsgSpec or an EnumSpec
    def append(self, enum):
        if enum is None:
            raise ValueError('cannot add null enum')
        name = enum.name
        if name in self._byName:
            raise KeyError("we already have an enum '%s'" % name)

        entry = EnumEntry( enum, len(self._enums) )
        self._byName[name] = entry
        self._enums.append(entry)
        # DEBUG
        print "added '%s' to enumReg" % name
        # END

#   def ndx(self, name):
#       if name in self._byName:
#           return self._byName[name].ndx
#       else:
#           return None

# -- ENUMS ----------------------------------------------------------
class EnumEntry(object):
    __slots__ = ['_enum', '_ndx', ]

    def __init__(self, enum, ndx):
        self._enum = enum               # an EnumSpec
        self._ndx  = ndx

    @property
    def enum(self):     return _enum
    @property
    def ndx(self):      return _ndx

# -- consolidate into EnumEntry or just drop ------------------------
#class EnumSpecEntry(NodeRegEntry):
#    __slots__ = [ '_rCanonical',  ]
#    def __init__(self, reg, qualName, rCanonical, putter, getter, lenFunc, pLenFunc):
#        super(EnumSpecEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)
#        if rCanonical is None:  raise ValueError('rCanonical may not be None')
#        self._rCanonical    = rCanonical
#
#        # XXX STUB
#
#    @property
#    def rCanonical(self):   return self._rCanonical


# == OLD CODE =======================================================



#class MsgSpecEntry(NodeRegEntry):
#    __slots__ = [ '_rCanonical',  ]
#    def __init__(self, reg, qualName, rCanonical, putter, getter, lenFunc, pLenFunc):
#        super(EnumSpecEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)
#        if rCanonical is None:  raise ValueError('rCanonical may not be None')
#        self._rCanonical    = rCanonical
#
#        # XXX STUB
#
#    @property
#    def rCanonical(self):   return self._rCanonical
#
#class ProtoSpecEntry(NodeRegEntry):
#    __slots__ = [ '_rCanonical',  ]
#    def __init__(self, reg, qualName, rCanonical, putter, getter, lenFunc, pLenFunc):
#        super(EnumSpecEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)
#        if rCanonical is None:  raise ValueError('rCanonical may not be None')
#        self._rCanonical    = rCanonical
#
#        # XXX STUB
#
#    @property
#    def rCanonical(self):   return self._rCanonical
#

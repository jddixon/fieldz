# fieldz/__init__.py

__version__         = '0.2.3'
__version_date__    = '2012-08-31'

__all__ = [ '__version__',      '__version_date__',
]

#!/usr/bin/python

# testFieldTypes.py
import time, unittest

from rnglib     import SimpleRNG
import fieldz.fieldTypes as F

class TestFieldTypes (unittest.TestCase):
    """ 
    Actually tests the method used for instantiating and importing
    an instance of the FieldTypes class.
    """

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################

    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print


    # actual unit tests #############################################
    def testConstants(self):
        self.assertEquals( 0, F._V_BOOL    ) 
        self.assertEquals(17, F._F_BYTES32 )
        try:
            F._V_BOOL = 47
        except RuntimeError as e:
            print 'caught attempt to reassign constant'
            pass

if __name__ == '__main__':
    unittest.main()

# fieldz/msgSpec.py

import re, sys
from fieldz.raw   import  *
from fieldz.typed import  *
import fieldz.fieldTypes    as F
import fieldz.coreTypes     as C

__all__ = [  \
            # constants, so to speak: quantifiers
            'Q_REQUIRED',   # no quantifier, so one and only one such field
            'Q_OPTIONAL',   # ?: either zero or one instance of the field
            'Q_STAR',       # *: zero or more instances of the field allowed
            'Q_PLUS',       # +: one or more instances of the field

            # methods
            'qName',        'validateSimpleName',   'validateDottedName',

            # class-level
            'cPutFuncs', 'cGetFuncs', 'cLenFuncs',  

            'enumPairSpecPutter',   'enumSpecPutter',   'fieldSpecPutter',
            'msgSpecPutter',        'seqSpecPutter',    'protoSpecPutter',

            'enumPairSpecGetter',   'enumSpecGetter',   'fieldSpecGetter',
            'msgSpecGetter',        'seqSpecGetter',    'protoSpecGetter',

            'enumPairSpecLen',      'enumSpecLen',      'fieldSpecLen',
            'msgSpecLen',           'seqSpecLen',       'protoSpecLen',

            # classes
            'EnumPairSpec',
            'EnumSpec',             'FieldSpec',            'MsgSpec',
            'ProtoSpec',            'SeqSpec',
            'StringMsgSpecParser',
            'WireMsgSpecParser',    'WireMsgSpecWriter',
          ]

Q_REQUIRED  = 0
Q_OPTIONAL  = 1
Q_STAR      = 2
Q_PLUS      = 3

Q_NAMES     = ['', '?', '*', '+',]
def qName(n):
    if n < 0 or n >= len(Q_NAMES):
        raise ValueError('does not map to a valid quantifier: %s' % str(n))
    return Q_NAMES[n]

# base names, forming part of a larger pattern
_VALID_NAME_PAT = "[a-zA-Z_][a-zA-Z_0-9]*"
_VALID_NAME_RE  = re.compile(_VALID_NAME_PAT)

# just base names; match will fail if any further characters follow
_VALID_SIMPLE_NAME_PAT = _VALID_NAME_PAT + '$'
_VALID_SIMPLE_NAME_RE  = re.compile(_VALID_SIMPLE_NAME_PAT)

def validateSimpleName(s):
    m = _VALID_SIMPLE_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid simple name '%s'" % s)

# both protocol names and field names can be qualified
_VALID_DOTTED_NAME_PAT = _VALID_NAME_PAT + '(\.' + _VALID_NAME_PAT + ')*$'
_VALID_DOTTED_NAME_RE  = re.compile(_VALID_DOTTED_NAME_PAT)

def validateDottedName(s):
    m = _VALID_DOTTED_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid (optionally dotted) name '%s'" % s)


# -- CLASSES --------------------------------------------------------
class EnumPairSpec(object):
    __slots__ = ['_symbol', '_value',]
    def __init__(self, symbol, value):
        validateSimpleName(symbol)
        self._symbol    = symbol
        self._value     = int(value)

    @property
    def symbol(self):           return self._symbol
    @property
    def value(self):            return self._value

    def __eq__(self, other):
        if other is None or not isinstance(other, EnumPairSpec):
            print 'XXX None or not EnumPairSpec'
            return False
        if (self._symbol != other._symbol) or (self._value  != other._value):
            print 'XXX symbol or value differs'
            return False
#       print 'XXX pairs match'
#       print "  my    self:  %s" % self
#       print "  other other: %s" % other
        return True

    def __str__(self):
        """ return a usable representation of the EnumPairSpec """
        return '%s = %d' % (self._symbol, self._value)

    def __repr__(self):
        """ return the EnumPairSpec in today's notion of the canonical form """
        return '%s=%d' % (self._symbol, self._value)

class EnumSpec(object):
    """
    For our purposes an enum is a named list of simple names (names
    containing no delimiters)` and a map from such names to their
    non-negative integer values.
    """
    __slots__ = ['_name', '_pairs', '_sym2pair', '_size', ]
    def __init__(self, name, pairs):
        """pairs are EnumPairSpecs """
        validateDottedName(name)
        self._name = name
        if pairs is None:
            raise ValueError('null list of enum pairs')
        if len(pairs) == 0:
            raise ValueError('empty list of enum pairs')
        self._pairs     = []
        self._sym2pair  = {}
        for pair in pairs:
            sym = pair.symbol
            val = pair.value
            if sym in self._sym2pair:
                raise ValueError("already in EnumSpec: '%s'" % sym)
            self._pairs.append(pair)
            self._sym2pair[sym] = pair
        self._size = len(self._pairs)  # which should be the same as i

    @classmethod
    def create (cls, name, pairs):
        """pairs are 2-tuples, (symbol, value), where value is uInt16 """
        validateDottedName(name)
        if pairs is None:
            raise ValueError('null list of enum pairs')
        if len(pairs) == 0:
            raise ValueError('empty list of enum pairs')

        _pairs = []
        for pair in pairs:
            sym = pair[0]
            val = pair[1]
            p   = EnumPairSpec(sym, val) 
            _pairs.append(p)
        return EnumSpec(name, _pairs)

    def value(self, s):
        """ map a name to the corresponding value """
        return self._sym2pair[s].value

    @property
    def name(self):     return self._name

    # def pair(self, k):
    def __getitem__(self, k):
        return self._pairs[k]

    # XXX DOES NOT FOLLOW PYTHON CONVENTION
    @property
    def size(self):     return self._size

    def __eq__(self, other):
        if other is None or not isinstance(other, EnumSpec):
            return False
        if other is self:
            return True
        if other._name != self._name:
            return False
        if len(self._pairs) != len(other._pairs):
            return False
        for i in range(self._size):
            #if self[i] != other[i]:
            if self[i].symbol != other[i].symbol or \
                    self[i].value != other[i].value:
#               print "ENUM_PAIR_SPECS DIFFER:"
#               print "  my    pair %u: %s" % (i, self[i])
#               print "  other pair %u: %s" % (i, other[i])
                return False
        return True

    def __str__(self):
        """ return a usable representation of the EnumSpec """
        s = [] 
        s.append('%s ' % self._name)
        for pair in self._pairs:
            s.append('%s ' % pair)
        return '' . join(s)
    def __repr__(self):
        """ return the EnumSpec in today's notion of the canonical form """
        # XXX THIS IS WRONG XXX
        # return ',' . join(self._pairs)                      # GEEP
        return self.__str__()


class FieldSpec(object):
    __slots__ = [ '_name', '_type', '_quantifier', '_fieldNbr', '_default', ]

    def __eq__(self, other):
        if other is None or not isinstance(other, FieldSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
        if other._name != self._name:
            return False
        if other._type != self._type:
            return False
        if other._quantifier != self._quantifier:
            return False
        if self._fieldNbr:
            if other._fieldNbr is None:
                return False
            if self._fieldNbr != other._fieldNbr:
                return False

        # XXX IGNORE DEFAULTS FOR NOW

        return True


    def __init__(self, name, fType, quantifier=Q_REQUIRED,
                                        fieldNbr=None, default=None):
        # -- name ---------------------------------------------------
        if name is None:
            raise ValueError('no field name specified')
        validateDottedName(name)
        self._name = name

        # -- fType --------------------------------------------------
        if fType is None:
            raise ValueError('no field type specified')
        tNdx = F.ndx(fType)
        if tNdx is None:
            # print "DEBUG: '%s' maps to %s" % (fType, str(tNdx))
            raise ValueError("'%s' is not a field type" % fType)
        self._type = tNdx

        # -- quantifier ---------------------------------------------
        # XXX BAD RANGE CHECK
        if quantifier < 0 or quantifier > Q_PLUS:
            raise ValueError("invalid quantifier '%s'" % str(quantifier))
        self._quantifier = quantifier

        # -- fieldNbr -----------------------------------------------
        self._fieldNbr = int(fieldNbr)

        # -- default ------------------------------------------------
        # if default is None, could provide a default appropriate for the type
        # XXXif we are going to support a default value, it needs to be
        #   validated
        # XXX STUB
        if default is not None:
            raise NotImplementedError('default for FieldSpec')
        self._default = default

    @property
    def name(self):         return self._name

    # XXX return a string value
    @property
    def fTypeName(self):    return F.asStr(self._type)

    # XXX return a number
    @property
    def fTypeNdx(self):     return self._type

    @property
    def quantifier(self):   return self._quantifier
    #def quantifier(self):   return Q_NAMES[self._quantifier]

    @property
    def fieldNbr(self):     return self._fieldNbr

    @property
    def default(self):      return self._default

    def __str__(self):
        """ return a prettier representation of the FieldSpec """

        # KEEP THIS IN SYNC WITH __repr__

        s = []
        # assume the caller does any indenting
        s.append('%-20s ' % self._name)

        tName = self.fTypeName
        if self._quantifier != Q_REQUIRED:
            tName += qName(self._quantifier)
        s.append('%-12s' % tName)               # at least one space

        if self._fieldNbr is not None:
            s.append(' @%d ' % self._fieldNbr)  # again, at least one space

        #========================
        # XXX default not handled
        #========================

        return '' . join(s)                 # GEEP

    def __repr__(self):
        """
        Return the FieldSpec in today's notion of the canonical form.
        This doesn't have to be pretty, just absolutely clear and
        unambiguous.
        """

        # KEEP THIS IN SYNC WITH __str__

        s = []
        # assume the caller does any indenting
        s.append(self._name)
        s.append(' ')

        tName = self.fTypeName
        if self._quantifier != Q_REQUIRED:
            tName += qName(self._quantifier)
        s.append(tName)
        s.append(' ')

        if self._fieldNbr is not None:
            s.append('@%d ' % self._fieldNbr)  # at least one space

        #========================
        # XXX default not handled
        #========================

        return '' . join(s)                 # GEEP

class MsgSpec(object):
    """
    A message is specified as an acceptable sequence of typed fields.
    Each field has a 1-based index, a name, and a type.  Later it will
    have a default value.

    Serialized, a message spec begins with the name of the message,
    which is a lenPlus string; this must be either a simple name
    containing no delimiters or it may be a sequence of simple names
    separated by dots ('.').  This is followed by individual field
    specs, each of which is a lenPlus names followed by colon (':')
    followed by a fieldType.

    """
    def __init__(self, protocol, name, fields, enum=None):
        # -- protocol -----------------------------------------------
        if protocol is None:
            raise ValueError('missing protocol declaration')
        validateDottedName(protocol)
        self._protocol = protocol

        # -- msgSpec name -------------------------------------------
        if name is None:
            raise ValueError('missing protocol declaration')
        validateSimpleName(name)
        self._name = name
        self._fields = []

        # -- fields -------------------------------------------------
        ndx             = 0
        self._nameToNdx = {}

        for f in fields:
            fName = f.name
            if fName in self._nameToNdx:
                # we will just ignore any fields with duplicate names
                continue
            if not isinstance(f, FieldSpec):
                raise ValueError("'%s' is not a FieldSpec!" % fName)
            self._fields.append(f)
            self._nameToNdx[fName] = ndx
            ndx += 1
        self._size = ndx

        # -- enum ---------------------------------------------------
        if enum is not None and not isinstance(enum, EnumSpec):
            raise ValueError('not an EnumSpec')
        # we allow this to be None
        self._enum = enum

    # redundant but seems sensible; could return _fields[0].name
    @property
    def protocol(self):     return self._protocol

    @property
    def name(self):         return self._name

    @property
    def size(self):         return self._size

    def fName(self, i):
        if i < 0 or i > self._size:
            raise ValueError('field number out of range')
        return self._fields[i].name

    def fTypeName(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')
        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeName

    def fTypeNdx(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')

        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeNdx

    def fDefault(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')
        return self._fields[i].default

    # -- serialization ----------------------------------------------
    def __eq__(self, other):
        if other is None or not isinstance(other, MsgSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
        if other._protocol != self._protocol:
            return False
        if other._name != self._name:
            return False
        if self._size == 0 or other._size == 0:
            return False
        if self._size != other._size:
            return False
        for n in range(self._size):
            if not self._fields[n].__eq__(other._fields[n]):
                return False
        return True

    def __str__(self):
        """ return string representation in perhaps prettier format """
        s = []
        s.append( "protocol %s\n\n" % self._protocol)
        s.append( "message %s\n"    % self._name)
        for f in self._fields:
            s.append( "    %s\n" % f.__str__())

        return ''.join(s)

    def __repr__(self):
        """ return string representation in canonical format """
        s = []
        s.append( "protocol %s\n"   % self._protocol)
        s.append( "message %s\n"    % self._name)
        for f in self._fields:
            s.append( "  %s\n" % f.__repr__())

        return ''.join(s)

class ProtoSpec(object):
    """
    A protocol is a set of message types, enumerations, and acceptable
    message sequences.  It is essential for our purposes that any
    protocol can be constructed dynamically from its wire serialization.

    """

    def __init__(self, name):
        if name is None:
            raise ValueError('missing protocol name')
        validateDottedName(name)
        self._name = name

        # XXX STUB


    def __str__(self):
        raise NotImplementedError('__str__ for ProtoSpec')

    def __repr__(self):
        raise NotImplementedError('__repr__ for ProtoSpec')

class SeqSpec(object):
    """

    """
    def __init__(self):
        pass
        # XXX STUB


    def __str__(self):
        raise NotImplementedError('__str__ for SeqSpec')

    def __repr__(self):
        raise NotImplementedError('__repr__ for SeqSpec')


# == PARSERS AND WRITERS ============================================

# -------------------------------------------------------------------
class StringMsgSpecParser(object):
    """
    Reads a human-readable MsgSpec (a *.msgSpec file) to produce a
    MsgSpec object model, which is a MsgSpec with FieldSpecs and EnumSpecs
    dangling off of it.
    """
    def __init__(self, fd):
        # XXX should die if fd not open
        self._fd            = fd
        self._protocol      = None
        self._name          = None
        self._enum          = None
        self._fields        = []

        self._nextFieldNbr  = 0

    def getLine(self):
        while True:
            line = self._fd.readline()

            # The first condition never fails if fd is a file-like object
            # (from StringIO)
            if line is None or line == '':
                return None

            # strip off any comments
            s   = line.partition('#')[0]

            # get rid of any trailing blanks
            line = s.rstrip()
            if line != '':
                return line

    def expectTokenCount(self, tokens, kind, n):
        if len(tokens) != n:
            raise RuntimeError("too many tokens in %s line '%s'" % (
                                                            kind,tokens))

    def expectProtocol(self):
        line  = self.getLine()
        words = line.split()
        self.expectTokenCount(words, 'protocol', 2)
        if words[0] == 'protocol':
            validateDottedName(words[1])
            self._protocol = words[1]
            # print "DEBUG: protocol is '%s'" % str(self._protocol)
        else:
            raise RuntimeError("expected protocol line, found '%s'" % line)

    def expectMsgSpecName(self):
        line  = self.getLine()
        words = line.split()
        self.expectTokenCount(words, 'protocol', 2)
        if words[0] == 'message':
            self._name = words[1]
            if self._name[-1] == ':':
                self._name = self._name[:-1]
            validateSimpleName(self._name)
            # print "DEBUG: msgSpec name is '%s'" % str(self._name)
        else:
            raise RuntimeError("expected message line, found '%s'" % line)

    def acceptEnum(self):
        # XXX STUB XXX
        # I think we need to return a line, but just do nothing for now
        self._enum = None

    def expectField(self, line):
        # for now, ignore any indentation
        line  = line.lstrip()

        # accept NAME FTYPE(Q)? (@N)? (=DEFAULT)?

        words = line.split()
        wordCount = len(words)

        if wordCount < 2:
            raise RuntimeError("too few tokens in field def '%s'" % line)
        if wordCount > 4:
            raise RuntimeError("too many tokens in field def '%s'" % line)

        # -- field name -------------------------
        fName   = words[0]
        validateSimpleName(fName)

        # -- quantifier -------------------------
        q = words[1][-1]
        if q == '?' or q == '*' or q == '+':
            words[1]    = words[1][:-1]
            if   q == '?':  quantifier = Q_OPTIONAL
            elif q == '*':  quantifier = Q_STAR
            else         :  quantifier = Q_PLUS
        else:
            quantifier  = Q_REQUIRED

        # -- field type --------------------------
        fType   = words[1]
        if F.ndx(fType) is None:
            # may be the name of a message type, possibly from another protocol
            validateDottedName(fType)

        # XXX NAME OF MESSAGE TYPE NOT HANDLED ???

        # -- field number -----------------------
        fieldNbr = self._nextFieldNbr
        if wordCount >2:
            if words[2].startswith('@'):
                fieldNbr = int(words[2][1:])    # could use some validation
                if fieldNbr < self._nextFieldNbr:
                    raise ValueError('field number <= last field number')
        self._nextFieldNbr = fieldNbr + 1

        # -- default ----------------------------
        # XXX STUB - NOT IMPLEMENTED YET

        return FieldSpec(fName, fType, quantifier, fieldNbr)

    def expectFields(self):
        # they get appended to self._fields; there must be at least one
        line  = self.getLine()
        if line is None or line == '':
            raise RuntimeError('no fields found')
        self._fields.append( self.expectField(line) )

        line = self.getLine()
        while line is not None and line != '':
            self._fields.append( self.expectField(line) )
            line = self.getLine()

    def parse(self):
        self.expectProtocol()
        self.expectMsgSpecName()
        self.acceptEnum()
        self.expectFields()
        return MsgSpec(self._protocol, self._name, self._fields, self._enum)

# POSSIBLY SUPERCLASS IS TFReader
class WireMsgSpecParser(object):
    """
    Reads a MsgSpec fully serialized to wire form (and so a sequence of
    fieldz) produce a MsgSpec object model, which is a MsgSpec with
    FieldSpecs and EnumSpecs dangling off of it.
    """
    def __init__(self, w):
        pass

# POSSIBLY SUPERCLASS IS TFBuffer OR TFWriter
class WireMsgSpecWriter(object):
    """
    Given a MsgSpec (including attached FieldSpecs and optional EnumSpecs)
    produces a serialization using FieldTypes.
    """

    def __init__(self, mSpec, wb):
        if mSpec is None:
            raise ValueError('no MsgSpec identified')
        self._m = mSpec

        if wb is None:
            raise ValueError('no WireBuffer specified')
        self._wb = wb

    def write(self):

        # THIS SHOULD JUST USE TFWriter, OR ITS BITS AND PIECES.
        # To use TFWriter in its current form, we need a wired-in class
        # definition, say MsgSpecClz.
        # Alternatively, put the putNext methods into a dispatch table
        # and invoke them through that table.

        # protocol
        # name
        # enum
        # fields

        pass

# DISPATCH TABLES ===================================================

# XXX dunno why notImpl is not picked up by 
#                                          from fieldz.typed import *
def notImpl(*arg):     raise NotImplementedError

cPutFuncs = [notImpl]*(C.maxNdx + 1)
cGetFuncs = [notImpl]*(C.maxNdx + 1)
cLenFuncs = [notImpl]*(C.maxNdx + 1)

# PUTTERS, GETTERS, LEN FUNCS ---------------------------------------

lStringLen = tLenFuncs[F._L_STRING]
lStringPut = tPutFuncs[F._L_STRING]
vuInt32Len = tLenFuncs[F._V_UINT32]
vuInt32Put = tPutFuncs[F._V_UINT32]

# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# LEN PARAMETERS MUST BE (val, n), where n is the field number
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

def enumPairSpecLen(val, n):
    """
    val is guaranteed to be a well-formed EnumPair object; this is 
    the length of the spec on the wire, what is written before the spec.
    Returns a 2-tuple containing first the byte count and then that plus
    the header lengths.
    """
    h = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    byteCount = lStringLen(val.symbol, n) + vuInt32Len(val.value, n)
    return (byteCount, h + lengthAsVarint(byteCount) + byteCount)

# val = instance of the type, n = field number
def enumPairSpecPutter(buf, pos, val, n):
    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "AFTER WRITING HEADER pos = %u" %  pos
  
    # write the byte count
    count = enumPairSpecLen(val, n)[0]
    pos = writeRawVarint( buf, pos, count)
#   print "AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)
   
    # write field 0, the symbol
    pos = lStringPut( buf, pos, val.symbol, 0 ) 
#   print "AFTER WRITING SYMBOL %s pos = %u" % ( val.symbol, pos)
    
    # write field 1, the value
    pos = vuInt32Put( buf, pos, val.value,  1 ) 
#   print "AFTER WRITING VALUE %u pos = %u" % (val.value, pos)
    return pos

def enumPairSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount           # XXX should use for validation

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    sym = str(s)                        # convert bytearray to str

    # read field 1
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (val,pos) = readRawVarint(buf, pos)

    # construct the EnumPairSpec object from field values
    obj = EnumPairSpec(sym, val)
    return (obj, pos)

cLenFuncs[C._ENUM_PAIR_SPEC] = enumPairSpecLen
cPutFuncs[C._ENUM_PAIR_SPEC] = enumPairSpecPutter
cGetFuncs[C._ENUM_PAIR_SPEC] = enumPairSpecGetter

# ---------------------------------------------------------
def enumSpecLen(val, n):
    # val is guaranteed to be a well-formed EnumSpec object

    # we are going to write the header, then a byte count, then the enum
    # name, then one or more EnumPairSpecs
    h       = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE)) 

    count   = lStringLen(val.name, 0)           # field 0 contribution
    for k in range(val.size):
        pair = val[k]
        count += enumPairSpecLen(pair, 1)[1]    # field 1 contribution(s)

    return (count, h + lengthAsVarint(count) + count)

def enumSpecPutter(buf, pos, val, n):
    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "AFTER WRITING HEADER pos = %u" %  pos
  
    # write the byte count
    count = enumSpecLen(val, n) [0]
    pos = writeRawVarint( buf, pos, count)
#   print "AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write the enum's name
    pos = lStringPut(buf, pos, val.name, 0)             # field 0
    
    # write the pairs
    for k in range(val.size):
        #pos = enumPairSpecPutter(buf, pos, val.pair(k), n)
        pos = enumPairSpecPutter(buf, pos, val[k], 1)   # field 1 instances
#   print "END IS AT %u" % end      # XXX  
   
    return pos

def enumSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount           # XXX should use for validation

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    name = str(s)                        # convert bytearray to str

    # read instances of field 1: should enforce the + quantifier here
    pairs = []
    while pos < end:
        (hdr, pos0) = readRawVarint(buf, pos)
        if hdrFieldNbr(hdr) != 1:
            # XXX SHOULD COMPLAIN IF WRONG HEADER
            # XXX This is a a peek: pos only gets advanced if OK
            print "EXPECTED FIELD 1, FOUND %s" % hdrFieldNbr(hdr)
            break
        (e,pos) = enumPairSpecGetter(buf, pos0)
        pairs.append(e)

    # create EnumSpec instance, which gets returned
    val = EnumSpec(name, pairs)
    return (val, pos)

cLenFuncs[C._ENUM_SPEC] = enumSpecLen
cPutFuncs[C._ENUM_SPEC] = enumSpecPutter
cGetFuncs[C._ENUM_SPEC] = enumSpecGetter

# ---------------------------------------------------------
def fieldSpecLen(val, n):
    # val is guaranteed to be a well-formed fieldSpec object
    # MUST RETURN 2-TUPLE: (byteCount, totalLen)
    pass

def fieldSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def fieldSpecGetter(buf, pos):
     # STUB
     return (val, pos)

cLenFuncs[C._FIELD_SPEC] = fieldSpecLen
cPutFuncs[C._FIELD_SPEC] = fieldSpecPutter
cGetFuncs[C._FIELD_SPEC] = fieldSpecGetter

# ---------------------------------------------------------
def msgSpecLen(val, n):
    # val is guaranteed to be a well-formed msgSpec object
    # MUST RETURN 2-TUPLE: (byteCount, totalLen)
    pass

def msgSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def msgSpecGetter(buf, pos):
     # STUB
     return (val, pos)

cLenFuncs[C._MSG_SPEC] = msgSpecLen
cPutFuncs[C._MSG_SPEC] = msgSpecPutter
cGetFuncs[C._MSG_SPEC] = msgSpecGetter

# ---------------------------------------------------------
def seqSpecLen(val, n):
    # val is guaranteed to be a well-formed seqSpec object
    # MUST RETURN 2-TUPLE: (byteCount, totalLen)
    pass

def seqSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def seqSpecGetter(buf, pos):
     # STUB
     return (val, pos)

cLenFuncs[C._SEQ_SPEC] = seqSpecLen
cPutFuncs[C._SEQ_SPEC] = seqSpecPutter
cGetFuncs[C._SEQ_SPEC] = seqSpecGetter

# ---------------------------------------------------------
def protoSpecLen(val, n):
    # val is guaranteed to be a well-formed protoSpec object
    # MUST RETURN 2-TUPLE: (byteCount, totalLen)
    pass

def protoSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def protoSpecGetter(buf, pos):
     # STUB
     return (val, pos)              # END DISPATCH TABLES

cLenFuncs[C._PROTO_SPEC] = protoSpecLen
cPutFuncs[C._PROTO_SPEC] = protoSpecPutter
cGetFuncs[C._PROTO_SPEC] = protoSpecGetter


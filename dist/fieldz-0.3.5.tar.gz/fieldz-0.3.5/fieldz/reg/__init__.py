# ~/dev/py/fieldz/reg/__init__.py

from fieldz.msgSpec import validateSimpleName, validateDottedName
import fieldz.typed         as T
import fieldz.fieldTypes    as F

__all__ = [ 'Registry', ]

# XXX At least three different types of regEntries, so we need a 
# RegEntry superclass, and then a subclass for the wired-in fieldTypes,
# a second for core types (MsgSpec, FieldSpec, etc), and then a third
# for dynamically created classes

class _RegEntry(object):
    __slots__ = [ '_id', '_qualName', '_putter', '_getter', ]

    def __init__(self, reg, qualName, putter, getter):
        if reg is None:         raise ValueError('reg may not be None')
        if qualName is None:    raise ValueError('qualName may not be None')
        if putter is None:      raise ValueError('putter may not be None')
        if getter is None:      raise ValueError('getter may not be None')

        validateDottedName(qualName)
        # XXX if the name is dotted the protocol must be defined.
        self._qualName      = qualName

        # XXX these must be methods with the right signature :-)
        self._putter        = putter
        self._getter        = getter

        # XXX THIS IS A BAD IDEA.  If the entry cannot be created, we don't
        # want to have allocated an ID.  So create the entry and then 
        # register it, allocating an ID at registration time
        self._id = reg.nextRegID             # MOVE ME XXX

    @property
    def regID(self):        return self._id
    @property
    def qualName(self):     return self._qualName
    @property
    def putter(self):       return self._putter
    @property
    def getter(self):       return self._getter

class _FieldTypeEntry(_RegEntry):
    def __init__(self, reg, qualName, putter, getter):
        super(_FieldTypeEntry, self).__init__(reg, qualName, putter, getter)
    @property
    def rCanonical(self):   return None


class _CoreTypeEntry(_RegEntry):
    __slots__ = [ '_rCanonical',  ]
    def __init__(self, reg, qualName, rCanonical, putter, getter):
        super(_CoreTypeEntry, self).__init__(reg, qualName, putter, getter)
        if rCanonical is None:  raise ValueError('rCanonical may not be None')
        self._rCanonical    = rCanonical

        # XXX STUB

    @property
    def rCanonical(self):   return self._rCanonical

class _DefinedTypeEntry(_RegEntry):
    __slots__ = [ '_rCanonical',  ]
    def __init__(self, reg, qualName, rCanonical, putter, getter):
        super(_DefinedTypeEntry, self).__init__(reg, qualName, putter, getter)
        if rCanonical is None:  raise ValueError('rCanonical may not be None')
        self._rCanonical    = rCanonical

        # XXX STUB

    @property
    def rCanonical(self):   return self._rCanonical

class Registry(object):

    def __init__(self):
        self._entries    = []

        self._qualNames  = []   # unique qualified (dotted) name list
        self._qName2regID = {}   # qualified name to content key
        # content key is hash of canonical string version of object
        self._qName2hash = {}   # qualified name to content key
        self._hash2regID = {}   # content key to unique ID

        # currying could help here
        self._putter     = []   # methods, write instance field type to buffer
        self._getter     = []   # methods, get instance field type from buffer

        self._nextRegID  = 0
        self.bootstrap()

    def register(self, qName, rCanonical, putter, getter):
        """ 
        Add a type to the registry's internal tables.  The canonical
        string serialization of the type is used to calculate a content
        key (160 bit SHA1 or 256 bit SHA3) for the type.  The caller
        must provide a putter, a method for serializing an instance of
        the type into a bytearray, and a getter, a method for deserializing
        an instance from a bytearray.
        """
        
        # XXX STUB - add some validation
        
        entry = _DefinedRegEntry( qName, rCanonical, putter, getter )
        self._register(entry)       # _uses_ the next free regID
        return entry._regID

    # XXX NOT IMMUTABLE
    def entry(self, i):
        return self._entries[i]

    def _register(self, entry):
        # creation of the entry has used the next free regID
        self._nextRegID += 1            # so we step it
        self._entries.append(entry)
        name = entry.qualName

        # we maintain a list of type names
        self._qualNames.append( name )
        self._qName2regID[name] = entry.regID

        # we map names to the rCanonical hash  (which may be null)
        self._qName2hash[name] = entry.rCanonical

        # and we main a reverse map
        if entry.rCanonical is not None:
            self._hash2regID[entry.rCanonical] = entry.regID

    def bootstrap(self):
        """ populate registry tables with standard values """
        # -- add fieldTypes -----------------------------------------
        for i in range(F.maxNdx + 1):
            entry = _FieldTypeEntry(
                        self,           # reg 
                        F.asStr(i),     # qualName, 
                        # pos = putter(buf, pos, val, fieldNbr)
                        T.tPutFuncs[i],  # putter, 
                        # (val, pos) = getter(buf, pos)
                        T.tGetFuncs[i])  # getter, 
            self._register(entry)

        self._nextRegID = F.maxNdx

        # -- load core types from specs/org/xlattice/fieldz/core/* 

        # -- add core types to tables -------------------------------
        pass

    @property
    def nextRegID(self):
        return self._nextRegID

    def qualName2RegID(self, name):
        return self._qName2regID[name]


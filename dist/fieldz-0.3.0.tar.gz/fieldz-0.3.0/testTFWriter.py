#!/usr/bin/python

# testTFWriter.py
import time, unittest

from rnglib         import SimpleRNG

import fieldz.fieldTypes as F
from fieldz.typed   import *
from fieldz.msgSpec import *

# scratch variables
b128 = bytearray(16)
b160 = bytearray(20)
b256 = bytearray(32)

# msgSpec -----------------------------------------------------------
protocol= 'org.xlattice.upax'
name    = 'testMsgSpec'
# no enum is used
fields  = [ \
        # all varint types except enum and boolean
        FieldSpec('i32',        'vInt32'),       # field 0
        FieldSpec('i32bis',     'vInt32'),       # 1
        FieldSpec('i64',        'vInt64'),       # 2
        FieldSpec('si32',       'vsInt32'),      # 3
        FieldSpec('si32bis',    'vsInt32'),      # 4
        FieldSpec('si64',       'vsInt64'),      # 5
        FieldSpec('vuint32',    'vuInt32'),      # 6
        FieldSpec('vuint64',    'vuInt64'),      # 7
        # take care with gaps from here
        FieldSpec('fint32',     'vuInt32'),      # 8
        FieldSpec('fint64',     'vuInt64'),      # 9
        FieldSpec('lstr',       'lString'),      # 10
        FieldSpec('lbytes',     'lBytes'),       # 11
        FieldSpec('lbytes16',   'fBytes16'),     # 12
        FieldSpec('lbytes20',   'fBytes20'),     # 13
        FieldSpec('lbytes32',   'fBytes32'),     # 14
]
testMsgSpec = MsgSpec(protocol, name, fields)  

# -------------------------------------------------------------------
class TestTFWriter (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################

    # these two methods are all that's left of testTFBuffer.py
    def testBufferCtor(self):
        BUFSIZE = 1024
        buffer  = [0]*BUFSIZE
        tfBuf   = TFBuffer(testMsgSpec, BUFSIZE, buffer)
        self.assertEquals(0,        tfBuf.position)
        self.assertEquals(BUFSIZE,  tfBuf.capacity)

    def testBufferCreator(self):
        BUFSIZE = 1024
        tfBuf   = TFBuffer.create(testMsgSpec, BUFSIZE)
        self.assertTrue( isinstance( tfBuf, TFBuffer ) )
        self.assertEquals(0,        tfBuf.position)
        self.assertEquals(BUFSIZE,  tfBuf.capacity)

    # and these two methods are all that's left of testTFReader.py
    def testReaderCtor(self):
        BUFSIZE = 1024
        buffer  = bytearray(BUFSIZE)
        tfReader   = TFReader(testMsgSpec, BUFSIZE, buffer)
        self.assertEquals(0,       tfReader.position)
        self.assertEquals(BUFSIZE, tfReader.capacity)
        self.assertEquals(BUFSIZE, len(tfReader.buffer))

    def testReaderCreator(self):
        BUFSIZE = 1024
        tfReader   = TFReader.create(testMsgSpec, BUFSIZE)
        self.assertTrue( isinstance( tfReader, TFReader ) )
        self.assertEquals(0,        tfReader.position)
        self.assertEquals(BUFSIZE,  tfReader.capacity)

    # next two are specific to TFWriter
    def testWriterCtor(self):
        BUFSIZE = 1024
        buffer  = bytearray(BUFSIZE)
        tfWriter   = TFWriter(testMsgSpec, BUFSIZE, buffer)
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def testWriterCreator(self):
        BUFSIZE = 1024
        tfWriter   = TFWriter.create(testMsgSpec, BUFSIZE)
        self.assertTrue( isinstance( tfWriter, TFWriter ) )
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def doRoundTripField(self, writer, reader, n, fType, value):
        writer.putNext(n, value)
#       # DEBUG
#       tfBuf   = writer.buffer
#       print "after put buffer is " ,
#       self.dumpBuffer(tfBuf)
#       # END
        reader.getNext()
        self.assertEquals( n,     reader.fieldNbr )
        # XXX THIS SHOULD WORK:
        # self.assertEquals( fType, reader.fType    )
        self.assertEquals( value, reader.value    )
        return n + 1

    def testWritingAndReading(self):
        BUFSIZE = 16*1024
        tfWriter= TFWriter.create(testMsgSpec, BUFSIZE)
        tfBuf   = tfWriter.buffer       # we share the buffer
        tfReader= TFReader(testMsgSpec, BUFSIZE, tfBuf)

        n = 0                           # 0-based field number

        # field types encoded as varints (8) ========================
        # These are tested in greater detail in testVarint.py; the
        # tests here are to exercise their use in a heterogeneous
        # buffer

        # fields 0: _V_INT32
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vInt32', 0x1f)
        self.assertEquals(1, n)         # DEBUG XXX 

        # fields 1: _V_INT32
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vInt32', 0x172f3e4d)
        # field 2:  _V_INT64
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vInt64',
                                                      0x12345678abcdef3e)
        # field 3: vsInt32
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vsInt32', 192)

        # field 4: vsInt32
        # _V_SINT32 (zig-zag encoded, optimal for small values near zero)
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vsInt32', -192)

        # field 5: _V_SINT64
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vsInt64', -193) # GEEP

        # field 6: _V_UINT32
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vuInt32',
                                                      0x172f3e4d)
        # field 7: _V_UINT64
        n = self.doRoundTripField(tfWriter, tfReader, n, 'vuInt64',
                                                      0xffffffff172f3e4d)

        # _V_BOOL
        # XXX NOT IMPLEMENTED, NOT TESTED

        # _V_ENUM
        # XXX NOT IMPLEMENTED, NOT TESTED

        # encoded as fixed length 32 bit fields =====================
        # field 8: _F_INT32
        n = self.doRoundTripField(tfWriter, tfReader, n, 'fInt32',
                                                      0x172f3e4d)
        # _F_FLOAT * MIND THE GAP * ie, if you implement this, fix numbering
        # XXX STUB XXX not implemented

        # encoded as fixed length 64 bit fields =====================
        # field 9: _F_INT64
        n = self.doRoundTripField(tfWriter, tfReader, n, 'fInt64',
                                                      0xffffffff172f3e4d)
        # _F_DOUBLE
        # XXX STUB XXX not implemented

        # encoded as varint len followed by byte[len] ===============
        # field 10: _L_STRING
        s = self.rng.nextFileName(16)
        n = self.doRoundTripField(tfWriter, tfReader, n, 'lString', s)

        # field 11: _L_BYTES
        b = bytearray(8 + self.rng.nextInt16(16))
        self.rng.nextBytes(b)
        n = self.doRoundTripField(tfWriter, tfReader, n, 'lBytes', b)

        # _L_MSG
        # XXX STUB XXX not implemented

        # fixed length byte sequences, byte[N} ======================
        # field 12: _F_BYTES16
        self.rng.nextBytes(b128)
        n = self.doRoundTripField(tfWriter, tfReader, n, 'fBytes16', b128)

        # field 13: _F_BYTES20
        self.rng.nextBytes(b160)
        n = self.doRoundTripField(tfWriter, tfReader, n, 'fBytes20', b160)

        # may want to introduce eg fNodeID20 and fSha1Key types
        # field 14: _F_BYTES32
        self.rng.nextBytes(b256)
        n = self.doRoundTripField(tfWriter, tfReader, n, 'fBytes32', b256)

        # may want to introduce eg fSha3Key type, allowing semantic checks

if __name__ == '__main__':
    unittest.main()

# fieldz/__init__.py

__version__         = '0.3.0'
__version_date__    = '2012-09-03'

__all__ = [ '__version__',      '__version_date__',
]

# fieldz/fieldTypes.py

import sys
#from fieldz.core import singleton, SimpleEnumWithRepr
from fieldz.core import SimpleEnumWithRepr

#@singleton
class FieldTypes(SimpleEnumWithRepr):
    def __init__(self):
        super(FieldTypes,self).__init__( [ \
            # FIELDS IMPLEMENTED USING VARINTS
            ('_V_BOOL',     'vBool'),   ('_V_ENUM',     'vEnum'),
            ('_V_INT32',    'vInt32'),  ('_V_INT64',    'vInt64'),
            ('_V_SINT32',   'vsInt32'), ('_V_SINT64',   'vsInt64'),
            ('_V_UINT32',   'vuInt32'), ('_V_UINT64',   'vuInt64'),
            # IMPLEMENTED USING B32
            ('_F_UINT32',   'fuInt32'), ('_F_SINT32',   'fsInt32'), 
            ('_F_FLOAT',    'fFloat'),
            # IMPLEMENTED USING B64
            ('_F_UINT64',   'fuInt64'), ('_F_SINT64',   'fsInt64'), 
            ('_F_DOUBLE',   'fDouble'),
            # IMPLEMENTED USING LEN_PLUS
            ('_L_STRING',   'lString'), ('_L_BYTES',    'lBytes'),
            ('_L_MSG',      'lMsg'),
            # OTHER FIXED LENGTH BYTE SEQUENCES
            ('_F_BYTES16',  'fBytes16'),('_F_BYTES20',  'fBytes20'),
            ('_F_BYTES32',  'fBytes32'),
        ])

#       self._reprs     = []            # list of string representations
#       self._repr2type = {}            # maps string reprs to ints
#       for i in range(len(self._pairs)):
#           pair = self._pairs[i]
#           sym  = pair[0]              # a string
#           self.__dict__[sym] = i      # the corresponding int value
#           self._reprs.append(pair[1])
#           self._repr2type[pair[1]] = i

#       self._MAX_TYPE  = self._F_BYTES32

#   def repr(self, n):
#       if n is None or n < 0 or self._MAX_TYPE < n:
#           raise ValueError('no such field type: %s' % str(n))
#       return self._reprs[n]

#   def ndx(self, s):
#       """ 
#       Maps a string representation to the unique integer value associated 
#       with the corresponding symbol.
#       """
#       if s is None or not s in self._repr2type:
#           print "DEBUG: invalid fType representation '%s'" % s
#           return None
#       else:
#           return self._repr2type[s]

#   def maxFieldTypeNdx(self):
#       return self.ndx('fBytes32')             # GEEP

sys.modules[__name__] = FieldTypes()

# ~/dev/py/fieldz/reg/__init__.py

import fieldz.fieldTypes as F

__all__ = [ 'Registry', ]

class Registry(object):

    def __init__(self):
        self._qNames     = []   # unique qualified (dotted) name list
        self._qName2hash = {}   # qualified name to content key
        self._hash2regID = {}   # content key to unique ID
        self._putFunc    = []   # methods, write instance field type to buffer
        self._getFunc    = []   # methods, get instance field type from buffer

        pass

    def register(seld):
        pass

    def bootstrap(self):
        # -- add fieldTypes -----------------------------------------

        # -- load core types from specs/org/xlattice/fieldz/core/* 

        # -- add core types to tables -------------------------------
        pass



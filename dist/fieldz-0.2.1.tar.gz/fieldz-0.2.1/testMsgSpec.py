#!/usr/bin/python

# testMsgSpec.py
import StringIO, time, unittest

from rnglib         import SimpleRNG
from fieldz         import *
from fieldz.msgSpec import *
from fieldz.typed   import *


LOG_ENTRY_MSG_SPEC = """protocol org.xlattice.zoggery
message logEntry:
    timestamp   fInt32
    nodeID      fBytes20
    key         fBytes20
    by          lString
    path        lString
"""
class TestMsgSpec (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # actual unit tests #############################################

    def testMaps(self):
        maxNdx  = maxFieldTypeNdx()
        maxName = stdFieldTypeName(maxNdx)
        self.assertEquals('fBytes32', maxName)

    def testEnum(self):
        """ 
        A not very useful enum, limited to mapping a fixed list of
        names into a zero-based sequence of integers.
        """

        # XXX should test null or empty lists, ill-formed names
        names = ['abc', 'def', 'ghi']
        enum  = EnumSpec(names)
        self.assertEquals( ','.join(names), enum._repr())
        self.assertEquals( 'abc', enum.name(0))
        self.assertEquals( 'def', enum.name(1))
        self.assertEquals( 'ghi', enum.name(2))

    def doFieldTest(self, name, fType, quantifier='', default=None):
        # XXX Defaults are ignore for now.
        f = FieldSpec(name, fType, quantifier, default)

        self.assertEquals(name,         f.name)
        self.assertEquals(fType,        f.fTypeName)
        self.assertEquals(quantifier,   f.quantifier)
        if default is not None:
            self.assertEquals(default,  f.default)

    def testsQuantifiers(self):
        self.assertEquals('',  qName(Q_REQUIRED))
        self.assertEquals('?', qName(Q_OPTIONAL))
        self.assertEquals('*', qName(Q_STAR))
        self.assertEquals('+', qName(Q_PLUS))

    def testFieldSpec(self):
        self.doFieldTest( 'foo',    'vInt32'                ) 
        # default is not implemented yet
       #self.doFieldTest( 'bar',    'vsInt32', '*',    -3   )    
        self.doFieldTest( 'bar',    'vsInt32',  '*'         )    
        self.doFieldTest( 'nodeID', 'fBytes20', '?'         )
        self.doFieldTest( 'tix',    'vBool',    '+'         )

    def testMsgSpec(self):
        """ this is in fact the current spec for a log entry """
        protocol= 'org.xlattice.fieldz.upax'
        name    = 'logEntry'
        # the enum is not used 
        enum    = EnumSpec(['oh', 'hello', 'there',])
        fields  = [ \
                FieldSpec('timestamp', 'fInt32'),
                FieldSpec('nodeID',    'fBytes20'),
                FieldSpec('key',       'fBytes20'),
                FieldSpec('by',        'lString'),
                FieldSpec('path',      'lString'),
        ]
        msgSpec = MsgSpec(protocol, name, fields, enum)

        self.assertEquals(name, msgSpec.name)

        # not likely to be useful just yet but ...
        self.assertEquals(name,     msgSpec.fName(0))
        # XXX How do we get the name of the message type?
        self.assertEquals('lMsg',   msgSpec.fTypeName(0))

        self.assertEquals(6, msgSpec.size)  # including 'field 0'

        # field numbers can be seen as 1-based
        for i in range(1,msgSpec.size):
            self.assertEquals(fields[i - 1].name,       msgSpec.fName(i))
            self.assertEquals(fields[i - 1].fTypeName,  msgSpec.fTypeName(i))

    def testParseAndWriteMsgSpec(self):
        data = StringIO.StringIO(LOG_ENTRY_MSG_SPEC)
        p    = StringMsgSpecParser(data)   # data should be file-like
        sOM  = p.parse()             # object model from string serialization
        self.assertIsNotNone(sOM)
        self.assertTrue(isinstance(sOM, MsgSpec))

        # XXX we aren't using the protocol line
        self.assertEquals( 'logEntry', sOM.name )

        # expect six fields, first of which carries message name
        # XXX WORKING HERE
        self.assertEquals(sOM.fName(0),     'logEntry')
        self.assertEquals(sOM.fTypeName(0), 'lMsg')

        # MAJOR INCONSISTENCY HERE: we should be using INTs for types,
        # not strings XXX
        self.assertEquals(sOM.fName(1),     'timestamp')   
        self.assertEquals(sOM.fTypeName(1), 'fInt32')
        self.assertEquals(sOM.fName(2),     'nodeID')
        self.assertEquals(sOM.fTypeName(2), 'fBytes20')
        self.assertEquals(sOM.fName(3),     'key')
        self.assertEquals(sOM.fTypeName(3), 'fBytes20')
        self.assertEquals(sOM.fName(4),     'by')
        self.assertEquals(sOM.fTypeName(4), 'lString')
        self.assertEquals(sOM.fName(5),     'path')
        self.assertEquals(sOM.fTypeName(5), 'lString')

#               FieldSpec('timestamp', FieldTypes._F_INT32),
#               FieldSpec('nodeID',    FieldTypes._F_BYTES20),
#               FieldSpec('key',       FieldTypes._F_BYTES20),
#               FieldSpec('by',        FieldTypes._L_STRING),
#               FieldSpec('path',      FieldTypes._L_STRING),


if __name__ == '__main__':
    unittest.main()

#!/usr/bin/python

# testTFWriter.py
import time, unittest

from rnglib         import SimpleRNG
from fieldz.typed   import *
from fieldz.msgSpec import *

# scratch variables
b128 = bytearray(16)
b160 = bytearray(20)
b256 = bytearray(32)

# msgSpec -----------------------------------------------------------
protocol= 'org.xlattice.upax'
name    = 'testMsgSpec'
# no enum is used
fields  = [ \
        # all varint types except enum and boolean
        FieldSpec('i32',        'vInt32'),       # field 1
        FieldSpec('i32bis',     'vInt32'),       # 2
        FieldSpec('i64',        'vInt64'),       # 3
        FieldSpec('si32',       'vsInt32'),      # 4
        FieldSpec('si32bis',    'vsInt32'),      # 5
        FieldSpec('si64',       'vsInt64'),      # 6
        FieldSpec('vuint32',    'vuInt32'),      # 7
        FieldSpec('vuint64',    'vuInt64'),      # 8
        # take care with gaps from here
        FieldSpec('fint32',     'vuInt32'),      # 9
        FieldSpec('fint64',     'vuInt64'),      # 10
        FieldSpec('lstr',       'lString'),      # 11
        FieldSpec('lbytes',     'lBytes'),       # 12
        FieldSpec('lbytes16',   'fBytes16'),     # 13
        FieldSpec('lbytes20',   'fBytes20'),     # 14
        FieldSpec('lbytes32',   'fBytes32'),     # 15
]
testMsgSpec = MsgSpec(protocol, name, fields)  

# -------------------------------------------------------------------
class TestTFWriter (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################

    # these two methods are all that's left of testTFBuffer.py
    def testBufferCtor(self):
        BUFSIZE = 1024
        buffer  = [0]*BUFSIZE
        tfBuf   = TFBuffer(buffer, testMsgSpec)
        self.assertEquals(0,        tfBuf.position)
        self.assertEquals(BUFSIZE,  tfBuf.capacity)
        self.assertEquals(BUFSIZE,  tfBuf.limit)

    def testBufferCreator(self):
        BUFSIZE = 1024
        tfBuf   = TFBuffer.create(BUFSIZE, testMsgSpec)
        self.assertTrue( isinstance( tfBuf, TFBuffer ) )
        self.assertEquals(0,        tfBuf.position)
        self.assertEquals(BUFSIZE,  tfBuf.capacity)
        self.assertEquals(BUFSIZE,  tfBuf.limit)

    # and these two methods are all that's left of testTFReader.py
    def testReaderCtor(self):
        BUFSIZE = 1024
        buffer  = bytearray(BUFSIZE)
        tfReader   = TFReader(buffer, testMsgSpec)
        self.assertEquals(0,       tfReader.position)
        self.assertEquals(BUFSIZE, tfReader.capacity)
        self.assertEquals(BUFSIZE, len(tfReader.buffer))

    def testReaderCreator(self):
        BUFSIZE = 1024
        tfReader   = TFReader.create(BUFSIZE, testMsgSpec)
        self.assertTrue( isinstance( tfReader, TFReader ) )
        self.assertEquals(0,        tfReader.position)
        self.assertEquals(BUFSIZE,  tfReader.capacity)

    # next two are specific to TFWriter
    def testWriterCtor(self):
        BUFSIZE = 1024
        buffer  = bytearray(BUFSIZE)
        tfWriter   = TFWriter(buffer, testMsgSpec)
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def testWriterCreator(self):
        BUFSIZE = 1024
        tfWriter   = TFWriter.create(BUFSIZE, testMsgSpec)
        self.assertTrue( isinstance( tfWriter, TFWriter ) )
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def doRoundTripField(self, writer, reader, n, fType, value):
        writer.putNext(n, value)
#       # DEBUG
#       tfBuf   = writer.buffer
#       print "after put buffer is " ,
#       self.dumpBuffer(tfBuf)
#       # END
        reader.getNext()
        self.assertEquals( n,     reader.fieldNbr )
        # XXX THIS SHOULD WORK:
        # self.assertEquals( fType, reader.fType    )
        self.assertEquals( value, reader.value    )
        return n + 1

    def testWritingAndReading(self):
        BUFSIZE = 16*1024
        tfWriter= TFWriter.create(BUFSIZE, testMsgSpec)
        tfBuf   = tfWriter.buffer       # we share the buffer
        tfReader= TFReader(tfBuf, testMsgSpec)

        F = FieldTypes()                # yes, this is stupid
        n = 1                           # 1-based field number

        # field types encoded as varints (8) ========================
        # These are tested in greater detail in testVarint.py; the
        # tests here are to exercise their use in a heterogeneous
        # buffer

        # fields 1: _V_INT32
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 0x1f)
        self.assertEquals(2, n)         # DEBUG

        # fields 2: _V_INT32
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 0x172f3e4d)
        # field 3:  _V_INT64
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt64,
                                                      0x12345678abcdef3e)
        # field 4: vsInt32
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vsInt32, 192)

        # field 5: vsInt32
        # _V_SINT32 (zig-zag encoded, optimal for small values near zero)
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vsInt32, -192)

        # field 6: _V_SINT64
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vsInt64, -193) # GEEP

        # field 7: _V_UINT32
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vuInt32,
                                                      0x172f3e4d)
        # field 8: _V_UINT64
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vuInt64,
                                                      0xffffffff172f3e4d)

        # _V_BOOL
        # XXX NOT IMPLEMENTED, NOT TESTED

        # _V_ENUM
        # XXX NOT IMPLEMENTED, NOT TESTED

        # encoded as fixed length 32 bit fields =====================
        # field 9: _F_INT32
        n = self.doRoundTripField(tfWriter, tfReader, n, F.fInt32,
                                                      0x172f3e4d)
        # _F_FLOAT * MIND THE GAP * ie, if you implement this, fix numbering
        # XXX STUB XXX not implemented

        # encoded as fixed length 64 bit fields =====================
        # field 10: _F_INT64
        n = self.doRoundTripField(tfWriter, tfReader, n, F.fInt64,
                                                      0xffffffff172f3e4d)
        # _F_DOUBLE
        # XXX STUB XXX not implemented

        # encoded as varint len followed by byte[len] ===============
        # field 11: _L_STRING
        s = self.rng.nextFileName(16)
        n = self.doRoundTripField(tfWriter, tfReader, n, F.lString, s)

        # field 12: _L_BYTES
        b = bytearray(8 + self.rng.nextInt16(16))
        self.rng.nextBytes(b)
        n = self.doRoundTripField(tfWriter, tfReader, n, F.lBytes, b)

        # _L_MSG
        # XXX STUB XXX not implemented

        # fixed length byte sequences, byte[N} ======================
        # field 13: _F_BYTES16
        self.rng.nextBytes(b128)
        n = self.doRoundTripField(tfWriter, tfReader, n, F.fBytes16, b128)

        # field 14: _F_BYTES20
        self.rng.nextBytes(b160)
        n = self.doRoundTripField(tfWriter, tfReader, n, F.fBytes20, b160)

        # may want to introduce eg fNodeID20 and fSha1Key types
        # field 15: _F_BYTES32
        self.rng.nextBytes(b256)
        n = self.doRoundTripField(tfWriter, tfReader, n, F.fBytes32, b256)

        # may want to introduce eg fSha3Key type, allowing semantic checks

if __name__ == '__main__':
    unittest.main()

# fieldz

Implementation nodes:

<table>
    <tr><td>api</td>       <td>https://jddixon.github.io/api.html</td></tr>
    <tr><td>channels</td>  <td>https://jddixon.github.io/channels.html</td></tr>
    <tr><td>goals</td>     <td>https://jddixon.github.io/goals.html</td></tr>
</table>

## On-line Documentation

More information on the **fieldz** project can be found
[here](https://jddixon.github.io/fieldz)

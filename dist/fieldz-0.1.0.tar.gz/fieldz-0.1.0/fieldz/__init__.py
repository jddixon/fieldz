# fieldz/__init__.py

__version__         = '0.1.0'
__version_date__    = '2012-08-15'

__all__ = [ '__version__', '__version_date__',
            'B32_TYPE', 'B64_TYPE', 'LEN_PLUS_TYPE', 'VARINT_TYPE',
            'lengthAsVarint',
            'readFieldHdr', 'readRawVarint',
            'writeVarintField',
]

# assume that each field is preceded by a varint whose value is field number
# ORed with its type

VARINT_TYPE     = 0 # variable length integer
B32_TYPE        = 1 # fixed length, 32 bits
B64_TYPE        = 2 # fixed length, 64 bits
LEN_PLUS_TYPE   = 3 # sequence of bytes preceded by a varint length

def fieldHdr(n, t):
    # it would be prudent but slower to validate the parameters
    return (n << 3) | t

def hdrFieldNbr(h):
    return h >> 3

def hdrType(h):
    return h & 7

def lengthAsVarint(v):
    if   v < (1<<7):    return 1
    elif v < (1<<14):   return 2
    elif v < (1<<21):   return 3 
    elif v < (1<<28):   return 4
    elif v < (1<<35):   return 5
    elif v < (1<<42):   return 6
    elif v < (1<<49):   return 7
    elif v < (1<<56):   return 8
    elif v < (1<<63):   return 9
    else:               return 10

def writeRawVarint(buf, offset, v):
#   # DEBUG
#   print "entering writeRaw: will write 0x%x at offset %u" % ( v, offset)
#   # END
    l = lengthAsVarint(v)
    if offset + l > len(buf):
        raise ValueError("can't fit varint of length %u into buffer" % l)
    while True:
        buf[offset] = (v & 0x7f) 
        offset += 1
        v >>= 7
        if v == 0:
            # return offset of next unused byte
            return offset   # next unused byte
        else:
            buf[offset-1] |= 0x80

def writeVarintField(buf, offset, v, f):
    # the header is the field number << 3 ORed with 0, VARINT_TYPEa
    # XXX for now, assume f << 3 always fits in one byte
    hdr = f << 3
    offset = writeRawVarint(buf, offset, hdr)
#   # DEBUG
#   print "header was 0x%x; writing value 0x%x at offset %u" % ( 
#                                                   hdr, v, offset)
#   # END
    return writeRawVarint(buf, offset, v)



def readRawVarint(buf, offset):
    v = 0
    x = 0
    while True:
        if offset >= len(buf):
            raise ValueError("attempt to read beyond end of buffer")
        nextByte = buf[offset]
#       # DEBUG
#       print "readRaw: nextByte = 0x%x" % nextByte
#       # END
        offset  += 1

        sign     = nextByte & 0x80
        nextByte = nextByte & 0x7f
        nextByte <<= (x * 7)
        v |= nextByte
        x += 1

#       # DEBUG
#       print "  after shifting nextByte is 0x%x" % nextByte
#       print "    and v is 0x%x" % v
#       # END
        if sign == 0:
            break
    return (v, offset)

def readFieldHdr(buf, offset):
    (hdr, offset) = readRawVarint(buf, offset)
    fieldType     = hdrType(hdr)
    fieldNbr      = hdrFieldNbr(hdr) 
    return (fieldType, fieldNbr, offset)

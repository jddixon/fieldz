# fieldz/__init__.py

__version__      = '0.10.1'
__version_date__ = '2016-02-19'


__all__ = [ '__version__',      '__version_date__', 
            'chan',     'coreTypes',    'enum',     'fieldTypes',
            'msgImpl',  'msgSpec',      'parser',   'raw',
            'tfbuffer', 'typed',
          ]




#!/usr/bin/python

# testZoggerySerialization.py
import time, unittest
from io     import StringIO

from rnglib import SimpleRNG

from fieldz.parser import StringProtoSpecParser
import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T
from fieldz.chan    import Channel
from fieldz.msgImpl import makeMsgClass, makeFieldClass
# XXX NEEDS FIXING: we shouldn't be using this low-level code
from fieldz.raw     import writeFieldHdr, writeRawVarint, LEN_PLUS_TYPE

# PROTOCOLS ---------------------------------------------------------
from zoggeryProtoSpec       import ZOGGERY_PROTO_SPEC

BUFSIZE = 16*1024
rng     = SimpleRNG( time.time() )

# TESTS -------------------------------------------------------------
class TestZoggerySerialization (unittest.TestCase):

    def setUp(self):
        data = StringIO(ZOGGERY_PROTO_SPEC)
        p    = StringProtoSpecParser(data)   # data should be file-like
        self.sOM        = p.parse()     # object model from string serialization
        self.protoName  = self.sOM.name # the dotted name of the protocol

    def tearDown(self):
        pass

    # utility functions #############################################
    def leMsgValues(self):
        """ returns a list """
        timestamp   = int(time.time())
        key         = [0]*20
        nodeID      = [0]*20
        by          = 'who is responsible'
        path        = '/home/jdd/tarballs/something.tar.gz'
        # let's have some random bytes
        rng.nextBytes(key)
        rng.nextBytes(nodeID)
        # NOTE that this is a list
        return [timestamp, key, nodeID, by, path]

    # actual unit tests #############################################

    def testZoggerySerialization(self):
        # XXX These comments are generally out of date.

        # Testing MsgSpec with simple fields.  Verify that getter,
        # putter, lenFunc, and pLenFunc work for the basic types
        # (ie, that they are correctly imported into this reg) and
        # they are work for the newly defined single-msg protoSpec.

        # Use ZOGGERY_PROTO_SPEC 

        # parse the protoSpec
        # verify that this adds 1 (msg) + 5 (field count) to the number
        # of entries in getters, putters, etc
        
        self.assertIsNotNone(self.sOM)
        self.assertTrue(isinstance(self.sOM, M.ProtoSpec))
        self.assertEquals( 'org.xlattice.zoggery', self.sOM.name )

        self.assertEquals(0, len(self.sOM.enums) )
        self.assertEquals(1, len(self.sOM.msgs) )
        self.assertEquals(0, len(self.sOM.seqs) )

        msgSpec = self.sOM.msgs[0]
        
        # Create a channel ------------------------------------------
        # its buffer will be used for both serializing # the instance 
        # data and, by deserializing it, for creating a second instance.
        chan = Channel(BUFSIZE)
        buf  = chan.buffer
        self.assertEquals( BUFSIZE, len(buf) )

        # create the LogEntryMsg class ------------------------------
        LogEntryMsg     = makeMsgClass(self.protoName, msgSpec)

        # create a message instance ---------------------------------
        values  = self.leMsgValues()        # a list quasi-random values
        leMsg   = LogEntryMsg( values )
        
        self.assertEquals(msgSpec.name, leMsg.name)
        # we don't have any nested enums or messages
        self.assertEquals(0, len(leMsg.enums))
        self.assertEquals(0, len(leMsg.msgs))

        self.assertEquals(5, len(leMsg.fieldClasses))
        self.assertEquals(5, len(leMsg))        # number of fields in instance
        for i in range(len(leMsg)):
            self.assertEquals(values[i], leMsg[i].value)

        # serialize the object to the channel -----------------------
        regID           = 18 + rng.nextInt16(40)  # XXX AS YET UNUSED
        # XXX A HACK TO MAKE THIS TEST SUCCEED:
        expectedMsgLen  = leMsg._wireLen()
        print "EXPECTED LENGTH OF SERIALIZED OBJECT: %u" % expectedMsgLen
        buf             = chan.buffer

        chan.clear()                 # offset
        # -----------------------------------------------------------
        # XXX should be a single call to leMsg.putFieldHdr ???
        # -----------------------------------------------------------
        writeFieldHdr ( chan, regID, LEN_PLUS_TYPE )
        writeRawVarint( chan, expectedMsgLen )
        lenHeader = chan.position

        leMsg.putter(chan)
        oldPosition = chan.position                     # TESTING flip()
        chan.flip()
        self.assertEquals(oldPosition, chan.limit)      # TESTING flip()
        self.assertEquals(0,           chan.position)   # TESTING flip() 
        actual = chan.limit

        print "ACTUAL LENGTH OF SERIALIZED OBJECT: %u" % actual
        self.assertEquals( lenHeader + expectedMsgLen, actual)

        # EXPECT THAT a simple message is serialized to the channel with its
        # regID as replacing the fieldNbr in the first varint.  So in 
        # this case we expect the value of the first varints to be
        #   (regID << 3) | LEN_PLUS
        #   msgLen
        # followed by that many bytes.  In this case there are 5 fields,
        # so we expect the data that follows to look like
        #   (0 << 3) | F_UINT32
        #   timestamp
        #   (1 << 3) | F_BYTES20
        #   nodeID
        #   (2 << 3) | F_BYTES20
        #   key
        #   (3 << 3) | L_STRING
        #   by
        #   (4 << 3) | L_STRING
        #   path
        # 
        # The message length will then be about 49 + len(key) + len(path)
        
        # XXX WORKING HERE: CONFIRM THAT THE DATA IN THE CHANNEL MATCHES 
        # OUR EXPECTATIONS


        # deserialize the channel, making a clone of the message ----
#       readBack = LogEntryMsg.getter(chan) 
#       self.assertIsNotNone(readBack)

#       # verify that the messages are identical --------------------
#       self.assertTrue(leMsg.__eq__(readBack))

#       # produce another message from the same values --------------
#       leMsg2  = LogEntryMsg( values )
#       chan2   = Channel(BUFSIZE)
#       leMsg2.putter(chan2)
#       copy2   = LogEntryMsg.getter(chan2)
#       self.assertTrue(leMsg.__eq__(copy2))
#       self.assertTrue(leMsg2.__eq__(copy2))       # GEEP
        

if __name__ == '__main__':
    unittest.main()

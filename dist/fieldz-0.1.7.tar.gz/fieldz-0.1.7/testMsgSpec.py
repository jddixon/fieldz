#!/usr/bin/python

# testMsgSpec.py
import time, unittest

from rnglib         import SimpleRNG
from fieldz.msgSpec import *
from fieldz.typed   import *


class TestMsgSpec (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # actual unit tests #############################################

    def testEnum(self):
        """ 
        A not very useful enum, limited to mapping a fixed list of
        names into a zero-based sequence of integers.
        """

        # XXX should test null or empty lists, ill-formed names
        names = ['abc', 'def', 'ghi']
        enum  = EnumSpec(names)
        self.assertEquals( ','.join(names), enum._repr())
        self.assertEquals( 'abc', enum.name(0))
        self.assertEquals( 'def', enum.name(1))
        self.assertEquals( 'ghi', enum.name(2))

    def doFieldTest(self, name, fType, quantifier='', default=None):
        # XXX Defaults are ignore for now.
        f = FieldSpec(name, fType, quantifier, default)

        self.assertEquals(name,         f.name)
        self.assertEquals(fType,        f.fType)
        self.assertEquals(quantifier,   qName(f.quantifier))
        if default is not None:
            self.assertEquals(default,  f.default)

    def testsQuantifiers(self):
        self.assertEquals('',  qName(Q_REQUIRED))
        self.assertEquals('?', qName(Q_OPTIONAL))
        self.assertEquals('*', qName(Q_STAR))
        self.assertEquals('+', qName(Q_PLUS))

    def testFieldSpec(self):
        self.doFieldTest( 'foo',    'vInt32'              ) 
        self.doFieldTest( 'bar',    'vsInt32', '*',    -3 )    
        self.doFieldTest( 'nodeID', 'fBytes20','?'        )
        self.doFieldTest( 'tix',    'vBool',   '+'        )

    def testMsgSpec(self):
        """ this is in fact the current spec for a log entry """
        name    = 'logEntry'
        # the enum is not used 
        enum    = EnumSpec(['oh', 'hello', 'there',])
        fields  = [ \
                FieldSpec('timestamp', FieldTypes._F_INT32),
                FieldSpec('nodeID',    FieldTypes._F_BYTES20),
                FieldSpec('key',       FieldTypes._F_BYTES20),
                FieldSpec('by',        FieldTypes._L_STRING),
                FieldSpec('path',      FieldTypes._L_STRING),
        ]
        msgSpec = MsgSpec(name, fields, enum)

        self.assertEquals(name, msgSpec.name)

        # not likely to be useful just yet but ...
        self.assertEquals(name, msgSpec.fName(0))
        self.assertEquals(FieldTypes._L_MSG, msgSpec.fType(0))

        # field numbers are 1-based
        for i in range(1,5):
            self.assertEquals(fields[i - 1].name, msgSpec.fName(i))
            self.assertEquals(fields[i - 1].fType, msgSpec.fType(i))

if __name__ == '__main__':
    unittest.main()

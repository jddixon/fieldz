#!/usr/bin/python

# testLogEntry.py
import time, unittest

from rnglib       import SimpleRNG
from fieldz.typed import *

# -- logEntry msgSpec ---------------------------
name    = 'logEntry'
enum    = ['not', 'being', 'used',]
fields  = [ \
        ('timestamp', FieldTypes._F_INT32),
        ('nodeID',    FieldTypes._F_BYTES20),
        ('key',       FieldTypes._F_BYTES20),
        ('by',        FieldTypes._L_STRING),
        ('path',      FieldTypes._L_STRING),
]
leMsgSpec = MsgSpec(name, fields, enum)
# -- end logEntry msgSpec -----------------------

class TestLogEntry (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################
    def testWritingAndReading(self):
        BUFSIZE = 16*1024
        writer  = TFWriter.create(BUFSIZE, leMsgSpec)
        buf     = writer.buffer
        reader  = TFReader(buf, leMsgSpec) # reader and writer share same buffer
    
        t       = int(time.time())
        nodeID  = bytearray(20)         # 160 bit 
        self.rng.nextBytes(nodeID)           #        .... random value
        key     = bytearray(20)         # 160 bit 
        self.rng.nextBytes(key)              #        .... random value
        by      = self.rng.nextFileName(16)      
        path    = 'path/to/' + self.rng.nextFileName(16) 

        F = FieldTypes()                # yes, this is stupid
        n = 1                           # 1-based field number

        # write a log entry into the buffer
        writer.putNext(n, F.fInt32, t);             n = n + 1
        writer.putNext(n, F.fBytes20, nodeID);      n = n + 1
        writer.putNext(n, F.fBytes20, key);         n = n + 1
        writer.putNext(n, F.lString,  by);          n = n + 1
        writer.putNext(n, F.lString, path)

        # now read the buffer to see what actually was written
        self.assertEquals(0,            reader.position)

        reader.getNext()
        self.assertEquals(1,            reader.fieldNbr)
        self.assertEquals(F.fInt32,     reader.fType) 
        self.assertEquals(t,            reader.value)   # GETS 108??
        self.assertEquals(5,            reader.position)

        reader.getNext()
        self.assertEquals(2,            reader.fieldNbr)    # GETS 6
        self.assertEquals(F.fBytes20,   reader.fType)       # GETS 5 not 16
        self.assertEquals(nodeID,       reader.value)       # GETS 53
        self.assertEquals(26,           reader.position)

        reader.getNext()
        self.assertEquals(3,            reader.fieldNbr)    
        self.assertEquals(F.fBytes20,   reader.fType)       
        self.assertEquals(key,          reader.value)       
        self.assertEquals(47,           reader.position)

        reader.getNext()
        self.assertEquals(4,            reader.fieldNbr)    
        self.assertEquals(F.lString,    reader.fType)       
        self.assertEquals(by,           reader.value)       

        reader.getNext()
        self.assertEquals(5,            reader.fieldNbr)    
        self.assertEquals(F.lString,    reader.fType)       
        self.assertEquals(path,         reader.value)       

if __name__ == '__main__':
    unittest.main()

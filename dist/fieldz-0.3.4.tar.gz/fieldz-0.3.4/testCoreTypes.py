#!/usr/bin/python

# testCoreTypes.py
import time, unittest

from rnglib import SimpleRNG
from fieldz.raw    import * 
from fieldz.typed  import * 
import fieldz.msgSpec   as M
import fieldz.coreTypes as C

class TestCoreTypes (unittest.TestCase):

    def setUp(self):
#       self.rng = SimpleRNG( time.time() )
        pass
    def tearDown(self):
        pass

    # utility functions #############################################


    # actual unit tests #############################################
    def testTheEnum(self):
        self.assertEquals(5, C.maxNdx)
        self.assertEquals(0, C._ENUM_PAIR_SPEC)
        self.assertEquals(5, C._PROTO_SPEC)

    def doRoundTripEnumPairSpec(self, wb, n, cType, val):
        buf     = wb.buffer
        putter  = M.cPutFuncs[cType] 
        getter  = M.cGetFuncs[cType] 
        lenFunc = M.cLenFuncs[cType] 

        expectedHdr = fieldHdr(n, LEN_PLUS_TYPE)
        expectedLen = lenFunc(val, n)
        expectedPos = lengthAsVarint(expectedHdr) + \
                      lengthAsVarint(expectedLen) + expectedLen

        wPos    = 0 # write
        rPos    = 0 # read

        wPos = putter(buf, wPos, val, 0) # writing field 0
        self.assertEquals(expectedPos, wPos)

        (pType, n, rPos) = readFieldHdr(buf, rPos)
        hdrLen           = rPos
        self.assertEquals( LEN_PLUS_TYPE,   pType )
        self.assertEquals( 0,               n     )    # field number
        self.assertEquals( 1,               hdrLen)

        (retVal, rPos)  = getter(buf, rPos)
        self.assertEquals( val, retVal)

        

    def testRoundTrippingCoreTypes(self):
        BUFSIZE = 16*1024
        wb      = WireBuffer(BUFSIZE)

        n = 0                           # 0-based field number
        p = M.EnumPairSpec('funnyFarm', 497)
        self.doRoundTripEnumPairSpec( wb, n, C._ENUM_PAIR_SPEC, p)


if __name__ == '__main__':
    unittest.main()

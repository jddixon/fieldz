#!/usr/bin/python

# testFieldTypes.py
import time, unittest

from rnglib     import SimpleRNG
import fieldz.fieldTypes    as F
import fieldz.raw           as R
import fieldz.typed         as T

class TestFieldTypes (unittest.TestCase):
    """ 
    Actually tests the method used for instantiating and importing
    an instance of the FieldTypes class.
    """

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################

    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print


    # actual unit tests #############################################
    def testConstants(self):
        self.assertEquals( 0, F._V_BOOL    ) 
        self.assertEquals(17, F._F_BYTES32 )
        try:
            F._V_BOOL = 47
        except RuntimeError as e:
            print 'caught attempt to reassign constant'
            pass

    def testLenFuncs(self):
        # == varint types ===========================================
        self.assertEquals(1, T.vBoolLen(True) )
        self.assertEquals(1, T.vBoolLen(False))

        n = self.rng.nextInt16()
        x = R.lengthAsVarint(n)
        self.assertEquals( x, T.vEnumLen(n) )
        # XXX FAILS:
        # self.assertEquals( x, T.vEnumLen(-n) )

        n = self.rng.nextInt32()
        self.assertTrue( n >= 0 )
        x = R.lengthAsVarint(n)
        self.assertEquals( x, T.vuInt32Len(n) )

        n = self.rng.nextInt32()
        self.assertTrue( n >= 0 )
        n = n - 0x80000000
        p = T.encodeSint32(n)
        x = R.lengthAsVarint(p)
        self.assertEquals( x, T.vsInt32Len(n) )     # GEEP

        n = self.rng.nextInt64()
        self.assertTrue( n >= 0 )
        x = R.fieldHdrLen(n, F._V_UINT64) + R.lengthAsVarint(n)
        self.assertEquals( x, T.vuInt64Len(n) )

        n = self.rng.nextInt64()
        self.assertTrue( n >= 0 )
        n = n - 0x8000000000000000
        p = T.encodeSint64(n)
        x = R.fieldHdrLen(n, F._V_SINT64) + R.lengthAsVarint(p)
        self.assertEquals( x, T.vsInt64Len(n) )     # GEEP

        # == fixed length 4 byte ====================================
        n = self.rng.nextInt64()
        self.assertTrue( n >= 0 )
        n = n - 0x8000000000000000
        
        # n is a signed 64 bit value whose value should be irrelevant
        self.assertEquals( 4, T.fuInt32Len(n) )
        self.assertEquals( 4, T.fsInt32Len(n) )
        self.assertEquals( 4, T.fFloatLen(n) )
        
        # == fixed length 8 byte ====================================
        # n is that signed 64 bit value whose value should be irrelevant
        self.assertEquals( 8, T.fuInt64Len(n) )
        self.assertEquals( 8, T.fsInt64Len(n) )
        self.assertEquals( 8, T.fDoubleLen(n) )
        
        # == LEN PLUS types =========================================
        def doLenPlusTest(n):
            s = [0]*n
            expectedLen = R.lengthAsVarint(n) + n
            self.assertEquals( expectedLen, T.lBytesLen(s) )

        # -- lString ---------------------------------------
        s = self.rng.nextFileName(256)
        n = len(s)
        expectedLen = R.lengthAsVarint(n) + n
        self.assertEquals(expectedLen, T.lStringLen(s))

        # -- lBytes ----------------------------------------
        doLenPlusTest(0x7f)
        doLenPlusTest(0x80)
        doLenPlusTest(0x3fff)
        doLenPlusTest(0x4000)

        # -- lMsg ------------------------------------------
        # XXX STUB

        # -- fixed length byte arrays -------------------------------
        buf = [0]*512       # length functions should ignore actual size
        self.assertEquals( 16, T.fBytes16Len(buf) )
        self.assertEquals( 20, T.fBytes20Len(buf) )
        self.assertEquals( 32, T.fBytes32Len(buf) )
        
if __name__ == '__main__':
    unittest.main()

# fieldz/fieldz/parser.py

import fieldz.fieldTypes as F
import fieldz.reg       as R

from fieldz.msgSpec import *

__all__ = [ \
        'StringSpecParser',
        'StringMsgSpecParser',
        ]

MAX_INDENT = 16

class StringSpecParser(object):

    def __init__(self, fd):
        # XXX should die if fd not open
        self._fd            = fd
        self._protocol      = None

        # XXX ONLY SUITABLE FOR A MsgSpec 
        self._name          = None
        self._enums         = []
        self._fields        = []
        self._enumReg       = None

        self._nextFieldNbr  = 0

    def getLine(self):
        while True:
            line = self._fd.readline()

            # The first condition never fails if fd is a file-like object
            # (from StringIO)
            if line is None or line == '':
                return None

            # strip off any comments
            s   = line.partition('#')[0]

            # get rid of any trailing blanks
            line = s.rstrip()
            if line != '':
                return line

    def expectTokenCount(self, tokens, kind, n):
        if len(tokens) != n:
            raise RuntimeError("too many tokens in %s line '%s'" % (
                                                            kind,tokens))

    def expectProtocol(self):
        line  = self.getLine()
        words = line.split()
        self.expectTokenCount(words, 'protocol', 2)
        if words[0] == 'protocol':
            validateDottedName(words[1])
            self._protocol = words[1]
            # print "DEBUG: protocol is '%s'" % str(self._protocol)
        else:
            raise RuntimeError("expected protocol line, found '%s'" % line)

    def expectMsgSpecName(self):
        line  = self.getLine()
        words = line.split()
        self.expectTokenCount(words, 'protocol', 2)
        if words[0] == 'message':
            self._name = words[1]
            if self._name[-1] == ':':
                self._name = self._name[:-1]
            validateSimpleName(self._name)
            # print "DEBUG: msgSpec name is '%s'" % str(self._name)
        else:
            raise RuntimeError("expected message line, found '%s'" % line)

    def acceptEnumPair(self, indent, line):
        if not line.startswith(indent):
            return None
        # we are not strict about the indent
        line = line.strip()
        # syntax is simply A = N
        parts = line.partition('=')
        if (parts[1] is None):
            raise RuntimeError("expected = in enum pair: '%s'" % line)
        sym = parts[0].strip()
        val = parts[2].strip()
        return EnumPairSpec(sym, val)

    def expectEnum(self, indent, line):
        # we know the line begins with INDENT + 'enum'.  This 
        # should be followed by the enum's name, and then a sequence
        # of pairs at a deeper indent
        from_ = len(indent) + len('enum')
        s    = line[from_:]
        # s should begin with one or more spaces, followed by one 
        # simple name
        if s[0] != ' ':
            raise RuntimeError("can't find enum name in '%s'" % line)
        name = s.strip()
        validateSimpleName(name)
        pairs       = []
        pairIndent  = indent + '    '
        line        = self.getLine()          # we require at least one pair
        pair        = self.acceptEnumPair(pairIndent, line)
        if pair is None:
            raise RuntimeError("expected enum pair, found '%s'" % line)
        pairs.append(pair)

        # we have one pair, let's see if there are any more
        line        = self.getLine()
        pair        = self.acceptEnumPair(pairIndent, line)
        while pair is not None:
            pairs.append(pair)
            line        = self.getLine()
            pair        = self.acceptEnumPair(pairIndent, line)
        eSpec = EnumSpec(name, pairs)
        if self._enumReg is None:
            self._enumReg = R.MsgReg(eSpec)
        else:
            self._enumReg.append(eSpec)
        return (line, eSpec)

    def acceptEnums(self, indent):
        """ 
        Accept and return any enums at the specified indent.  Return
        the first line at the wrong indent or not matching the enum 
        syntax.
        """
        line        = self.getLine()
        enumStart   = indent + 'enum'
        
        while line.startswith(enumStart):
            (line, enum) = self.expectEnum(indent, line) 
            self._enums.append(enum)
        return line

    def expectField(self, line):
        # for now, ignore any indentation
        line  = line.lstrip()

        # accept NAME FTYPE(Q)? (@N)? (=DEFAULT)?

        words = line.split()
        wordCount = len(words)

        if wordCount < 2:
            raise RuntimeError("too few tokens in field def '%s'" % line)
        if wordCount > 4:
            raise RuntimeError("too many tokens in field def '%s'" % line)

        # -- field name -------------------------
        fName   = words[0]
        validateSimpleName(fName)

        # -- quantifier -------------------------
        q = words[1][-1]
        if q == '?' or q == '*' or q == '+':
            words[1]    = words[1][:-1]
            if   q == '?':  quantifier = Q_OPTIONAL
            elif q == '*':  quantifier = Q_STAR
            else         :  quantifier = Q_PLUS
        else:
            quantifier  = Q_REQUIRED

        # -- field type --------------------------
        typeName = words[1]
        validateDottedName(typeName)
        if self._enumReg is not None and typeName in self._enumReg._byName :
            # THIS IS A KNOWN ERROR.  We should set fType to regID
            fType = F._V_ENUM
        elif F.ndx(typeName) is not None:
            fType = F.ndx(typeName)
        else:
            raise RuntimeError("can't identify type name in '%s'" % line)

        # -- field number -----------------------
        fieldNbr = self._nextFieldNbr
        if wordCount >2:
            if words[2].startswith('@'):
                fieldNbr = int(words[2][1:])    # could use some validation
                if fieldNbr < self._nextFieldNbr:
                    raise ValueError('field number <= last field number')
        self._nextFieldNbr = fieldNbr + 1

        # -- default ----------------------------
        # XXX STUB - NOT IMPLEMENTED YET

        return FieldSpec(fName, fType, quantifier, fieldNbr)

    def expectFields(self, indent, line):
        # they get appended to self._fields; there must be at least one
        if line is None or line == '':
            raise RuntimeError('no fields found')
        self._fields.append( self.expectField(line) )

        line = self.getLine()
        while line is not None and line != '':
            self._fields.append( self.expectField(line) )
            line = self.getLine()

    # OVERRIDE THIS to change fuctionality --------------------------
    def parse(self):
        self.expectProtocol()
        self.expectMsgSpecName()
        line = self.acceptEnums('    ')
        self.expectFields('    ', line)
        return MsgSpec(self._protocol, self._name, self._fields, self._enums)


class StringMsgSpecParser(StringSpecParser):
    """
    Reads a human-readable MsgSpec (a *.msgSpec file) to produce a
    MsgSpec object model, which is a MsgSpec with FieldSpecs and EnumSpecs
    dangling off of it.
    """
    def __init__(self, fd):
        super(StringMsgSpecParser, self).__init__(fd)

class StringProtoSpecParser(StringSpecParser):
    """
    Reads a human-readable MsgSpec (a *.msgSpec file) to produce a
    MsgSpec object model, which is a MsgSpec with FieldSpecs and EnumSpecs
    dangling off of it.
    """
    def __init__(self, fd):
        super(StringProtoSpecParser, self).__init__(fd)

    def parseEnumSpec(self, parent):
        pass

    def parseMsgSpec(self, parent):
        pass

    def parse(self):
        self.expectProtocol()       # just the name on a line by itself

        # accept zero or more EnumSpec declarations at zero indentation

        # XXX STUB XXX

        # expect one or more MsgSpec declaration at zero indentation; these 
        # may include EnumSpec declations at +4 indentation and nested MsgSpec 
        # at +4 indentation, which may be further nested to an arbitrary 
        # depth (where arbitrary means a total indentation of MAX_INDENT)

        # XXX STUB XXX

        # -----------------------------------------------------------
        # XXX WHAT FOLLOWS IS NOT RIGHT; we need to hack in the Reg code
        # -----------------------------------------------------------
        self.expectMsgSpecName()
        line = self.acceptEnums('    ')
        self.expectFields('    ', line)
        return MsgSpec(self._protocol, self._name, self._fields, self._enums)


# == OLDER CODE, MAY BE OBSOLETE ====================================
# POSSIBLY SUPERCLASS IS TFReader
class WireMsgSpecParser(object):
    """
    Reads a MsgSpec fully serialized to wire form (and so a sequence of
    fieldz) produce a MsgSpec object model, which is a MsgSpec with
    FieldSpecs and EnumSpecs dangling off of it.
    """
    def __init__(self, w):
        pass

# POSSIBLY SUPERCLASS IS TFBuffer OR TFWriter
class WireMsgSpecWriter(object):
    """
    Given a MsgSpec (including attached FieldSpecs and optional EnumSpecs)
    produces a serialization using FieldTypes.
    """

    def __init__(self, mSpec, wb):
        if mSpec is None:
            raise ValueError('no MsgSpec identified')
        self._m = mSpec

        if wb is None:
            raise ValueError('no WireBuffer specified')
        self._wb = wb

    def write(self):

        # THIS SHOULD JUST USE TFWriter, OR ITS BITS AND PIECES.
        # To use TFWriter in its current form, we need a wired-in class
        # definition, say MsgSpecClz.
        # Alternatively, put the putNext methods into a dispatch table
        # and invoke them through that table.

        # protocol
        # name
        # enum
        # fields

        pass
# END OF PARSER

# ~/dev/py/fieldz/reg/__init__.py

from fieldz.msgSpec import validateSimpleName, validateDottedName
import fieldz.typed         as T
import fieldz.fieldTypes    as F
import fieldz.coreTypes     as C
import fieldz.msgSpec       as M

__all__ = [ \
            # these can be considered obsolete
            'Registry', 
            'RegEntry', 
            'FieldTypeEntry', 
            'CoreTypeEntry', 
            'EnumSpecEntry',
            'MsgSpecEntry',
            'ProtoSpecEntry',

            # new stuff; there will be some merging with existing types
            'NodeReg',  'ProtoEntry', 
            'ProtoReg'  'MsgEntry',
            'MsgReg',   'EnumEntry',
        ]

# XXX At least three different types of regEntries, so we need a 
# RegEntry superclass, and then a subclass for the wired-in fieldTypes,
# a second for core types (MsgSpec, FieldSpec, etc), and then additional
# regEntry types for dynamically defined EnumSpec, MsgSpec,  and 
# ProtoSpec 

class RegEntry(object):
    __slots__ = [ '_id', '_qualName', '_putter', '_getter', 
                                      '_lenFunc', '_pLenFunc',]

    def __init__(self, reg, qualName, putter, getter, 
                                      lenFunc=None, pLenFunc=None):
        # XXX CURRENTLY NOT USED
        if reg is None:         raise ValueError('reg may not be None')
        # END NOT USED

        if qualName is None:    raise ValueError('qualName may not be None')
        if putter is None:      raise ValueError('putter may not be None')
        if getter is None:      raise ValueError('getter may not be None')
        # lenFunc and pLenFunc may be None

        validateDottedName(qualName)
        # XXX if the name is dotted the protocol must be defined.
        self._qualName      = qualName

        # XXX these must be methods with the right signature :-)
        self._putter        = putter
        self._getter        = getter
        self._lenFunc       = lenFunc
        self._pLenFunc      = pLenFunc

        # XXX THIS IS A BAD IDEA.  If the entry cannot be created, we don't
        # want to have allocated an ID.  So create the entry and then 
        # register it, allocating an ID at registration time
        self._id = reg.nextRegID             # MOVE ME XXX

    @property
    def regID(self):        return self._id
    @property
    def qualName(self):     return self._qualName
    @property
    def putter(self):       return self._putter
    @property
    def getter(self):       return self._getter
    @property
    def lenFunc(self):      return self._lenFunc
    @property
    def pLenFunc(self):     return self._pLenFunc

class FieldTypeEntry(RegEntry):
    def __init__(self, reg, qualName, putter, getter):
        super(FieldTypeEntry, self).__init__(reg, qualName, putter, getter)
    @property
    def rCanonical(self):   return None


class CoreTypeEntry(RegEntry):
    __slots__ = [ '_rCanonical',  ]
    def __init__(self, reg, qualName, putter, getter, lenFunc, pLenFunc):
        super(CoreTypeEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)

        # XXX STUB

    @property
    def rCanonical(self):   return None

class EnumSpecEntry(RegEntry):
    __slots__ = [ '_rCanonical',  ]
    def __init__(self, reg, qualName, rCanonical, putter, getter, lenFunc, pLenFunc):
        super(EnumSpecEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)
        if rCanonical is None:  raise ValueError('rCanonical may not be None')
        self._rCanonical    = rCanonical

        # XXX STUB

    @property
    def rCanonical(self):   return self._rCanonical

class MsgSpecEntry(RegEntry):
    __slots__ = [ '_rCanonical',  ]
    def __init__(self, reg, qualName, rCanonical, putter, getter, lenFunc, pLenFunc):
        super(EnumSpecEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)
        if rCanonical is None:  raise ValueError('rCanonical may not be None')
        self._rCanonical    = rCanonical

        # XXX STUB

    @property
    def rCanonical(self):   return self._rCanonical

class ProtoSpecEntry(RegEntry):
    __slots__ = [ '_rCanonical',  ]
    def __init__(self, reg, qualName, rCanonical, putter, getter, lenFunc, pLenFunc):
        super(EnumSpecEntry, self).__init__(reg, qualName, putter, getter, lenFunc, pLenFunc)
        if rCanonical is None:  raise ValueError('rCanonical may not be None')
        self._rCanonical    = rCanonical

        # XXX STUB

    @property
    def rCanonical(self):   return self._rCanonical

class Registry(object):

    def __init__(self):
        self._entries    = []

        self._qualNames  = []   # unique qualified (dotted) name list
        self._qName2regID = {}   # qualified name to content key
        # content key is hash of canonical string version of object
        self._qName2hash = {}   # qualified name to content key
        self._hash2regID = {}   # content key to unique ID

        # currying could help here
        self._putter     = []   # methods, write instance field type to buffer
        self._getter     = []   # methods, get instance field type from buffer
        self._lenFunc    = []
        self._pLenFunc   = []

        self._nextRegID  = 0
        self.bootstrap()

    def __len__(self):
        return len(self._entries)

    def register(self, qName, rCanonical, putter, getter, lenFunc, pLenFunc):
        """ 
        Add a type to the registry's internal tables.  The canonical
        string serialization of the type is used to calculate a content
        key (160 bit SHA1 or 256 bit SHA3) for the type.  The caller
        must provide a putter, a method for serializing an instance of
        the type into a bytearray, and a getter, a method for deserializing
        an instance from a bytearray.
        """
        
        # XXX STUB - add some validation
        
        entry = _DefinedRegEntry( qName, rCanonical, putter, getter, lenFunc, pLenFunc )
        self._register(entry)       # _uses_ the next free regID
        return entry._regID

    # XXX NOT IMMUTABLE
    def __getitem__(self, i):
        return self._entries[i]

    def _register(self, entry):
        # creation of the entry has used the next free regID
        self._nextRegID += 1            # so we step it
        self._entries.append(entry)
        name = entry.qualName

        # we maintain a list of type names
        self._qualNames.append( name )
        self._qName2regID[name] = entry.regID

#       # DEBUG
#       print "%-20s => regiID %d" % (name, entry.regID)
#       # END

        # we map names to the rCanonical hash  (which may be null)
        self._qName2hash[name] = entry.rCanonical

        # and we main a reverse map
        if entry.rCanonical is not None:
            self._hash2regID[entry.rCanonical] = entry.regID

    def bootstrap(self):
        """ populate registry tables with standard values """
        # -- add fieldTypes -----------------------------------------
        for i in range(F.maxNdx + 1):
            entry = FieldTypeEntry(
                        self,               # reg 
                        F.asStr(i),         # qualName, 
                        T.tPutFuncs[i],     # putter, 
                        T.tGetFuncs[i])     # getter, 
            self._register(entry)

        # self._nextRegID = F.maxNdx    # redundant and wrong anyway
        for i in range(C.maxNdx + 1):
            entry = CoreTypeEntry(
                        self,               # reg 
                        C.asStr(i),         # qualName, 
                        M.cPutFuncs[i],     # putter, 
                        M.cGetFuncs[i],     # getter, 
                        M.cLenFuncs[i],     # getter, 
                        M.cPLenFuncs[i])    # getter, 
            self._register(entry)


    @property
    def nextRegID(self):
        return self._nextRegID

    def qualName2RegID(self, name):
        return self._qName2regID[name]

# BEGIN NEW CLASSES =================================================

class NodeReg(object):
    """ maintains the list of protocols known to the node """
    def __init__(self):
        self._protocols = []    # list of ProtoEntries

class ProtoEntry(object):
    def __init__(self, parent, protoSpec):
        self._parent    = parent
        self._protoSpec = protoSpec
        self._reg       = ProtoReg(self) 

class ProtoReg(object):
    def __init__(self, parent):
        self._parent    = parent
        self._enums     = []
        self._msgs      = []

class MsgEntry(object):
    def __init__(self, parent, msgSpec):
        self._parent    = parent
        self._msgSpec   = msgSpec
        self._reg       = MsgReg(self) 
        pass

class MsgReg(object):

    # XXX PARAMTER MUST BE parent XXX
    def __init__(self, primum):
        self._enums     = []
        self._msgs      = []    # nested messages allowed as well 
        self._byName    = {}
        self.append(primum)

    # XXX 'in' uses a linear search based on __getitem__ rather than
    # the byName index.
#   def __getitem__(self, k):
#       if k < 0:
#           raise ValueError('index is out of range: %s' % str(k))
#       if k >= len(self._enums):
#           # Python uses this to detect the end of the range
#           raise IndexError()
#       return self._enums[k]

    def __len_(self):
        return len(self._enums) 

    # XXX what's added can be either a MsgSpec or an EnumSpec
    def append(self, enum):
        if enum is None:
            raise ValueError('cannot add null enum')
        name = enum.name
        if name in self._byName:
            raise KeyError("we already have an enum '%s'" % name)

        entry = EnumEntry( enum, len(self._enums) )
        self._byName[name] = entry
        self._enums.append(entry)
        # DEBUG
        print "added '%s' to enumReg" % name
        # END

#   def ndx(self, name):
#       if name in self._byName:
#           return self._byName[name].ndx
#       else:
#           return None

class EnumEntry(object):
    __slots__ = ['_enum', '_ndx', ]

    def __init__(self, enum, ndx):
        self._enum = enum               # an EnumSpec
        self._ndx  = ndx

    @property
    def enum(self):     return _enum
    @property
    def ndx(self):      return _ndx


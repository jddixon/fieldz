# fieldz/__init__.py

__version__         = '0.1.3'
__version_date__    = '2012-08-17'

__all__ = [ '__version__', '__version_date__',
]

## MACHINE ###########################################################
#
##class ReadMachine(object):
##    def __init__ (self, buffer, offset=0):
##        if buffer is None:
##            raise ValueError('no input buffer')
##        if offset < 0 or len(buffer) HERE ***
##
##
##

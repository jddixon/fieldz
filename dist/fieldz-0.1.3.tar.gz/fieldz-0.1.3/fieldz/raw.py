# fieldz/raw.py

__all__ = [ 'B32_TYPE', 'B64_TYPE', 'LEN_PLUS_TYPE', 'VARINT_TYPE',
            'fieldHdr',         'readFieldHdr',
            'lengthAsVarint',   'readRawVarint', 'writeVarintField',
            'readRawB32',       'writeB32Field',
            'readRawB64',       'writeB64Field',
            'readRawLenPlus',   'writeLenPlusField',
]

# assume that each field is preceded by a varint whose value is field number
# ORed with its type

VARINT_TYPE     = 0 # variable length integer
B32_TYPE        = 1 # fixed length, 32 bits
B64_TYPE        = 2 # fixed length, 64 bits
LEN_PLUS_TYPE   = 3 # sequence of bytes preceded by a varint length

# FIELD HEADERS #####################################################
def fieldHdr(n, t):
    # it would be prudent but slower to validate the parameters
    return (n << 3) | t

def hdrFieldNbr(h):
    return h >> 3

def hdrType(h):
    return h & 7

def readFieldHdr(buf, offset):
    (hdr, offset) = readRawVarint(buf, offset)
    fieldType     = hdrType(hdr)
    fieldNbr      = hdrFieldNbr(hdr)
    return (fieldType, fieldNbr, offset)

# VARINTS ###########################################################
def lengthAsVarint(v):
    """ return the number of bytes occupied by an unsigned int """
    if   v < (1<<7):    return 1
    elif v < (1<<14):   return 2
    elif v < (1<<21):   return 3
    elif v < (1<<28):   return 4
    elif v < (1<<35):   return 5
    elif v < (1<<42):   return 6
    elif v < (1<<49):   return 7
    elif v < (1<<56):   return 8
    elif v < (1<<63):   return 9
    else:               return 10

def readRawVarint(buf, offset):
    v = 0
    x = 0
    while True:
        if offset >= len(buf):
            raise ValueError("attempt to read beyond end of buffer")
        nextByte = buf[offset]
#       # DEBUG
#       print "readRaw: nextByte = 0x%x" % nextByte
#       # END
        offset  += 1

        sign     = nextByte & 0x80
        nextByte = nextByte & 0x7f
        nextByte <<= (x * 7)
        v |= nextByte
        x += 1

#       # DEBUG
#       print "  after shifting nextByte is 0x%x" % nextByte
#       print "    and v is 0x%x" % v
#       # END
        if sign == 0:
            break
    return (v, offset)

def writeRawVarint(buf, offset, v):
#   # DEBUG
#   print "entering writeRaw: will write 0x%x at offset %u" % ( v, offset)
#   # END
    l = lengthAsVarint(v)
    if offset + l > len(buf):
        raise ValueError("can't fit varint of length %u into buffer" % l)
    while True:
        buf[offset] = (v & 0x7f)
        offset += 1
        v >>= 7
        if v == 0:
            # return offset of next unused byte
            return offset   # next unused byte
        else:
            buf[offset-1] |= 0x80

def writeVarintField(buf, offset, v, f):
    # the header is the field number << 3 ORed with 0, VARINT_TYPEa
    hdr = f << 3
    offset = writeRawVarint(buf, offset, hdr)
#   # DEBUG
#   print "header was 0x%x; writing value 0x%x at offset %u" % (
#                                                   hdr, v, offset)
#   # END
    return writeRawVarint(buf, offset, v)

# 32- AND 64-BIT FIXED LENGTH FIELDS ################################

def readRawB32 (buf, offset):
    """ buf construed as array of unsigned bytes """
    # XXX verify buffer long enough
    v = buf[offset];        offset += 1         # little-endian
    v |= buf[offset] <<  8; offset += 1
    v |= buf[offset] << 16; offset += 1
    v |= buf[offset] << 24; offset += 1
    return (v, offset)

def writeRawB32(buf, offset, v):
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;                 offset += 1
    return offset

def writeB32Field(buf, offset, v, f):
    hdr    = fieldHdr(f, B32_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
    return writeRawB32(buf, offset, v)                  # GEEP

def readRawB64 (buf, offset):
    """ buf construed as array of unsigned bytes """
    # XXX verify buffer long enough
    v = buf[offset];        offset += 1         # little-endian
    v |= buf[offset] <<  8; offset += 1
    v |= buf[offset] << 16; offset += 1
    v |= buf[offset] << 24; offset += 1
    v |= buf[offset] << 32; offset += 1
    v |= buf[offset] << 40; offset += 1
    v |= buf[offset] << 48; offset += 1
    v |= buf[offset] << 56; offset += 1
    return (v, offset)

def writeRawB64(buf, offset, v):
    # XXX verify buffer long enough
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;     v >>= 8;    offset += 1
    buf[offset] = 0xff & v;                 offset += 1
    return offset

def writeB64Field(buf, offset, v, f):
    hdr    = fieldHdr(f, B64_TYPE)
    offset = writeRawVarint(buf, offset, hdr)
    return writeRawB64(buf, offset, v)

# VARIABLE LENGTH FIELDS ############################################

def readRawLenPlus(buf, offset):

    # read the varint len
    (n, offset) = readRawVarint(buf, offset)

    # then read n actual bytes
    s = []
    count = 0
    while count < n:
        s.append(buf[offset])
        count += 1
        offset += 1
    return (bytearray(s), offset)

def writeRawBytes(buf, offset, bytes):
    """ bytes a byte array """
    # XXX CHECK LEN OFFSET
    for b in bytes:
        buf[offset] = b;
        offset += 1
    return offset

def writeLenPlusField(buf, offset, s, f):
    # write the field header --------------------
    hdr    = fieldHdr(f, LEN_PLUS_TYPE)
    offset = writeRawVarint(buf, offset, hdr)

    # write the length of the byte array --------
    offset = writeRawVarint(buf, offset, len(s))

    # now write the byte array itself -----------
    return writeRawBytes(buf, offset, s)

# MACHINE ###########################################################

#class ReadMachine(object):
#    def __init__ (self, buffer, offset=0):
#        if buffer is None:
#            raise ValueError('no input buffer')
#        if offset < 0 or len(buffer) HERE ***
#
#
#

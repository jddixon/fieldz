# fieldz/__init__.py

__version__         = '0.8.0'
__version_date__    = '2012-12-18'


__all__ = [ '__version__',      '__version_date__',
]

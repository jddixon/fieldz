#!/usr/bin/python

# testTFReader.py
import time, unittest

from rnglib       import SimpleRNG
from fieldz.raw   import *
from fieldz.typed import *

class TestTFReader (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for b in buf:
            print "0x%02x " % b,
        print

    # actual unit tests #############################################

    def testVarintWithNegativeValues(self):
        # negative numbers, that is
        pass

    def testZZ32(self):
        pass 

    def testZZ64(self):
        pass


if __name__ == '__main__':
    unittest.main()

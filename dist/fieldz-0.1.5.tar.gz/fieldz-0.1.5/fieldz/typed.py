# fieldz/typed.py

from fieldz.raw import *

# __all__ = [ 'FieldTypes', 'TFBuffer', 
#             'encodeSint32', 'decodeSint32',
#             'encodeSint64', 'decodeSint64',
#       ]

# THESE ARE KNOWN NOT TO WORK
def encodeSint32(v):
    # DEBUG
    print "unencoded sint32:       0x%x" % v
    # END
    v = 0xffffffff & v
    # DEBUG
    print "after truncation:       0x%x" % v
    # END
    v = (v << 1) ^ ( v >> 31) 
    # DEBUG
    print "after zig-zag encoding: 0x%x" % v
    # END GEEP
    return v

def decodeSint32(v):
    # decode zig-zag:  stackoverflow 2210923
    # DEBUG
    print "before zig-zag decoding: 0x%x" % v
    # END GEEP

    #v = 0xffffffff & ((v >> 1) ^ (-(v & 1))) 
    v = int ((v >> 1) ^ (-(v & 1))) 
    # DEBUG
    print "after zig-zag decoding: 0x%x (%d)" % (v, v)
    # END GEEP
    return v

def encodeSint64(v):
    v = 0xffffffffffffffff & v
    v = (v << 1) ^ ( v >> 63)
    return v
def decodeSint64(v):
    v = 0xffffffffffffffff & ((v >> 1) ^ (-(v & 1))) 
    return v

class FieldTypes(object):
    """ higher-level field types """
 
    # FIELDS IMPLEMENTED USING VARINTS --------------------
    _V_BOOL    = 0
    _V_ENUM    = 1
    _V_INT32   = 2     # usually/mostly positive values
    _V_INT64   = 3     # ditto
    _V_SINT32  = 4     # expect some negative values, zig-zag encoded
    _V_SINT64  = 5     # ditto
    _V_UINT32  = 6     # unsigned
    _V_UINT64  = 7     # unsigned
    
    # IMPLEMENTED USING B32 -------------------------------
    _F_INT32   = 8     # always 4 bytes
    _F_FLOAT   = 9
    
    # IMPLEMENTED USING B64 -------------------------------
    _F_INT64   = 10     # always 8 bytes
    _F_DOUBLE  = 11
    
    # IMPLEMENTED USING LEN_PLUS --------------------------
    _L_STRING  = 12    # unicode or 7-bit ASCII
    _L_BYTES   = 13    # arbitrary byte values
    _L_MSG     = 14    # an embedded message

    # OTHER FIXED LENGTH BYTE SEQUENCES -------------------
    _F_BYTES16 = 15    # fixed length string of 16 bytes
    _F_BYTES20 = 16    # fixed length string of 20 bytes
    _F_BYTES32 = 17    # fixed length string of 32 bytes

    _MAX_TYPE  = _F_BYTES32

    # to create an illusion of immutability
    @property
    def vBool(clz):        return clz._V_BOOL
    @property
    def vEnum(clz):        return clz._V_ENUM
    @property
    def vInt32(clz):       return clz._V_INT32
    @property
    def vInt64(clz):       return clz._V_INT64
    @property
    def vsInt32(clz):      return clz._V_SINT32
    @property
    def vsInt64(clz):      return clz._V_SINT64
    @property
    def vuInt32(clz):      return clz._V_UINT32
    @property
    def vuInt64(clz):      return clz._V_UINT64
    @property
    def fInt32(clz):       return clz._F_INT32
    @property
    def fFloat(clz):       return clz._F_FLOAT
    @property
    def fInt64(clz):       return clz._F_INT64
    @property
    def fDouble(clz):      return clz._F_DOUBLE
    @property
    def lString(clz):      return clz._L_STRING
    @property
    def lBytes(clz):       return clz._L_BYTES
    @property
    def fBytes20(clz):     return clz._F_BYTES20
    @property
    def fBytes32(clz):     return clz._F_BYTES32
   
    # XXX NEED A MAP FROM THESE CONSTANTS TO ENCODE FUNCTIONS, AND THEN A
    # MAP TO DECODE FUNCTIONS
    _names = {}
    _names[_V_BOOL]     = 'vBool'
    _names[_V_ENUM]     = 'vEnum'
    _names[_V_INT32]    = 'vInt32'
    _names[_V_INT64]    = 'vInt64'
    _names[_V_SINT32]   = 'vsInt32'
    _names[_V_SINT64]   = 'vsInt64'
    _names[_V_UINT32]   = 'vuInt32'
    _names[_V_UINT64]   = 'vuInt64'
    _names[_F_INT32]    = 'fInt32'
    _names[_F_FLOAT]    = 'fFloat'  # XXX WARNING: Python doesn't support 
    _names[_F_INT64]    = 'fInt64'
    _names[_F_DOUBLE]   = 'fDouble'
    _names[_L_STRING]   = 'lString'
    _names[_L_BYTES]    = 'lBytes'
    _names[_F_BYTES20]  = 'fBytes20'
    _names[_F_BYTES32]  = 'fBytes32'

    @classmethod
    def name(clz, v):      
        if v is None or v < 0 or FieldTypes._MAX_TYPE < v:
            raise ValueError('no such field type: %s' + str(v))
        return clz._names[v]

class TFBuffer(object):

    __slots__ = ['_buffer', '_position', '_limit', '_capacity', ]

    def __init__(self, buffer):
        self._position = 0
        if buffer is None:
            raise ValueError('base buffer cannot be null')
        self._buffer    = buffer
        self._capacity  = len(buffer)
        self._limit     = self._capacity

    @property
    def buffer(self):   return self._buffer

    @property
    def position(self): return self._position
    @position.setter
    def position(self, offset):
        if offset < 0:
            raise ValueError('position cannot be negative')
        if (offset > self._limit):
            raise ValueError('position cannot be beyond limit')
        self._position = offset

    @property
    def limit(self):    return self._limit
    @limit.setter
    def limit(self, offset):
        if offset < 0:
            raise ValueError('limit cannot be set to a negative')
        if (offset < self._position):
            raise ValueError("limit can't be set to less than current position")
        if (offset > self._capacity):
            raise ValueError('limit cannot be beyond capacity')
        self._limit = offset
    @property
    def capacity(self): return self._capacity

    @classmethod
    def create(cls, n):
        if n <= 0:
            raise ValueError("buffer size must be a positive number")
        buffer = [0]*n
        return cls(buffer)

class TFReader(TFBuffer):
    # needs some thought; the pType is for debug
    __slots__ = ['_fieldNbr', '_fType', '_pType', '_value', ]

    def __init(self, buffer):
        super(TFReader, self).__init__(buffer)
        # this is a decision: we could read the first field
        self._fieldNbr = -1
        self._fType    = -1
        self._pType    = -1
        self._value    = None

    # def create(n) inherited 

    @property 
    def fieldNbr(self):     return self._fieldNbr
    @property 
    def fType(self):        return self._fType
    @property 
    def pType(self):        return self._pType      # for DEBUG
    @property 
    def value(self):        return self._value

    def getNext(self):
        (self._fType, self._fieldNbr, self._position) = \
                            readFieldHdr(self._buffer, self._position)
        # we use the field type to determine which primitive type to read next
       
        # - implemented using varints -------------------------------
        if self._fType <= FieldTypes._V_UINT64:
            self._pType = VARINT_TYPE       # DEBUG
            (self._value, self._position) = readRawVarint(
                                            self._buffer, self._position)
            # DEBUG
            print "getNext: readRawVarint returns value = 0x%x" % self._value
            # END
            if self._fType == FieldTypes._V_SINT32:
                self._value = decodeSint32(self._value)
            elif self._fType == FieldTypes._V_SINT64:
                self._value = decodeSint64(self._value)

        # implemented using B32 -------------------------------------
        # - WORKING HERE

        # implemented using B64 -------------------------------------

        # implemented using LEN_PLUS --------------------------------

        # implemented using B128, B160, B256 ------------------------

        else:
            raise RuntimeError(
                    "decode for type %d has not been implemented" % self._fType)



        
class TFWriter(TFBuffer):
    # needs some thought; MOSTLY FOR DEBUG
    __slots__ = ['_fieldNbr', '_fType', '_pType', '_value', ]

    def __init(self, buffer):
        super(TFWriter, self).__init__(buffer)
        # this is a decision: we could read the first field
        self._fieldNbr = -1
        self._fType    = -1
        self._pType    = -1
        self._value    = None

    # def create(n) inherited 

    # These are for DEBUG
    @property 
    def fieldNbr(self):     return self._fieldNbr
    @property 
    def fType(self):        return self._fType
    @property 
    def pType(self):        return self._pType  
    @property 
    def value(self):        return self._value
    # END DEBUG PROPERTIES

    def putNext(self, fieldNbr, fType, value):
        
        # - implemented using varints -------------------------------
        if fType <= FieldTypes._V_UINT64:
            if fType == FieldTypes._V_BOOL:
                if value is True:       value = 1
                else:                   value = 0
            elif fType == FieldTypes._V_ENUM:
                # just handle enums as simple ints for now, but constrain
                # to 16 bits; any sign is uhm mangled
                value = 0xffff & value

            elif fType == FieldTypes._V_INT32 \
                                or fType == FieldTypes._V_UINT32:
                value = 0xffffffff & value
            elif fType == FieldTypes._V_INT64 \
                                or fType == FieldTypes._V_UINT64:
                value = 0xffffffffffffffff & value

            elif fType == FieldTypes._V_SINT32: 
                value = encodeSint32(value)
            elif fType == FieldTypes._V_SINT64:
                value = encodeSint64(value)
            # DEBUG
            self._fType = fType
            self._pType = VARINT_TYPE
            self._value = value
            # END
        
        else:
            s = FieldTypes.name(fType)
            raise ValueError("unknown/unimplemented fType " + s)

        # WORKING HERE
        # DEBUG
        # print "putNext 
        # END
        self._position = writeVarintField( self._buffer, self._position, 
                                                    value, fieldNbr, fType)

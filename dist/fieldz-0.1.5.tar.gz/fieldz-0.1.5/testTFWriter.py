#!/usr/bin/python

# testTFWriter.py
import time, unittest

from rnglib       import SimpleRNG
from fieldz.typed import *

class TestTFWriter (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    # actual unit tests #############################################

    def testCtor(self):
        BUFSIZE = 1024
        buffer  = [0]*BUFSIZE
        tfWriter   = TFWriter(buffer)
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def testCreator(self):
        BUFSIZE = 1024
        tfWriter   = TFWriter.create(BUFSIZE)
        self.assertTrue( isinstance( tfWriter, TFWriter ) )
        self.assertEquals(0,        tfWriter.position)
        self.assertEquals(BUFSIZE,  tfWriter.capacity)

    def doRoundTripField(self, writer, reader, n, fType, value):
        writer.putNext(n, fType, value)
        # DEBUG
        tfBuf   = writer.buffer
        print "after put buffer is " ,
        self.dumpBuffer(tfBuf)
        # END
        reader.getNext()
        self.assertEquals( n,     reader.fieldNbr ) 
        self.assertEquals( fType, reader.fType    )
        self.assertEquals( value, reader.value    )
        return n + 1

    def testWritingAndReading(self):
        BUFSIZE = 16*1024
        tfWriter= TFWriter.create(BUFSIZE)
        tfBuf   = tfWriter.buffer
        tfReader= TFReader(tfBuf)       # evil :-)
        
        F = FieldTypes()                # yes, stupid
        n = 1                           # 1-based field number

        # field types encoded as varints ----------------------------
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 0x1f)
        self.assertEquals(2, n)         # DEBUG

        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt32, 
                                                      0x172f3e4d)

        n = self.doRoundTripField(tfWriter, tfReader, n, F.vInt64, 
                                                      0x12345678abcdef3e)

        # signed ints with zig-zag encode/decode XXX FAILS
        n = self.doRoundTripField(tfWriter, tfReader, n, F.vsInt32, -192)

if __name__ == '__main__':
    unittest.main()

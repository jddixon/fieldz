#!/usr/bin/python

# testVarint.py
import time, unittest

from rnglib         import SimpleRNG
from fieldz.raw     import *
from fieldz.typed   import *

LEN_NULLS   = 1024
NULLS       = [0] * LEN_NULLS

class TestVarint (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print


    # actual unit tests #############################################
    def testLengthAsVarint(self):
        len = lengthAsVarint
        self.assertEquals( 1, len(                 0))
        self.assertEquals( 1, len(              0x7f))
        self.assertEquals( 2, len(              0x80))
        self.assertEquals( 2, len(            0x3fff))
        self.assertEquals( 3, len(            0x4000))
        self.assertEquals( 3, len(          0x1fffff))
        self.assertEquals( 4, len(          0x200000))
        self.assertEquals( 4, len(         0xfffffff))
        self.assertEquals( 5, len(        0x10000000))
        self.assertEquals( 5, len(       0x7ffffffff))
        self.assertEquals( 6, len(       0x800000000))
        self.assertEquals( 6, len(     0x3ffffffffff))
        self.assertEquals( 7, len(     0x40000000000))
        self.assertEquals( 7, len(   0x1ffffffffffff))
        self.assertEquals( 8, len(   0x2000000000000))
        self.assertEquals( 8, len(  0xffffffffffffff))
        self.assertEquals( 9, len( 0x100000000000000))
        self.assertEquals( 9, len(0x7fffffffffffffff))
        self.assertEquals(10, len(0x8000000000000000))
        # the next test fails if I don't parenthesize the shift term or
        # convert >1 to /2
        bigNumber =               0x80000000000000000 + (self.rng.nextInt64()>1)
        self.assertEquals(10, len(bigNumber))

        # MAKE SURE THIS WORKS WITH SIGNED NUMBERS

    def roundTrip(self, n):
        """ 
        this tests writing and reading a varint as the first and
        only field in a buffer
        """
        buf    = bytearray()
        for null in NULLS:
            buf.append( null )

        # -- write varint -------------------------------------------
        fieldNbr    = 1 + self.rng.nextInt16(1024)  

        # XXX ADDED fieldType
        offset      = writeVarintField(buf, 0,  # offset
                                            n, fieldNbr, FieldTypes._V_INT64)

#       # DEBUG
#       print "buffer after writing varint field: ",
#       self.dumpBuffer(buf)
#       # END

        # -- read varint --------------------------------------------
        # first the header (which is a varint) ------------
        (fieldType, fieldNbr2, offset2) = readFieldHdr(buf, 0)
        self.assertEquals( FieldTypes._V_INT64, fieldType )
        self.assertEquals( fieldNbr,    fieldNbr2 )
        self.assertEquals( lengthAsVarint(fieldNbr << 3),  offset2 )

        # then the varint proper --------------------------
        (v, offset3) = readRawVarint(buf, offset2)
        self.assertEquals(n, v)
        self.assertEquals(offset2 + lengthAsVarint(n), offset3)


    def testEncodeDecode(self):
        """ other than 42, these are the usual border values """ 
        self.roundTrip(                  0 )
        self.roundTrip(                 42 )
        self.roundTrip(               0x7f )
        self.roundTrip(               0x80 )
        self.roundTrip(             0x3fff )
        self.roundTrip(             0x4000 )
        self.roundTrip(           0x1fffff )
        self.roundTrip(           0x200000 )
        self.roundTrip(          0xfffffff )
        self.roundTrip(         0x10000000 )
        self.roundTrip(        0x7ffffffff )
        self.roundTrip(        0x800000000 )
        self.roundTrip(      0x3ffffffffff )
        self.roundTrip(      0x40000000000 )
        self.roundTrip(    0x1ffffffffffff )
        self.roundTrip(    0x2000000000000 )
        self.roundTrip(   0xffffffffffffff )
        self.roundTrip(  0x100000000000000 )
        self.roundTrip( 0x7fffffffffffffff )
        self.roundTrip( 0x8000000000000000 )

        # test simple signed numbers
        self.roundTrip( -12 )

if __name__ == '__main__':
    unittest.main()

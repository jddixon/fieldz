# fieldz/__init__.py

__version__      = '0.10.10'
__version_date__ = '2016-04-25'


__all__ = ['__version__', '__version_date__',
           'chan', 'coreTypes', 'enum',
           'fieldImpl', 'fieldTypes',
           'msgImpl', 'msgSpec', 'parser', 'raw',
           'tfbuffer', 'typed',
           ]


#!/usr/bin/python

# testLenPlus.py
import time, unittest

from rnglib     import SimpleRNG
from fieldz     import *

LEN_NULLS   = 1024
NULLS       = [0] * LEN_NULLS

class TestLenPlus (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################

    # actual unit tests #############################################
    def dumpBuffer (self, buf):
        for i in range(16):
            print "0x%02x " % buf[i],
        print

    def roundTrip(self, s):
        """
        this tests writing and reading a string of bytes as the first and
        only field in a buffer
        """
        buf    = bytearray()
        for null in NULLS:
            buf.append( null )

        # -- write the bytearray ------------------------------------
        fieldNbr    = 1 + self.rng.nextInt16(1024)
        offset      = writeLenPlusField(buf, 0, s, fieldNbr)

#       # DEBUG
#       print "buffer after writing lenPlus field: " + str(buf)
#       # END

        # -- read the value written ---------------------------------
        # first the header (which is a varint) ------------
        (fieldType, fieldNbr2, offset2) = readFieldHdr(buf, 0)
        self.assertEquals(LEN_PLUS_TYPE, fieldType)
        self.assertEquals(fieldNbr, fieldNbr2)
        self.assertEquals(lengthAsVarint(fieldHdr(fieldNbr, LEN_PLUS_TYPE)),
                          offset2)

        # then the actual value written -------------------
        (t, offset3) = readRawLenPlus(buf, offset2)
        self.assertEquals(s, t)
        self.assertEquals(offset2 + lengthAsVarint(len(s)) + len(s), offset3) 

    def testEncodeDecode(self):
        self.roundTrip( '' )
        self.roundTrip( 'x' )
        self.roundTrip( 'should be a random string of bytes' )

if __name__ == '__main__':
    unittest.main()

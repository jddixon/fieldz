# fieldz

## Implementation Notes

*  [api](https://jddixon.github.io/fieldz//api.html)
*  [channels](https://jddixon.github.io/fieldz//channels.html)
*  [goals](https://jddixon.github.io/fieldz//goals.html)


## Project Status

Alpha.  Code and unit tests exist, but some tests fail.

## On-line Documentation

More information on the **fieldz** project can be found
[here](https://jddixon.github.io/fieldz)

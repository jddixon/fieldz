# fieldz/typed.py

import ctypes, sys

import fieldz.fieldTypes    as F
from fieldz.raw             import * 

#from fieldz.msgSpec import * 

__all__ = [\
            # value uncerftain
            'TFBuffer',     'TFReader',     'TFWriter',
            'encodeSint32', 'decodeSint32',
            'encodeSint64', 'decodeSint64',
            'notImpl',
            'tPutFuncs',    'tGetFuncs',    'tLenFuncs',
          ]

def encodeSint32(s):
    x = ctypes.c_int32(0xffffffff & s).value
    # we must have the sign filling in from the left
    v = (x << 1) ^ ( x >> 31) 
#   # DEBUG
#   print "\nencodeSint32: 0x%x --> 0x%x" % (s, v)
#   # END
    return v

def decodeSint32(v):
    # decode zig-zag:  stackoverflow 2210923
    x = (v >> 1) ^ (-(v & 1)) 
    s = ctypes.c_int32(x).value
#   # DEBUG
#   print "decodeSint32: 0x%x --> 0x%x" % (v, s)
#   # END
    return s

def encodeSint64(s):
    v = ctypes.c_int64(0xffffffffffffffff & s).value
    # we must have the sign filling in from the left
    v = (v << 1) ^ ( v >> 63) 
    return v

def decodeSint64(v):
    v = (v >> 1) ^ (-(v & 1)) 
    s = ctypes.c_int64(v).value
    return s

# -- CLASSES --------------------------------------------------------

class TFBuffer(WireBuffer):

    __slots__ = [ \
            # '_buffer', 
            '_msgSpec',]

    def __init__(self, msgSpec, n = 1024, buffer=None):
        super(TFBuffer,self).__init__(n, buffer)
        if msgSpec is None:
            raise ValueError('no msgSpec')
#       if not isinstance (msgSpec, MsgSpec):
#           raise ValueError('object is not a MsgSpec')
        self._msgSpec  = msgSpec

    @classmethod
    def create(cls, msgSpec, n):
        if n <= 0:
            raise ValueError("buffer size must be a positive number")
        buffer = bytearray(n)
        return cls(msgSpec, n, buffer)

class TFReader(TFBuffer):
    # needs some thought; the pType is for debug
    __slots__ = ['_fieldNbr', '_fType', '_pType', '_value',  ]

    def __init(self, msgSpec, n, buffer):
        #super(TFReader, self).__init__(msgSpec, len(buffer), buffer)
        super(TFReader, self).__init__(msgSpec, n, buffer)
        # this is a decision: we could read the first field
        self._fieldNbr = -1
        self._fType    = -1
        self._pType    = -1
        self._value    = None

    # def create(n) inherited 

    @property 
    def fieldNbr(self):     return self._fieldNbr
    @property 
    def fType(self):        return self._fType
    @property 
    def pType(self):        return self._pType      # for DEBUG
    @property 
    def value(self):        return self._value

    def getNext(self):
        (self._pType, self._fieldNbr, self._position) = \
                            readFieldHdr(self._buffer, self._position)

        # getter has range check
        fType = self._fType = self._msgSpec.fTypeNdx(self._fieldNbr)

        # gets through dispatch table -------------------------------
        if 0 <= fType and fType <= F._V_SINT64:
            (self._value, self.position) = tGetFuncs[fType](
                                            self._buffer, self._position)
            return

        # we use the field type to verify that have have read the right 
        # primitive type 
#       # - implemented using varints -------------------------------
#       if self._fType <= F._V_UINT64:
#           if self._pType != VARINT_TYPE:
#               raise RuntimeError("pType is %u but should be %u" % (
#                                       self._pType, VARINT_TYPE))
#           (self._value, self._position) = readRawVarint(
#                                           self._buffer, self._position)
#           # DEBUG
#           print "getNext: readRawVarint returns value = 0x%x" % self._value
#           # END
#           if self._fType == F._V_SINT32:
#               self._value = decodeSint32(self._value)
#               # DEBUG
#               print "    after decode self._value is 0x%x" % self._value
#               # 
#           elif self._fType == F._V_SINT64:
#               self._value = decodeSint64(self._value)

#           #END VARINT_GET
        
        # implemented using B32 -------------------------------------
        if self._fType <= F._F_FLOAT:
            self._pType = B32_TYPE              # DEBUG
            (v, self._position) = readRawB32(self._buffer, self._position)
            if self._fType == F._F_UINT32:
                self._value = ctypes.c_uint32(v).value
            elif self._fType == F._F_SINT32:
                self._value = ctypes.c_int32(v).value
            else:
                raise NotImplementedError('B32 handling for float')

        # implemented using B64 -------------------------------------
        elif self._fType <= F._F_DOUBLE:
            self._pType = B64_TYPE              # DEBUG
            (v, self._position) = readRawB64(self._buffer, self._position)
            if self._fType == F._F_UINT64:
                self._value = ctypes.c_uint64(v).value
            elif self._fType == F._F_SINT64:
                self._value = ctypes.c_int64(v).value
            else:
                raise NotImplementedError('B64 handling for double')

        # implemented using LEN_PLUS --------------------------------
        elif self._fType <= F._L_MSG:
            self._pType = LEN_PLUS_TYPE         # DEBUG
            (v, self._position) = readRawLenPlus(self._buffer, self._position)
            if self._fType == F._L_STRING:
                self._value = str(v)
            elif self._fType == F._L_BYTES:
                self._value = v
            else:
                raise NotImplementedError('LEN_PLUS handled as L_MSG')

        # implemented using B128, B160, B256 ------------------------
        elif self._fType == F._F_BYTES16:
            self._pType = B128_TYPE             # DEBUG
            (self._value, self._position) = readRawB128(
                                                self._buffer, self._position)
        elif self._fType == F._F_BYTES20:
            self._pType = B160_TYPE             # DEBUG
            (self._value, self._position) = readRawB160(
                                                self._buffer, self._position)
        elif self._fType == F._F_BYTES32:
            self._pType = B256_TYPE             # DEBUG
            (self._value, self._position) = readRawB256(
                                                self._buffer, self._position)

        else:
            raise NotImplementedError(
                    "decode for type %d has not been implemented" % self._fType)

        #END GET

        
class TFWriter(TFBuffer):
    # needs some thought; MOSTLY FOR DEBUG
    __slots__ = ['_fieldNbr', '_fType', '_pType', '_value', ]

    def __init(self, msgSpec, n=1024, buffer=None):
        super(TFWriter, self).__init__(msgSpec, n, buffer)
        # this is a decision: we could read the first field
        self._fieldNbr = -1
        self._fType    = -1
        self._pType    = -1
        self._value    = None

    # def create(n) inherited 

    # These are for DEBUG
    @property 
    def fieldNbr(self):     return self._fieldNbr
    @property 
    def fType(self):        return self._fType
    @property 
    def pType(self):        return self._pType  
    @property 
    def value(self):        return self._value
    # END DEBUG PROPERTIES

    def putNext(self, fieldNbr, value):

        # getter has range check
        fType = self._msgSpec.fTypeNdx(fieldNbr)

        # puts through dispatch table -------------------------------
        if 0 <= fType and fType <= F._F_BYTES32:
            # DEBUG
            print "putNext: field type is %d (%s)" % (fType, F.asStr(fType))
            sys.stdout.flush()
            # END
            self.position = tPutFuncs[fType](self._buffer, self._position,
                                                          value, fieldNbr)
            # DEBUG
            if fType < F._L_STRING:
                print "putNext through dispatch table:\n"   \
                      "         field   %u\n"               \
                      "         fType   %u,  %s\n"          \
                      "         value   %d (0x%x)\n"          \
                      "         offset  %u"     % (
                      fieldNbr, fType, F.asStr(fType), 
                                value, value, self._position)
            # END
            return
        else:
            print "unknown/unimplemented field type %s" % str(fType)

        # -- NOW VESTIGIAL ------------------------------------------
        v = None


# DISPATCH TABLES ===================================================

def notImpl(*arg):     raise NotImplementedError

tPutFuncs = [notImpl]*(F.maxNdx + 1)
tGetFuncs = [notImpl]*(F.maxNdx + 1)
tLenFuncs = [notImpl]*(F.maxNdx + 1)

# puts implemented using varInts --------------------------
def vBoolPut(buf, pos, val, n):
    if val is True:     return writeVarintField(buf, pos, 1, n)
    else:               return writeVarintField(buf, pos, 0, n)
tPutFuncs[F._V_BOOL]    = vBoolPut

def vEnumPut(buf, pos, val, n):
    # just handle enums as simple ints for now, but constrain
    # to 16 bits; any sign is uhm mangled
    v = 0xffff & val
    return writeVarintField(buf, pos, v, n)
tPutFuncs[F._V_ENUM]    = vEnumPut

def vuInt32Put(buf, pos, val, n):
    v = 0xffffffff & val
    return writeVarintField(buf, pos, v, n)
tPutFuncs[F._V_UINT32]    = vuInt32Put

def vsInt32Put(buf, pos, val, n):
    v = encodeSint32(val)
    return writeVarintField(buf, pos, v, n)
tPutFuncs[F._V_SINT32]    = vsInt32Put

def vuInt64Put(buf, pos, val, n):
    v = 0xffffffffffffffff & val
    return writeVarintField(buf, pos, v, n)
tPutFuncs[F._V_UINT64]    = vuInt64Put

def vsInt64Put(buf, pos, val, n):
    v = encodeSint64(val)
    return writeVarintField(buf, pos, v, n)  
tPutFuncs[F._V_SINT64]    = vsInt64Put

# -- implemented using B32 --------------------------------
def fuInt32Put(buf, pos, val, n):
    val = ctypes.c_uint32(val).value
    return writeB32Field(buf, pos, val, n)
tPutFuncs[F._F_UINT32] = fuInt32Put

def fsInt32Put(buf, pos, val, n):
    val = ctypes.c_int32(val).value
    return writeB32Field(buf, pos, val, n)
tPutFuncs[F._F_SINT32] = fsInt32Put

def fFloatPut(buf, pos, val, n):
    raise NotImplementedError
tPutFuncs[F._F_FLOAT] = fFloatPut

# -- implemented using B64 --------------------------------
def fuInt64Put(buf, pos, val, n):
    val = ctypes.c_uint64(val).value
    return writeB64Field(buf, pos, val, n)
tPutFuncs[F._F_UINT64] = fuInt64Put

def fsInt64Put(buf, pos, val, n):
    val = ctypes.c_int64(val).value
    return writeB64Field(buf, pos, val, n)
tPutFuncs[F._F_SINT64] = fsInt64Put

def fDoublePut(buf, pos, val, n):
    raise NotImplementedError
tPutFuncs[F._F_DOUBLE] = fDoublePut                        # END B64

def lStringPut (buf, pos, val, n):
    return  writeLenPlusField(buf, pos, val, n)
tPutFuncs[F._L_STRING] = lStringPut

def lBytesPut (buf, pos, val, n):
    return  writeLenPlusField(buf, pos, val, n)
tPutFuncs[F._L_BYTES] = lBytesPut

def lMsgPut (buf, pos, val, n):
    raise NotImplementedError
tPutFuncs[F._L_MSG] = lMsgPut

def fBytes16Put (buf, pos, val, n):
    return  writeB128Field(buf, pos, val, n)
tPutFuncs[F._F_BYTES16] = fBytes16Put

def fBytes20Put (buf, pos, val, n):
    return  writeB160Field(buf, pos, val, n)
tPutFuncs[F._F_BYTES20] = fBytes20Put

def fBytes32Put (buf, pos, val, n):
    return  writeB256Field(buf, pos, val, n)
tPutFuncs[F._F_BYTES32] = fBytes32Put                # END B256

# gets implemented using varInts ------------------------------------
def vEnumGet(buf, pos):
    return         readRawVarint(buf, pos)
tGetFuncs[F._V_ENUM] = vEnumGet

def vBoolGet(buf, pos):
    (v, pos) = readRawVarint(buf, pos)
    if v is True:   return (True,  pos)
    else:           return (False, pos)
tGetFuncs[F._V_BOOL] = vBoolGet

def vuInt32Get(buf, pos):
    return         readRawVarint(buf, pos)
tGetFuncs[F._V_UINT32] = vuInt32Get

def vsInt32Get(buf, pos):
    (v, pos) = readRawVarint(buf, pos)
    return (decodeSint32(v), pos)
tGetFuncs[F._V_SINT32] = vsInt32Get

def vuInt64Get(buf, pos):
    return         readRawVarint(buf, pos)
tGetFuncs[F._V_UINT64] = vuInt64Get

def vsInt64Get(buf, pos):
    (v, pos) = readRawVarint(buf, pos)
    return (decodeSint64(v), pos)
tGetFuncs[F._V_SINT64] = vsInt64Get              # END VAR


# -- length functions -----------------------------------------------
# XXX THESE ARE WRONG BECAUSE THE HEADER LENGTH DEPENDS UPON THE FIELD 
# NUMBER, so the signature must be (val, n).  Will work if field nbr
# < 2^5 = 32
# XXX ===============================================================

def vBoolLen(val, n):
    h = fieldHdrLen(n, F._V_BOOL)
    return h + 1        # header plus one for value
tLenFuncs[F._V_BOOL] = vBoolLen

# XXX This needs some thought
def vEnumLen(val, n):
    h = fieldHdrLen(n, F._V_ENUM)
    # XXX we constrain val to this range of non-negative ints
    return h + lengthAsVarint( val & 0xffff)
tLenFuncs[F._V_ENUM] = vEnumLen

def vuInt32Len(val, n):
    h = fieldHdrLen(n, F._V_UINT32)
    # XXX we constrain val to this range of non-negative ints
    return h + lengthAsVarint(val & 0xffffffff)
tLenFuncs[F._V_UINT32] = vuInt32Len

def vsInt32Len(val, n):
    h = fieldHdrLen(n, F._V_SINT32)
    return h + lengthAsVarint(encodeSint32(val))
tLenFuncs[F._V_SINT32] = vsInt32Len

def vuInt64Len(val, n):
    h = fieldHdrLen(n, F._V_UINT64)
    # XXX we constrain val to this range of non-negative ints
    return h + lengthAsVarint(val & 0xffffffffffffffff)
tLenFuncs[F._V_UINT64] = vuInt64Len

def vsInt64Len(val, n):
    h = fieldHdrLen(n, F._V_SINT64)
    return h + lengthAsVarint(encodeSint64(val))
tLenFuncs[F._V_SINT64] = vsInt64Len

def fuInt32Len(val, n):
    h = fieldHdrLen(n, F._F_UINT32)
    return h + 4
tLenFuncs[F._F_UINT32] = fuInt32Len

def fsInt32Len(val, n):
    h = fieldHdrLen(n, F._F_SINT32)
    return h + 4
tLenFuncs[F._F_SINT32] = fsInt32Len

def fFloatLen(val, n):
    h = fieldHdrLen(n, F._F_FLOAT)
    return h + 4
tLenFuncs[F._F_FLOAT] = fFloatLen

def fuInt64Len(val, n):
    h = fieldHdrLen(n, F._F_UINT64)
    return h + 8
tLenFuncs[F._F_UINT64] = fuInt64Len

def fsInt64Len(val, n):
    h = fieldHdrLen(n, F._F_SINT64)
    return h + 8
tLenFuncs[F._F_SINT64] = fsInt64Len

def fDoubleLen(val, n):
    h = fieldHdrLen(n, F._F_DOUBLE)
    return h + 8
tLenFuncs[F._F_DOUBLE] = fDoubleLen

def lStringLen(val,n):
    h = fieldHdrLen(n, F._L_STRING)
    x = len(val)
    return h + lengthAsVarint(x) + x
tLenFuncs[F._L_STRING] = lStringLen

def lBytesLen(val, n):
    h = fieldHdrLen(n, F._L_BYTES)
    x = len(val)
    return h + lengthAsVarint(x) + x
tLenFuncs[F._L_BYTES] = lBytesLen

def lMsgLen(val, n):
    h = fieldHdrLen(n, F._L_MSG)
    x = val.wireLen 
    return h + lengthAsVarint(x) + x
tLenFuncs[F._L_MSG] = lMsgLen

def fBytes16Len(val, n):
    h = fieldHdrLen(n, F._F_BYTES16)
    return h + 16
tLenFuncs[F._F_BYTES16] = fBytes16Len

def fBytes20Len(val, n):
    h = fieldHdrLen(n, F._F_BYTES20)
    return h + 20
tLenFuncs[F._F_BYTES20] = fBytes20Len

def fBytes32Len(val, n):
    h = fieldHdrLen(n, F._F_BYTES32)
    return h + 32
tLenFuncs[F._F_BYTES32] = fBytes32Len


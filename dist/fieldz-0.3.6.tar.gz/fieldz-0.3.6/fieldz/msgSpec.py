# fieldz/msgSpec.py

import re, sys
from fieldz.raw   import  *
from fieldz.typed import  *
import fieldz.fieldTypes    as F
import fieldz.coreTypes     as C


__all__ = [  \
            # constants, so to speak: quantifiers
            'Q_REQUIRED',   # no quantifier, so one and only one such field
            'Q_OPTIONAL',   # ?: either zero or one instance of the field
            'Q_STAR',       # *: zero or more instances of the field allowed
            'Q_PLUS',       # +: one or more instances of the field

            # methods
            'qName',        'validateSimpleName',   'validateDottedName',

            # class-level
            'cPutFuncs', 'cGetFuncs', 'cLenFuncs',

            'enumPairSpecPutter',   'enumSpecPutter',   'fieldSpecPutter',
            'msgSpecPutter',        'seqSpecPutter',    'protoSpecPutter',

            'enumPairSpecGetter',   'enumSpecGetter',   'fieldSpecGetter',
            'msgSpecGetter',        'seqSpecGetter',    'protoSpecGetter',

            'enumPairSpecLen',      'enumSpecLen',      'fieldSpecLen',
            'msgSpecLen',           'seqSpecLen',       'protoSpecLen',

            # classes
            'EnumRegEntry',         'EnumReg',
            'EnumPairSpec',
            'EnumSpec',             'FieldSpec',            'MsgSpec',
            'ProtoSpec',            'SeqSpec',
            #'StringMsgSpecParser',
            #'WireMsgSpecParser',    'WireMsgSpecWriter',
          ]

Q_REQUIRED  = 0
Q_OPTIONAL  = 1
Q_STAR      = 2
Q_PLUS      = 3

Q_NAMES     = ['', '?', '*', '+',]
def qName(n):
    if n < 0 or n >= len(Q_NAMES):
        raise ValueError('does not map to a valid quantifier: %s' % str(n))
    return Q_NAMES[n]

# base names, forming part of a larger pattern
_VALID_NAME_PAT = "[a-zA-Z_][a-zA-Z_0-9]*"
_VALID_NAME_RE  = re.compile(_VALID_NAME_PAT)

# just base names; match will fail if any further characters follow
_VALID_SIMPLE_NAME_PAT = _VALID_NAME_PAT + '$'
_VALID_SIMPLE_NAME_RE  = re.compile(_VALID_SIMPLE_NAME_PAT)

def validateSimpleName(s):
    m = _VALID_SIMPLE_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid simple name '%s'" % s)

# both protocol names and field names can be qualified
_VALID_DOTTED_NAME_PAT = _VALID_NAME_PAT + '(\.' + _VALID_NAME_PAT + ')*$'
_VALID_DOTTED_NAME_RE  = re.compile(_VALID_DOTTED_NAME_PAT)

def validateDottedName(s):
    m = _VALID_DOTTED_NAME_RE.match(s)
    if m is None:
        raise RuntimeError("invalid (optionally dotted) name '%s'" % s)


# -- CLASSES --------------------------------------------------------
class EnumPairSpec(object):
    __slots__ = ['_symbol', '_value',]
    def __init__(self, symbol, value):
        validateSimpleName(symbol)
        self._symbol    = symbol
        self._value     = int(value)

    @property
    def symbol(self):           return self._symbol
    @property
    def value(self):            return self._value

    def __eq__(self, other):
        if other is None or not isinstance(other, EnumPairSpec):
            print 'XXX None or not EnumPairSpec'
            return False
        if (self._symbol != other._symbol) or (self._value  != other._value):
            print 'XXX symbol or value differs'
            return False
#       print 'XXX pairs match'
#       print "  my    self:  %s" % self
#       print "  other other: %s" % other
        return True

    def __str__(self):
        """ return a usable representation of the EnumPairSpec """
        return '%s = %d' % (self._symbol, self._value)

    def __repr__(self):
        """ return the EnumPairSpec in today's notion of the canonical form """
        return '%s=%d' % (self._symbol, self._value)

class EnumSpec(object):
    """
    For our purposes an enum is a named list of simple names (names
    containing no delimiters)` and a map from such names to their
    non-negative integer values.
    """
    __slots__ = ['_name', '_pairs', '_sym2pair', '_size', ]
    def __init__(self, name, pairs):
        """pairs are EnumPairSpecs """
        validateDottedName(name)
        self._name = name
        if pairs is None:
            raise ValueError('null list of enum pairs')
        if len(pairs) == 0:
            raise ValueError('empty list of enum pairs')
        self._pairs     = []
        self._sym2pair  = {}
        for pair in pairs:
            sym = pair.symbol
            val = pair.value
            if sym in self._sym2pair:
                raise ValueError("already in EnumSpec: '%s'" % sym)
            self._pairs.append(pair)
            self._sym2pair[sym] = pair
        self._size = len(self._pairs)  # which should be the same as i

    @classmethod
    def create (cls, name, pairs):
        """pairs are 2-tuples, (symbol, value), where value is uInt16 """
        validateDottedName(name)
        if pairs is None:
            raise ValueError('null list of enum pairs')
        if len(pairs) == 0:
            raise ValueError('empty list of enum pairs')

        _pairs = []
        for pair in pairs:
            sym = pair[0]
            val = pair[1]
            p   = EnumPairSpec(sym, val)
            _pairs.append(p)
        return EnumSpec(name, _pairs)

    def value(self, s):
        """ map a name to the corresponding value """
        return self._sym2pair[s].value

    @property
    def name(self):     return self._name

    # def pair(self, k):
    def __getitem__(self, k):
        return self._pairs[k]

    # XXX Deprecated.  Use len() instead.
    # XXX DOES NOT FOLLOW PYTHON CONVENTION
    @property
    def size(self):     return self._size
    # END DEPRECATED
    
    def __len__(self):     return self._size

    def __eq__(self, other):
        if other is None or not isinstance(other, EnumSpec):
            return False
        if other is self:
            return True
        if other._name != self._name:
            return False
        if len(self._pairs) != len(other._pairs):
            return False

        # XXX should use for loop
        for i in range(self._size):
            #if self[i] != other[i]:
            if self[i].symbol != other[i].symbol or \
                    self[i].value != other[i].value:
#               print "ENUM_PAIR_SPECS DIFFER:"
#               print "  my    pair %u: %s" % (i, self[i])
#               print "  other pair %u: %s" % (i, other[i])
                return False
        return True

    def __str__(self):
        """ return a usable representation of the EnumSpec """
        s = []
        s.append('%s ' % self._name)
        for pair in self._pairs:
            s.append('%s ' % pair)
        return '' . join(s)
    def __repr__(self):
        """ return the EnumSpec in today's notion of the canonical form """
        # XXX THIS IS WRONG XXX
        # return ',' . join(self._pairs)                      # GEEP
        return self.__str__()

class EnumRegEntry(object):
    __slots__ = ['_enum', '_ndx', ]

    def __init__(self, enum, ndx):
        self._enum = enum
        self._ndx  = ndx

    @property
    def enum(self):     return _enum
    @property
    def ndx(self):      return _ndx

class EnumReg(object):

    def __init__(self, primum):
        self._enums     = []
        self._byName    = {}
        self.append(primum)

    # XXX 'in' uses a linear search based on __getitem__ rather than
    # the byName index.
    def __getitem__(self, k):
        if k < 0:
            raise ValueError('index is out of range: %s' % str(k))
        if k >= len(self._enums):
            # Python uses this to detect the end of the range
            raise IndexError()
        return self._enums[k]

    def __len_(self):
        return len(self._enums)

    def append(self, enum):
        if enum is None:
            raise ValueError('cannot add null enum')
        name = enum.name
        if name in self._byName:
            raise KeyError("we already have an enum '%s'" % name)

        entry = EnumRegEntry( enum, len(self._enums) )
        self._byName[name] = entry
        self._enums.append(entry)
        # DEBUG
        print "added '%s' to enumReg" % name
        # END

    def ndx(self, name):
        if name in self._byName:
            return self._byName[name].ndx
        else:
            return None

class FieldSpec(object):
    __slots__ = [ '_name', '_type', '_quantifier', '_fieldNbr', '_default', ]

    def __eq__(self, other):
        if other is None or not isinstance(other, FieldSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
        if other._name != self._name:
            return False
        if other._type != self._type:
            return False
        if other._quantifier != self._quantifier:
            return False
        if self._fieldNbr:
            if other._fieldNbr is None:
                return False
            if self._fieldNbr != other._fieldNbr:
                return False

        # XXX IGNORE DEFAULTS FOR NOW

        return True


    def __init__(self, name, fType, quantifier=Q_REQUIRED,
                                        fieldNbr=None, default=None):
        # -- name ---------------------------------------------------
        if name is None:
            raise ValueError('no field name specified')
        validateDottedName(name)
        self._name = name

        # -- fType --------------------------------------------------
        if fType < 0 or fType > F.maxNdx:
            raise ValueError("invalid fType '%s'" % str(fType))
        self._type = fType

        # -- quantifier ---------------------------------------------
        # XXX BAD RANGE CHECK
        if quantifier < 0 or quantifier > Q_PLUS:
            raise ValueError("invalid quantifier '%s'" % str(quantifier))
        self._quantifier = quantifier

        # -- fieldNbr -----------------------------------------------
        self._fieldNbr = int(fieldNbr)

        # -- default ------------------------------------------------
        # if default is None, could provide a default appropriate for the type
        # XXXif we are going to support a default value, it needs to be
        #   validated
        # XXX STUB
        if default is not None:
            raise NotImplementedError('default for FieldSpec')
        self._default = default

    @property
    def name(self):         return self._name

    # XXX return a string value
    @property
    def fTypeName(self):    return F.asStr(self._type)

    # XXX return a number
    @property
    def fTypeNdx(self):     return self._type

    @property
    def quantifier(self):   return self._quantifier
    #def quantifier(self):   return Q_NAMES[self._quantifier]

    @property
    def fieldNbr(self):     return self._fieldNbr

    @property
    def default(self):      return self._default

    def __str__(self):
        """ return a prettier representation of the FieldSpec """

        # KEEP THIS IN SYNC WITH __repr__

        s = []
        # assume the caller does any indenting
        s.append('%-20s ' % self._name)

        tName = self.fTypeName
        if self._quantifier != Q_REQUIRED:
            tName += qName(self._quantifier)
        s.append('%-12s' % tName)               # at least one space

        if self._fieldNbr is not None:
            s.append(' @%d ' % self._fieldNbr)  # again, at least one space

        #========================
        # XXX default not handled
        #========================

        return '' . join(s)                 # GEEP

    def __repr__(self):
        """
        Return the FieldSpec in today's notion of the canonical form.
        This doesn't have to be pretty, just absolutely clear and
        unambiguous.
        """

        # KEEP THIS IN SYNC WITH __str__

        s = []
        # assume the caller does any indenting
        s.append(self._name)
        s.append(' ')

        tName = self.fTypeName
        if self._quantifier != Q_REQUIRED:
            tName += qName(self._quantifier)
        s.append(tName)
        s.append(' ')

        if self._fieldNbr is not None:
            s.append('@%d ' % self._fieldNbr)  # at least one space

        #========================
        # XXX default not handled
        #========================

        return '' . join(s)                 # GEEP

class MsgSpec(object):
    """
    A message is specified as an acceptable sequence of typed fields.
    Each field has a 1-based index, a name, and a type.  Later it will
    have a default value.

    Serialized, a message spec begins with the name of the message,
    which is a lenPlus string; this must be either a simple name
    containing no delimiters or it may be a sequence of simple names
    separated by dots ('.').  This is followed by individual field
    specs, each of which is a lenPlus names followed by colon (':')
    followed by a fieldType.

    """
    def __init__(self, protocol, name, fields, enums=None):
        # -- protocol -----------------------------------------------
        if protocol is None:
            raise ValueError('missing protocol declaration')
        validateDottedName(protocol)
        self._protocol = protocol

        # -- msgSpec name -------------------------------------------
        if name is None:
            raise ValueError('missing protocol declaration')
        validateSimpleName(name)
        self._name = name
        self._fields = []

        # -- fields -------------------------------------------------
        ndx             = 0
        self._nameToNdx = {}

        for f in fields:
            fName = f.name
            if fName in self._nameToNdx:
                # we will just ignore any fields with duplicate names
                continue
            if not isinstance(f, FieldSpec):
                raise ValueError("'%s' is not a FieldSpec!" % fName)
            self._fields.append(f)
            self._nameToNdx[fName] = ndx
            ndx += 1
        self._size = ndx

        # -- enums ---------------------------------------------------
        if enums is not None and not isinstance(enums, list):
            raise ValueError('not a list (of EnumSpecs)')
        # we allow this to be None
        if enums is None:
            enums = []
        self._enums = enums                           # GEEP

    # redundant but seems sensible; could return _fields[0].name
    @property
    def protocol(self):     return self._protocol

    @property
    def name(self):         return self._name

    # Deprecated.  Use len() instead
    # XXX THIS DOES NOT FOLLOW PYTHON CONVENTIONS
    @property
    def size(self):         return self._size
    # END DEPRECATED
    
    def __len__(self):         return self._size

    def __getitem__(self, k):
        return self._fields[k]

    def fName(self, i):
        if i < 0 or i > self._size:
            raise ValueError('field number out of range')
        return self._fields[i].name

    def fTypeName(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')
        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeName

    def fTypeNdx(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')

        # XXX WRONG-ish: fType MUST be numeric; this should return
        # the string equivalent; HOWEVER, if the type is lMsg, we
        # want to return the message name ... XXX
        return self._fields[i].fTypeNdx

    def fDefault(self, i):
        # field numbers are zero-based
        if i < 0 or i >= self._size:
            raise ValueError('field number out of range')
        return self._fields[i].default

    @property
    def enums(self):                return self._enums

    # -- serialization ----------------------------------------------
    def __eq__(self, other):
        if other is None or not isinstance(other, MsgSpec):
            return False
        # using == in the next line causes infinite recursion
        if other is self:
            return True
        if other._protocol != self._protocol:
            return False
        if other._name != self._name:
            return False
        if self._size == 0 or other._size == 0:
            return False
        if self._size != other._size:
            return False
        for n in range(self._size):
            if not self._fields[n].__eq__(other._fields[n]):
                return False
        return True

    def __str__(self):
        """ return string representation in perhaps prettier format """
        s = []
        s.append( "protocol %s\n\n" % self._protocol)
        s.append( "message %s\n"    % self._name)
        for f in self._fields:
            s.append( "    %s\n" % f.__str__())

        return ''.join(s)

    def __repr__(self):
        """ return string representation in canonical format """
        s = []
        s.append( "protocol %s\n"   % self._protocol)
        s.append( "message %s\n"    % self._name)
        for f in self._fields:
            s.append( "  %s\n" % f.__repr__())

        return ''.join(s)

class ProtoSpec(object):
    """
    A protocol is a set of message types, enumerations, and acceptable
    message sequences.  It is essential for our purposes that any
    protocol can be constructed dynamically from its wire serialization.

    """

    def __init__(self, name):
        if name is None:
            raise ValueError('missing protocol name')
        validateDottedName(name)
        self._name = name

        # XXX STUB


    def __str__(self):
        raise NotImplementedError('__str__ for ProtoSpec')

    def __repr__(self):
        raise NotImplementedError('__repr__ for ProtoSpec')

class SeqSpec(object):
    """

    """
    def __init__(self):
        pass
        # XXX STUB


    def __str__(self):
        raise NotImplementedError('__str__ for SeqSpec')

    def __repr__(self):
        raise NotImplementedError('__repr__ for SeqSpec')

# DISPATCH TABLES ===================================================

# XXX dunno why notImpl is not picked up by
#                                          from fieldz.typed import *
def notImpl(*arg):     raise NotImplementedError

cPutFuncs  = [notImpl]*(C.maxNdx + 1)
cGetFuncs  = [notImpl]*(C.maxNdx + 1)
cLenFuncs  = [notImpl]*(C.maxNdx + 1)
cPLenFuncs = [notImpl]*(C.maxNdx + 1)

# PUTTERS, GETTERS, LEN FUNCS ---------------------------------------

lStringLen = tLenFuncs[F._L_STRING]
lStringPut = tPutFuncs[F._L_STRING]
vuInt32Len = tLenFuncs[F._V_UINT32]
vuInt32Put = tPutFuncs[F._V_UINT32]
vEnumGet   = tGetFuncs[F._V_ENUM]
vEnumLen   = tLenFuncs[F._V_ENUM]
vEnumPut   = tPutFuncs[F._V_ENUM]

# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# LEN PARAMETERS MUST BE (val, n), where n is the field number
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

def enumPairSpecLen(val, n):
    """
    val is guaranteed to be a well-formed EnumPair object; this is
    the length of the spec on the wire, what is written before the spec.
    Returns a 2-tuple containing first the byte count and then that plus
    the header lengths.
    """
    return lStringLen(val.symbol, n) + vuInt32Len(val.value, n)

def enumPairSpecPrefixedLen(val, n):
    """
    val is guaranteed to be a well-formed EnumPair object; this is
    the length of the spec on the wire, what is written before the spec.
    Returns a 2-tuple containing first the byte count and then that plus
    the header lengths.
    """
    h = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    byteCount = enumPairSpecLen(val, n)
    return h + lengthAsVarint(byteCount) + byteCount

# val = instance of the type, n = field number
def enumPairSpecPutter(buf, pos, val, n):
    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = enumPairSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
#   print "AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write field 0, the symbol
    pos = lStringPut( buf, pos, val.symbol, 0 )
#   print "AFTER WRITING SYMBOL %s pos = %u" % ( val.symbol, pos)

    # write field 1, the value
    pos = vuInt32Put( buf, pos, val.value,  1 )
#   print "AFTER WRITING VALUE %u pos = %u" % (val.value, pos)
    return pos

def enumPairSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount           # XXX should use for validation

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    sym = str(s)                        # convert bytearray to str

    # read field 1
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (val,pos) = readRawVarint(buf, pos)

    # construct the EnumPairSpec object from field values
    obj = EnumPairSpec(sym, val)
    return (obj, pos)

cLenFuncs[C._ENUM_PAIR_SPEC]    = enumPairSpecLen
cPLenFuncs[C._ENUM_PAIR_SPEC]   = enumPairSpecPrefixedLen
cPutFuncs[C._ENUM_PAIR_SPEC]    = enumPairSpecPutter
cGetFuncs[C._ENUM_PAIR_SPEC]    = enumPairSpecGetter

# ---------------------------------------------------------
def enumSpecLen(val, n):
    # val is guaranteed to be a well-formed EnumSpec object

    count   = lStringLen(val.name, 0)               # field 0 contribution
    for k in range(val.size):
        pair = val[k]
        count += enumPairSpecPrefixedLen(pair, 1)   # field 1 contribution(s)
    return count

def enumSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed EnumSpec object

    # we are going to write the header, then a byte count, then the enum
    # name, then one or more EnumPairSpecs
    h       = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    count   = enumSpecLen(val, n)
    return h + lengthAsVarint(count) + count

def enumSpecPutter(buf, pos, val, n):
    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = enumSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
#   print "AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write the enum's name
    pos = lStringPut(buf, pos, val.name, 0)             # field 0

    # write the pairs
    for k in range(val.size):
        #pos = enumPairSpecPutter(buf, pos, val.pair(k), n)
        pos = enumPairSpecPutter(buf, pos, val[k], 1)   # field 1 instances
#   print "END IS AT %u" % end      # XXX

    return pos

def enumSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount           # XXX should use for validation

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    name = str(s)                        # convert bytearray to str

    # read instances of field 1: should enforce the + quantifier here
    pairs = []
    while pos < end:
        (hdr, pos0) = readRawVarint(buf, pos)
        if hdrFieldNbr(hdr) != 1:
            # XXX SHOULD COMPLAIN IF WRONG HEADER
            # XXX This is a a peek: pos only gets advanced if OK
            print "EXPECTED FIELD 1, FOUND %s" % hdrFieldNbr(hdr)
            break
        (e,pos) = enumPairSpecGetter(buf, pos0)
        pairs.append(e)

    # create EnumSpec instance, which gets returned
    val = EnumSpec(name, pairs)
    return (val, pos)

cLenFuncs[C._ENUM_SPEC]     = enumSpecLen
cPLenFuncs[C._ENUM_SPEC]    = enumSpecPrefixedLen
cPutFuncs[C._ENUM_SPEC]     = enumSpecPutter
cGetFuncs[C._ENUM_SPEC]     = enumSpecGetter

# ---------------------------------------------------------
def fieldSpecLen(val, n):
    # val is guaranteed to be a well-formed fieldSpec object
    # fields are '_name', '_type', '_quantifier', '_fieldNbr', '_default'

    count   = lStringLen(val.name,      0)      # field 0 contribution
    count  += vEnumLen(val.fTypeNdx,    1)
    count  += vEnumLen(val.quantifier,  2)
    count  += vuInt32Len(val.fieldNbr,  3)
    if val.default is not None:
        # TYPE OF DEFAULT VALUE MUST MATCH val.fType
        pass
    return count

def fieldSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed fieldSpec object
    h       = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    count   = fieldSpecLen(val, n)
    return h + lengthAsVarint(count) + count

def fieldSpecPutter(buf, pos, val, n):
    # fields are '_name', '_type', '_quantifier', '_fieldNbr', '_default'

    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
#   print "FIELD SPEC: AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = fieldSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
#   print "FIELD SPEC: AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write the field's name
    pos = lStringPut(buf, pos, val.name, 0)             # field 0

    # write the type
    pos = vEnumPut(buf, pos, val.fTypeNdx, 1)

    # write the quantifier
    pos = vEnumPut(buf, pos, val.quantifier, 2)

    # write the field number
    pos = vuInt32Put(buf, pos, val.fieldNbr, 3)

    # write the default, should there be one
    if val.default is not None:
        # XXX STUB XXX
        pass

    return pos

def fieldSpecGetter(buf, pos):
    # we have already read the header containing the field number
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    name = str(s)                        # convert bytearray to str

    # read field 1
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (fType, pos) = vEnumGet(buf, pos)

    # read field 2
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (quant, pos) = vEnumGet(buf, pos)

    # read field 3
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (fNbr, pos) = vEnumGet(buf, pos)

    # XXX IGNORING DEFAULT
    default = None
    val = FieldSpec(name, fType, quant, fNbr, default)

    return (val, pos)

cLenFuncs[C._FIELD_SPEC]    = fieldSpecLen
cPLenFuncs[C._FIELD_SPEC]   = fieldSpecPrefixedLen
cPutFuncs[C._FIELD_SPEC]    = fieldSpecPutter
cGetFuncs[C._FIELD_SPEC]    = fieldSpecGetter

# ---------------------------------------------------------
def msgSpecLen(val, n):
    # val is guaranteed to be a well-formed msgSpec object
    # fields are  protocol, name, fields, enum=None

    count   = lStringLen(val.protocol,  0)          # field 0, protocol
    count  += lStringLen(val.name,      1)          # field 1, name
    for k in range(val.size):
        field = val[k]
        count += fieldSpecPrefixedLen(field, 2)     # field 2, fields
    if val.enums is not None and val.enums != []:
        for enum in val.enums:
            count += enumSpecPrefixedLen(enum, 3)   # field 3, optional enums
    return count

def msgSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed msgSpec object
    h       = lengthAsVarint(fieldHdrLen(n, LEN_PLUS_TYPE))
    count   = msgSpecLen(val, n)
    return h + lengthAsVarint(count) + count

def msgSpecPutter(buf, pos, val, n):
    # fields are  protocol, name, fields, enum=None
    
    # write the field header
    pos = writeRawVarint( buf, pos, fieldHdr(n, LEN_PLUS_TYPE) )
    print "MSG SPEC: AFTER WRITING HEADER pos = %u" %  pos

    # write the byte count
    count = msgSpecLen(val, n)
    pos = writeRawVarint( buf, pos, count)
    print "MSG SPEC: AFTER WRITING BYTE COUNT %u pos = %u" % (count, pos)

    # write the protocol name
    pos = lStringPut(buf, pos, val.protocol, 0)             # field 0

    # write the spec's name
    pos = lStringPut(buf, pos, val.name, 1)                 # field 1

    # write the fields
    for k in range(val.size):
        pos = fieldSpecPutter(buf, pos, val[k], 2)          # field 2 instances

    # write the enum, should there be one
    if val.enums is not None and val.enums != []:
        for enum in val.enums:
            pos = enumSpecPutter(buf, pos, enum, 3)         # yup, field 3

    return pos

def msgSpecGetter(buf, pos):
    # read the byte count, the length of the spec
    (byteCount, pos) = readRawVarint(buf, pos)
    end = pos + byteCount

    # read field 0
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    protocol = str(s)                       # convert bytearray to str

    # read field 1
    (hdr, pos) = readRawVarint(buf, pos)
    # SHOULD COMPLAIN IF WRONG HEADER
    (s, pos) = readRawLenPlus(buf, pos)
    name = str(s)                           # convert bytearray to str

    # read instances of field 2: should enforce the + quantifier here
    fields = []
    while pos < end:
        (hdr, pos0) = readRawVarint(buf, pos)
        if hdrFieldNbr(hdr) != 2:
            # XXX SHOULD COMPLAIN IF WRONG HEADER
            # XXX This is a a peek: pos only gets advanced if OK
            print "EXPECTED FIELD 2, FOUND %s" % hdrFieldNbr(hdr)
            break
        (f,pos) = fieldSpecGetter(buf, pos0)
        fields.append(f)
   
    # we may have multiple enums 
    enums = []
    while pos < end:
        (hdr, pos0) = readRawVarint(buf, pos)
        if hdrFieldNbr(hdr) != 3:
            print "EXPECTED FIELD 2, FOUND %s" % hdrFieldNbr(hdr)
            break
        (enum, pos) = enumSpecGetter(buf, pos0)
        enums.append(enum)
   
    val = MsgSpec(protocol, name, fields, enums)
    
    return (val, pos)

cLenFuncs[C._MSG_SPEC] = msgSpecLen
cPLenFuncs[C._MSG_SPEC] = msgSpecPrefixedLen
cPutFuncs[C._MSG_SPEC] = msgSpecPutter
cGetFuncs[C._MSG_SPEC] = msgSpecGetter

# ---------------------------------------------------------
def seqSpecLen(val, n):
    # val is guaranteed to be a well-formed seqSpec object
    pass

def seqSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed seqSpec object
    pass

def seqSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def seqSpecGetter(buf, pos):
     # STUB
     return (val, pos)

cLenFuncs[C._SEQ_SPEC] = seqSpecLen
cPLenFuncs[C._SEQ_SPEC] = seqSpecPrefixedLen
cPutFuncs[C._SEQ_SPEC] = seqSpecPutter
cGetFuncs[C._SEQ_SPEC] = seqSpecGetter

# ---------------------------------------------------------
def protoSpecLen(val, n):
    # val is guaranteed to be a well-formed protoSpec object
    pass

def protoSpecPrefixedLen(val, n):
    # val is guaranteed to be a well-formed protoSpec object
    pass

def protoSpecPutter(buf, pos, val, n):
    # STUB
    return pos

def protoSpecGetter(buf, pos):
     # STUB
     return (val, pos)              # END DISPATCH TABLES

cLenFuncs[C._PROTO_SPEC] = protoSpecLen
cPLenFuncs[C._PROTO_SPEC] = protoSpecPrefixedLen
cPutFuncs[C._PROTO_SPEC] = protoSpecPutter
cGetFuncs[C._PROTO_SPEC] = protoSpecGetter


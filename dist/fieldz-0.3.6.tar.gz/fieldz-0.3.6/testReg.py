#!/usr/bin/python

# testReg.py
import time, unittest

from rnglib         import SimpleRNG
from fieldz.reg     import Registry
import fieldz.fieldTypes as F

class TestReg (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # utility functions #############################################


    # actual unit tests #############################################
    def testReg(self):
        testReg = Registry()

        # XXX when we add the core types, we will need to increase the 
        # value on the left accordingly.  This ensures that the range
        # on the next for loop will be valid.
        self.assertTrue( F.maxNdx + 1, testReg.nextRegID )

        # verify that all fieldTypes are defined in the registry, each
        # with the proper index (vBool through fBytes32 at F.maxNdx)
        # DEBUG
        print 'REGISTERED FIELD TYPES'
        # END
        for i in range(F.maxNdx + 1):
            name = testReg.entry(i).qualName
            # DEBUG
            print '%2u %s' % (i, name)
            # END
            self.assertEquals(F.asStr(i), name)
            self.assertEquals(i, testReg.qualName2RegID(name))

        # XXX STUB

if __name__ == '__main__':
    unittest.main()

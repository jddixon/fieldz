# fieldz/typed.py

import ctypes
from fieldz         import FieldTypes
from fieldz.raw     import *
from fieldz.msgSpec import *

__all__ = [ 'FieldTypes', 'TFBuffer', 'TFReader', 'TFWriter',
            'encodeSint32', 'decodeSint32',
            'encodeSint64', 'decodeSint64',
          ]

def encodeSint32(s):
    x = ctypes.c_int32(0xffffffff & s).value
    # we must have the sign filling in from the left
    v = (x << 1) ^ ( x >> 31) 
#   # DEBUG
#   print "\nencodeSint32: 0x%x --> 0x%x" % (s, v)
#   # END
    return v

def decodeSint32(v):
    # decode zig-zag:  stackoverflow 2210923
    x = (v >> 1) ^ (-(v & 1)) 
    s = ctypes.c_int32(x).value
#   # DEBUG
#   print "decodeSint32: 0x%x --> 0x%x" % (v, s)
#   # END
    return s

def encodeSint64(s):
    v = ctypes.c_int64(0xffffffffffffffff & s).value
    # we must have the sign filling in from the left
    v = (v << 1) ^ ( v >> 63) 
    return v

def decodeSint64(v):
    v = (v >> 1) ^ (-(v & 1)) 
    s = ctypes.c_int64(v).value
    return s

class TFBuffer(object):

    __slots__ = ['_buffer', '_position', '_limit', '_capacity', '_msgSpec',]

    def __init__(self, buffer, msgSpec):
        self._position = 0
        if buffer is None:
            raise ValueError('base buffer cannot be null')
        self._buffer    = buffer
        self._capacity  = len(buffer)
        self._limit     = self._capacity
        if msgSpec is None:
            raise ValueError('no msgSpec')
        if not isinstance (msgSpec, MsgSpec):
            raise ValueError('object is not a MsgSpec')
        self._msgSpec  = msgSpec

    @property
    def buffer(self):   return self._buffer

    @property
    def position(self): return self._position
    @position.setter
    def position(self, offset):
        if offset < 0:
            raise ValueError('position cannot be negative')
        if (offset > self._limit):
            raise ValueError('position cannot be beyond limit')
        self._position = offset

    @property
    def limit(self):    return self._limit
    @limit.setter
    def limit(self, offset):
        if offset < 0:
            raise ValueError('limit cannot be set to a negative')
        if (offset < self._position):
            raise ValueError("limit can't be set to less than current position")
        if (offset > self._capacity):
            raise ValueError('limit cannot be beyond capacity')
        self._limit = offset
    @property
    def capacity(self): return self._capacity

    @classmethod
    def create(cls, n, msgSpec):
        if n <= 0:
            raise ValueError("buffer size must be a positive number")
        buffer = bytearray(n)
        return cls(buffer, msgSpec)

class TFReader(TFBuffer):
    # needs some thought; the pType is for debug
    __slots__ = ['_fieldNbr', '_fType', '_pType', '_value',  ]

    def __init(self, buffer, msgSpec):
        super(TFReader, self).__init__(buffer, msgSpec)
        # this is a decision: we could read the first field
        self._fieldNbr = -1
        self._fType    = -1
        self._pType    = -1
        self._value    = None


    # def create(n) inherited 

    @property 
    def fieldNbr(self):     return self._fieldNbr
    @property 
    def fType(self):        return self._fType
    @property 
    def pType(self):        return self._pType      # for DEBUG
    @property 
    def value(self):        return self._value

    def getNext(self):
        (self._pType, self._fieldNbr, self._position) = \
                            readFieldHdr(self._buffer, self._position)

        # getter has range check
        self._fType = self._msgSpec.fType(self._fieldNbr)

        # we use the field type to verify that have have read the right 
        # primitive type 
        # - implemented using varints -------------------------------
        if self._fType <= FieldTypes._V_UINT64:
            if self._pType != VARINT_TYPE:
                raise RuntimeError("pType is %u but should be %u" % (
                                        self._pType, VARINT_TYPE))
            (self._value, self._position) = readRawVarint(
                                            self._buffer, self._position)
            # DEBUG
            print "getNext: readRawVarint returns value = 0x%x" % self._value
            # END
            if self._fType == FieldTypes._V_SINT32:
                self._value = decodeSint32(self._value)
                # DEBUG
                print "    after decode self._value is 0x%x" % self._value
                # 
            elif self._fType == FieldTypes._V_SINT64:
                self._value = decodeSint64(self._value)

        # implemented using B32 -------------------------------------
        elif self._fType <= FieldTypes._F_FLOAT:
            self._pType = B32_TYPE              # DEBUG
            (v, self._position) = readRawB32(self._buffer, self._position)
            if self._fType == FieldTypes._F_INT32:
                self._value = ctypes.c_int32(v).value
            else:
                raise NotImplementedError('B32 handling for float')

        # implemented using B64 -------------------------------------
        elif self._fType <= FieldTypes._F_DOUBLE:
            self._pType = B64_TYPE              # DEBUG
            (v, self._position) = readRawB64(self._buffer, self._position)
            if self._fType == FieldTypes._F_INT64:
                self._value = ctypes.c_int64(v).value
            else:
                raise NotImplementedError('B64 handling for double')

        # implemented using LEN_PLUS --------------------------------
        elif self._fType <= FieldTypes._L_MSG:
            self._pType = LEN_PLUS_TYPE         # DEBUG
            (v, self._position) = readRawLenPlus(self._buffer, self._position)
            if self._fType == FieldTypes._L_STRING:
                self._value = str(v)
            elif self._fType == FieldTypes._L_BYTES:
                self._value = v
            else:
                raise NotImplementedError('LEN_PLUS handled as L_MSG')

        # implemented using B128, B160, B256 ------------------------
        elif self._fType == FieldTypes._F_BYTES16:
            self._pType = B128_TYPE             # DEBUG
            (self._value, self._position) = readRawB128(
                                                self._buffer, self._position)
        elif self._fType == FieldTypes._F_BYTES20:
            self._pType = B160_TYPE             # DEBUG
            (self._value, self._position) = readRawB160(
                                                self._buffer, self._position)
        elif self._fType == FieldTypes._F_BYTES32:
            self._pType = B256_TYPE             # DEBUG
            (self._value, self._position) = readRawB256(
                                                self._buffer, self._position)

        else:
            raise NotImplementedError(
                    "decode for type %d has not been implemented" % self._fType)



        
class TFWriter(TFBuffer):
    # needs some thought; MOSTLY FOR DEBUG
    __slots__ = ['_fieldNbr', '_fType', '_pType', '_value', ]

    def __init(self, buffer, msgSpec):
        super(TFWriter, self).__init__(buffer, msgSpec)
        # this is a decision: we could read the first field
        self._fieldNbr = -1
        self._fType    = -1
        self._pType    = -1
        self._value    = None

    # def create(n) inherited 

    # These are for DEBUG
    @property 
    def fieldNbr(self):     return self._fieldNbr
    @property 
    def fType(self):        return self._fType
    @property 
    def pType(self):        return self._pType  
    @property 
    def value(self):        return self._value
    # END DEBUG PROPERTIES

    # 3rd arg was fType
    def putNext(self, fieldNbr, value):

        # getter has range check
        fType = self._msgSpec.fType(fieldNbr)
        v = None

        # ***********************************************************
        # THIS SHOULD BE DONE THROUGH A DISPATCH TABLE **************
        # ***********************************************************

        # - implemented using varints ===============================
        if fType <= FieldTypes._V_UINT64:
            if fType == FieldTypes._V_BOOL:
                if value is True:       v = 1
                else:                   v = 0
            elif fType == FieldTypes._V_ENUM:
                # just handle enums as simple ints for now, but constrain
                # to 16 bits; any sign is uhm mangled
                v = 0xffff & value

            elif fType == FieldTypes._V_INT32 \
                                or fType == FieldTypes._V_UINT32:
                v = 0xffffffff & value
            elif fType == FieldTypes._V_INT64 \
                                or fType == FieldTypes._V_UINT64:
                v = 0xffffffffffffffff & value

            # XXX NEXT TWO FAIL - returns value/2 (with correct sign)
            elif fType == FieldTypes._V_SINT32: 
                v = encodeSint32(value)
            elif fType == FieldTypes._V_SINT64:
                v = encodeSint64(value)

            self._position = writeVarintField( self._buffer, self._position, 
                                                    v, fieldNbr)
            # DEBUG
            self._pType = VARINT_TYPE
            # END

        # - implemented using B32 ===================================
        elif fType <= FieldTypes._F_FLOAT:
            self._pType = B32_TYPE          # DEBUG
            if fType == FieldTypes._F_INT32:
                # XXX we do any casting at this level
                value = ctypes.c_int32(value).value
                self._position = writeB32Field(self._buffer, self._position,
                                                    value, fieldNbr)
            elif fType == FieldTypes._F_FLOAT:
                # XXX we do any casting at this level
                raise NotImplementedError()

        # - implemented using B64 ===================================
        elif fType <= FieldTypes._F_DOUBLE:
            self._pType = B64_TYPE          # DEBUG
            if fType == FieldTypes._F_INT64:
                # XXX we do any casting at this level
                value = ctypes.c_int64(value).value
                self._position = writeB64Field(self._buffer, self._position,
                                                    value, fieldNbr)
            elif fType == FieldTypes._F_DOUBLE:
                raise NotImplementedError()

        # - implemented using LEN_PLUS ==============================
        elif fType <= FieldTypes._L_MSG:
            self._pType = LEN_PLUS_TYPE          # DEBUG
            if fType == FieldTypes._L_STRING or fType == FieldTypes._L_BYTES:
                self._position = writeLenPlusField(self._buffer, self._position,
                                                    value, fieldNbr)
            elif fType == FieldTypes._L_MSG:
                raise NotImplementedError()
    
        # - implemented using B128/160/256 ==========================
        elif fType == FieldTypes._F_BYTES16:
            self._pType    = B128_TYPE
            self._position = writeB128Field(self._buffer, self._position,
                                                    value, fieldNbr)

        elif fType == FieldTypes._F_BYTES20:
            self._pType    = B160_TYPE
            self._position = writeB160Field(self._buffer, self._position,
                                                    value, fieldNbr)

        elif fType == FieldTypes._F_BYTES32:
            self._pType    = B256_TYPE
            self._position = writeB256Field(self._buffer, self._position,
                                                    value, fieldNbr)

        # -- UNRECOGNIZED ===========================================
        else:
            print "unknown/unimplemented field type %s" % str(fieldType)

        # DEBUG these are debug because whoever did the put should already
        # know their value
        self._fType = fType
        self._value = v
        # END

        # DEBUG
        print "putNext: field   %u\n" \
              "         fType   %u\n" \
              "         pType   %u\n" \
              "         value   %s\n" \
              "         offset  %u"     % (
              fieldNbr, self._fType, self._pType, str(value), self._position)
        # END



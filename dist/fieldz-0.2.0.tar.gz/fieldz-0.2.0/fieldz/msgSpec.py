# fieldz/msgSpec.py

import re, sys
from fieldz import FieldTypes

__all__ = [  \
            # constants, so to speak: quantifiers
            'Q_REQUIRED',   # no quantifier, so one and only one such field
            'Q_OPTIONAL',   # ?: either zero or one instance of the field
            'Q_STAR',       # *: zero or more instances of the field allowed
            'Q_PLUS',       # +: one or more instances of the field

            # methods
            'qName',

            # classes
            'EnumSpec',         'FieldSpec',        'MsgSpec',
            'MsgSpecParser',    'MsgSpecWriter',
            'WireSpecParser',   'WireSpecWriter',
          ]

Q_REQUIRED  = 0
Q_OPTIONAL  = 1
Q_STAR      = 2
Q_PLUS      = 3

Q_NAMES     = ['', '?', '*', '+',]
def qName(n):
    if n < 0 or n >= len(Q_NAMES):
        raise ValueError('does not map to a valid quantifier: %u' % str(n))
    return Q_NAMES[n]

# we are simple folk
_VALID_NAME_PAT = "[a-zA-Z_][a-zA-Z_0-9]*$"
_VALID_NAME_RE  = re.compile(_VALID_NAME_PAT)

class EnumSpec(object):
    """
    For our purposes an enum is a list of simple names (names containing
    no delimiters and a map from such names to their 0-based indexes.
    """
    def __init__(self, names):
        if names is None:
            raise ValueError('null list of enum names')
        if len(names) == 0:
            raise ValueError('empty list of enum names')

        # sorting seems inappropriate, but we must not allow matches
        self._names     = []
        self._name2ndx  = {}
        i = 0
        for name in names:
            m = _VALID_NAME_RE.match(name)
            if m is None:
                raise ValueError("'%s' is not a valid enum name" % name)
            if not name in self._name2ndx:
                # silently discard duplicates
                self._names.append(name)
                self._name2ndx[name]    = i
                i += 1
        self._size      = len(self._names)  # which should be the same as i

    def value(self, s):
        """ map a name to the corresponding value """
        if s in self._name2ndx:
            return self._name2ndx[s]
        else:
            return None

    def name(self, n):
        if n < 0 or n > self._size - 1:
            return None
        else:
            return self._names[n]

    def _repr(self):
        return ',' . join(self._names)


class FieldSpec(object):
    __slots__ = [ '_name', '_type', '_quantifier', '_default', ]

    def __init__(self, name, fType, quantifier='', default=None):
        if name is None:
            raise ValueError('no field name specified')
        m = _VALID_NAME_RE.match(name)
        if m is None:
            raise ValueError("'%s' is not a field enum name" % name)
        self._name = name

        # XXX TYPE - SHOULD CONVERT TO INTEGER
        self._type = fType

        # XXX QUANTIFIER
        if quantifier == '':    self._quantifier = Q_REQUIRED
        elif quantifier == '?': self._quantifier = Q_OPTIONAL
        elif quantifier == '*': self._quantifier = Q_STAR
        elif quantifier == '+': self._quantifier = Q_PLUS
        else: raise ValueError("invalid quantifier '%s'" % str(quantifier))

        # XXX DEFAULT
        # if default is None, could provide a default appropriate for the type
        # XXXif we are going to support a default value, it needs to be
        #   validated
        # XXX STUB
        self._default = default

    @property
    def name(self):         return self._name

    # XXX return a string value
    @property
    def fType(self):        return self._type

    @property
    def quantifier(self):   return self._quantifier

    @property
    def default(self):      return self._default

class MsgSpec(object):
    """
    A message is specified as an acceptable sequence of typed fields.
    Each field has a 1-based index, a name, and a type.  Later it will
    have a default value.

    Serialized, a message spec begins with the name of the message,
    which is a lenPlus string; this must be either a simple name
    containing no delimiters or it may be a sequence of simple names
    separated by dots ('.').  This is followed by individual field
    specs, each of which is a lenPlus names followed by colon (':')
    followed by a fieldType.
    """
    def __init__(self, name, fields, enum=None):
        self._fields = []

        F = FieldTypes()            # XXX UGH!
        junk = F._L_MSG

        # this may raise an exception if the name is null or otherwise invalid
        field0 = FieldSpec(name, F._L_MSG)
        # a convenience
        self._name = name

        ndx = 0
        self._fields.append(field0)
        self._nameToNdx = { name: ndx }

        for f in fields:
            fName = f.name
            if fName in self._nameToNdx:
                # we will just ignore any fields with duplicate names
                continue
            if not isinstance(f, FieldSpec):
                raise ValueError("'%s' is not a FieldSpec!" % fName)
            self._fields.append(f)
            ndx += 1
            self._nameToNdx[fName] = ndx

        if enum is not None and not isinstance(enum, EnumSpec):
            raise ValueError('not an EnumSpec')
        self._enum = enum
        self._size = ndx

    # redundant but seems sensible; could return _fields[0].name
    @property
    def name(self):         return self._name

    def fName(self, i):
        if i < 0 or i > self._size:
            raise ValueError('field number out of range')
        return self._fields[i].name

    def fType(self, i):
        if i < 0 or i > self._size:
            raise ValueError('field number out of range')
        return self._fields[i].fType

    def default(self, i):
        if i < 0 or i > self._size:
            raise ValueError('field number out of range')
        return self._fields[i].default

# 'MsgSpecParser',    'MsgSpecWriter', 'WireSpecParser',   'WireSpecWriter',

class MsgSpecParser(object):
    """
    Reads a human-readable MsgSpec (a *.msgSpec file) to produce a
    MsgSpec object model, which is a MsgSpec with FieldSpecs and EnumSpecs
    dangling off of it.
    """
    def __init__(self, fd):
        self._fd = fd

    def chomp(self, line):
        """ strip out comments too """
        pass

    def parse(self):
        # DEBUG
        print
        # END
        line = self._fd.readline()
        # The first condition never fails if fd is a file-like object 
        # (from StringIO)
        while line is not None and line != '':
            # DEBUG
            print "LINE: " + line,      # do notice the comma
            sys.stdout.flush()
            # END

            # XXX STUB: should handle the line here

            line = self._fd.readline()
        self._fd.close()                # does this make sense??

class MsgSpecWriter(object):
    """
    Given a MsgSpec (including attached FieldSpecs and optional EnumSpec)
    produces a canonical string representation suitable for writing to disk.
    """
    def __init__(self, mSpec):
        pass

class WireSpecParser(object):
    """
    Reads a MsgSpec fully serialized to wire form (and so a sequence of
    fieldz) produce a MsgSpec object model, which is a MsgSpec with
    FieldSpecs and EnumSpecs dangling off of it.
    """
    def __init__(self, w):
        pass

class WireSpecWriter(object):
    """
    Given a MsgSpec (including attached FieldSpecs and optional EnumSpec)
    produces a serialization using FieldTypes.
    """
    def __init__(self, mSpec):
        pass

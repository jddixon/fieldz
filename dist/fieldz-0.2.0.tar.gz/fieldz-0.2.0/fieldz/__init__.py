# fieldz/__init__.py

__version__         = '0.2.0'
__version_date__    = '2012-08-24'

__all__ = [ '__version__', '__version_date__',
            'FieldTypes',
]

# MAPS --------------------------------------------------------------
# the first table maps ints (field types) to names, the second names to types
_names      = {}
_name2type  = {}

def mapEm(x, s):
    # global _names, _name2type
    _names[x]       = s
    _name2type[s]   = x

# XXX This has become an embarassment

# FieldTypes class --------------------------------------------------
# ... which is probably just a bad idea
class FieldTypes(object):
    """ higher-level field types """

    # FIELDS IMPLEMENTED USING VARINTS --------------------
    _V_BOOL    = 0
    _V_ENUM    = 1
    _V_INT32   = 2     # usually/mostly positive values
    _V_INT64   = 3     # ditto
    _V_SINT32  = 4     # expect some negative values, zig-zag encoded
    _V_SINT64  = 5     # ditto
    _V_UINT32  = 6     # unsigned
    _V_UINT64  = 7     # unsigned

    # IMPLEMENTED USING B32 -------------------------------
    _F_INT32   = 8     # always 4 bytes
    _F_FLOAT   = 9

    # IMPLEMENTED USING B64 -------------------------------
    _F_INT64   = 10     # always 8 bytes
    _F_DOUBLE  = 11

    # IMPLEMENTED USING LEN_PLUS --------------------------
    _L_STRING  = 12    # unicode or 7-bit ASCII
    _L_BYTES   = 13    # arbitrary byte values
    _L_MSG     = 14    # an embedded message

    # OTHER FIXED LENGTH BYTE SEQUENCES -------------------
    _F_BYTES16 = 15    # fixed length string of 16 bytes
    _F_BYTES20 = 16    # fixed length string of 20 bytes
    _F_BYTES32 = 17    # fixed length string of 32 bytes

    _MAX_TYPE  = _F_BYTES32

    # to create an illusion of immutability
    @property
    def vBool(clz):        return clz._V_BOOL
    @property
    def vEnum(clz):        return clz._V_ENUM
    @property
    def vInt32(clz):       return clz._V_INT32
    @property
    def vInt64(clz):       return clz._V_INT64
    @property
    def vsInt32(clz):      return clz._V_SINT32
    @property
    def vsInt64(clz):      return clz._V_SINT64
    @property
    def vuInt32(clz):      return clz._V_UINT32
    @property
    def vuInt64(clz):      return clz._V_UINT64
    @property
    def fInt32(clz):       return clz._F_INT32
    @property
    def fFloat(clz):       return clz._F_FLOAT
    @property
    def fInt64(clz):       return clz._F_INT64
    @property
    def fDouble(clz):      return clz._F_DOUBLE
    @property
    def lString(clz):      return clz._L_STRING
    @property
    def lBytes(clz):       return clz._L_BYTES
    @property
    def fBytes16(clz):     return clz._F_BYTES16
    @property
    def fBytes20(clz):     return clz._F_BYTES20
    @property
    def fBytes32(clz):     return clz._F_BYTES32

    # XXX NEED A MAP FROM THESE CONSTANTS TO ENCODE FUNCTIONS, AND THEN A
    # MAP TO DECODE FUNCTIONS
    mapEm(_V_BOOL,      'vBool')
    mapEm(_V_ENUM,      'vEnum')
    mapEm(_V_INT32,     'vInt32')
    mapEm(_V_INT64,     'vInt64')
    mapEm(_V_SINT32,    'vsInt32')
    mapEm(_V_SINT64,    'vsInt64')
    mapEm(_V_UINT32,    'vuInt32')
    mapEm(_V_UINT64,    'vuInt64')
    mapEm(_F_INT32,     'fInt32')
    mapEm(_F_FLOAT,     'fFloat' )
    mapEm(_F_INT64,     'fInt64')
    mapEm(_F_DOUBLE,    'fDouble')
    mapEm(_L_STRING,    'lString')
    mapEm(_L_BYTES,     'lBytes')
    mapEm(_F_BYTES16,   'fBytes16')
    mapEm(_F_BYTES20,   'fBytes20')
    mapEm(_F_BYTES32,   'fBytes32')

    # ---------------------------------------------------------------
    # XXX CONFUSED.  There is no reason for this to class method.
    # Rename fieldTypeName ?
    # ---------------------------------------------------------------
    @classmethod
    def name(clz, v):
        if v is None or v < 0 or FieldTypes._MAX_TYPE < v:
            raise ValueError('no such field type: %s' + str(v))
        return _names[v]

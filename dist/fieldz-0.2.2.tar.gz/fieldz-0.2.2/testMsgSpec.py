#!/usr/bin/python

# testMsgSpec.py
import StringIO, time, unittest

from rnglib         import SimpleRNG
from fieldz         import *
from fieldz.msgSpec import *
from fieldz.typed   import *


LOG_ENTRY_MSG_SPEC = """protocol org.xlattice.zoggery
message logEntry:
    timestamp   fInt32
    nodeID      fBytes20
    key         fBytes20
    by          lString
    path        lString
"""
class TestMsgSpec (unittest.TestCase):

    def setUp(self):
        self.rng = SimpleRNG( time.time() )
    def tearDown(self):
        pass

    # actual unit tests #############################################

    def testMaps(self):
        maxNdx  = maxFieldTypeNdx()
        maxName = stdFieldTypeName(maxNdx)
        self.assertEquals('fBytes32', maxName)

    def testEnum(self):
        """ 
        A not very useful enum, limited to mapping a fixed list of
        names into a zero-based sequence of integers.
        """

        # XXX should test null or empty lists, ill-formed names
        names = ['abc', 'def', 'ghi']
        enum  = EnumSpec(names)
        self.assertEquals( ','.join(names), enum.__str__())
        self.assertEquals( 'abc', enum.name(0))
        self.assertEquals( 'def', enum.name(1))
        self.assertEquals( 'ghi', enum.name(2))

    def doFieldTest(self, name, fType, quantifier='', default=None):
        # XXX Defaults are ignore for now.
        f = FieldSpec(name, fType, quantifier, default)

        self.assertEquals(name,         f.name)
        self.assertEquals(fType,        f.fTypeName)
        self.assertEquals(quantifier,   f.quantifier)
        if default is not None:
            self.assertEquals(default,  f.default)

        expectedRepr = "%s  %s%s" % (name, fType, quantifier)
        # DEFAULTS NOT SUPPORTED
        # @N NOTATION FOR FIELD POSITIONS NOT YET SUPPORTED
        # @N NOTATION FOR FIELD POSITIONS NOT YET SUPPORTED
        self.assertEquals(expectedRepr, f.__repr__())

    def testsQuantifiers(self):
        self.assertEquals('',  qName(Q_REQUIRED))
        self.assertEquals('?', qName(Q_OPTIONAL))
        self.assertEquals('*', qName(Q_STAR))
        self.assertEquals('+', qName(Q_PLUS))

    def testFieldSpec(self):
        self.doFieldTest( 'foo',    'vInt32'                ) 
        # default is not implemented yet
       #self.doFieldTest( 'bar',    'vsInt32', '*',    -3   )    
        self.doFieldTest( 'bar',    'vsInt32',  '*'         )    
        self.doFieldTest( 'nodeID', 'fBytes20', '?'         )
        self.doFieldTest( 'tix',    'vBool',    '+'         )

    def testMsgSpec(self):
        """ this is in fact the current spec for a log entry """
        protocol= 'org.xlattice.upax'
        name    = 'logEntry'
        # the enum is not used 
        enum    = EnumSpec(['oh', 'hello', 'there',])
        fields  = [ \
                FieldSpec('timestamp', 'fInt32'),
                FieldSpec('nodeID',    'fBytes20'),
                FieldSpec('key',       'fBytes20'),
                FieldSpec('by',        'lString'),
                FieldSpec('path',      'lString'),
        ]
        msgSpec = MsgSpec(protocol, name, fields, enum)

        self.assertEquals(name, msgSpec.name)

        self.assertEquals(len(fields), msgSpec.size) 

        for i in range(0,msgSpec.size):
            self.assertEquals(fields[i].name,       msgSpec.fName(i))
            self.assertEquals(fields[i].fTypeName,  msgSpec.fTypeName(i))
        self.roundTripMsgSpecViaString(msgSpec)

    def roundTripMsgSpecViaString(self, m):
        """ 
        Convert a MsgSpec object model to canonical string form,
        parse that to make a clone, and verify that the two are
        equal.
        """
        canonicalSpec = m.__repr__()
        p = StringMsgSpecParser( StringIO.StringIO(canonicalSpec) )
        clonedSpec   = p.parse()
        # crude tests of equals()
        self.assertFalse( m.equals(None)        )
        self.assertTrue ( m.equals(m)           )
        self.assertTrue ( m.equals(clonedSpec)  )
        self.assertTrue ( clonedSpec.equals(m)  )

    def testParseAndWriteMsgSpec(self):
        data = StringIO.StringIO(LOG_ENTRY_MSG_SPEC)
        p    = StringMsgSpecParser(data)   # data should be file-like
        sOM  = p.parse()             # object model from string serialization
        self.assertIsNotNone(sOM)
        self.assertTrue(isinstance(sOM, MsgSpec))

        # XXX we aren't using the protocol line
        self.assertEquals( 'logEntry', sOM.name )

        # XXX THIS SHOULD BE A LOOP, with no magic numbers
        self.assertEquals(sOM.fName(0),     'timestamp')   
        self.assertEquals(sOM.fTypeName(0), 'fInt32')
        self.assertEquals(sOM.fName(1),     'nodeID')
        self.assertEquals(sOM.fTypeName(1), 'fBytes20')
        self.assertEquals(sOM.fName(2),     'key')
        self.assertEquals(sOM.fTypeName(2), 'fBytes20')
        self.assertEquals(sOM.fName(3),     'by')
        self.assertEquals(sOM.fTypeName(3), 'lString')
        self.assertEquals(sOM.fName(4),     'path')
        self.assertEquals(sOM.fTypeName(4), 'lString')


if __name__ == '__main__':
    unittest.main()
